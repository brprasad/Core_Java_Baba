/*Lab958.java:11: error: abstract method show() in Hello cannot be accessed directly
                super.show();
                     ^
1 error*/

abstract class Hello	// abstract class 
{
	abstract void show();
}

class Hai extends Hello 
{
	void show()
	{
		System.out.println("Hai -> show()");
		super.show();	// can't access abstract method directly with super keyword.
	}
}
class Lab958
{
	public static void main(String[] args)
	{
		Hai hai=new Hai();
		hai.show();
	}
}