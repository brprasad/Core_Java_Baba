class Shape
{
	void area(){}
}
class Square extends Shape{}

class Lab947
{
	public static void main(String[] args)
	{
		Shape shape=new Square();
		shape.area();
	}
}