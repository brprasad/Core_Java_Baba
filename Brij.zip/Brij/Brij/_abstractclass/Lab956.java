abstract class Hello	// abstract class 
{
	static int A=1234;	//static datamemebr
	static void show()	// static member function
	{
		System.out.println("Hello -> show()");
	}
}
class Lab956	// when we use static members in abstract class; so to access static member always use class name
{
	public static void main(String[] args)
	{
		System.out.println(Hello.A);	// 1234
		Hello.show(); // Hello -> show()
	}
}