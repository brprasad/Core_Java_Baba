// to load main method JVM only require class name and main method with standard signature, ie Lab959.main()
abstract class Lab959 
{
	public static void main(String[] args)
	{
		System.out.println("Lab959 Main Method");
	}
}