package com.jlc.p1;
public abstract class Person
{
	abstract void sleeping();
}