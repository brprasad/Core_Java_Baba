package com.jlc.p2;
import com.jlc.p1.Person;

public class Student extends Person
{
	public void sleeping()
	{
		System.out.println("Student-> sleeping ");
	}
	public static void main(String[] args)
	{
		Student s=new Student();
		s.sleeping();
	}
}