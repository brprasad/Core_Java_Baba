abstract class Person 
{
	public abstract void sleeping();
}

class Student extends Person 
{
	void sleeping() 
	{
		System.out.println("Student -> sleeping");
	}
}

class Lab955
{
	public static void main(String[] args)
	{
		Student student =new Student();
		student.sleeping();
	}
}