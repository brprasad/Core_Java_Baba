/*Lab950.java:14: error: Shape is abstract; cannot be instantiated
                Shape shape=new Shape();
                            ^
1 error*/
		
		abstract class Shape			// if their is any abstract method in your class then make class as abstract class.
{
	abstract void area(); 
}

class Lab950
{
	public static void main(String[] args)
	{
		Shape shape=new Shape();	//
		shape.area();
	}
}