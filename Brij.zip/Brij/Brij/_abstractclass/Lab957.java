abstract class Hello	// abstract class 
{
	int a; // instance data member.	
	void show()	// instance member funtion 
	{
		System.out.println("Hello -> show()");
		System.out.println(a);
	}
	
	{	// instance block
		System.out.println("instance block of Hello class ");
	}
	
	Hello(int a)	 // constructor
	{
		System.out.println("Default constructor of Hello class ");
		this.a=a;
	}
}

// instance member, instance block , instance method,  constructor of abstract class will be access with sub class object
class Hai extends Hello 
{
	Hai(int a)
	{
		super(a);
	}
}
class Lab957
{
	public static void main(String[] args)
	{
		Hai hai=new Hai(10);
		hai.show();
	}
}