/*Lab949.java:1: error: Shape is not abstract and does not override abstract method area() in Shape
class Shape
^
1 error*/

class Shape			// if their is any abstract method in your class then make class as abstract class.
{
	abstract void area(); 
}
class Square extends Shape{}

class Lab949
{
	public static void main(String[] args)
	{
		Shape shape=new Square();
		shape.area();
	}
}