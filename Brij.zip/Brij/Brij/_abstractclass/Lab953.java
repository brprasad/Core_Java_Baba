abstract class Person			// if their is any abstract method in your class then make class as abstract class.
{
	abstract void sleeping(); 
	abstract void walking(); 
}
abstract class Student extends Person
{								// if any class extending abstract class then that class should do following :-
								// Either implementation all the method of abstract class in your class
								// OR make your class itself as abstract class.

	void sleeping()
	{
		System.out.println("Student- sleeping()");
	}
}

class CurrentStudent extends Student
{								// if any class extending abstract class then that class should do following :-
								// Either implementation all the method of abstract class in your class
								// OR make your class itself as abstract class.

	void walking()
	{
		System.out.println("CurrentStudent- walking()");
	}
	
}

class Lab953
{
	public static void main(String[] args)
	{
		Person person=new CurrentStudent();
		person.sleeping();
		person.walking();
	}
}