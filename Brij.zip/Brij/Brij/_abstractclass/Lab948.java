/*Lab948.java:3: error: missing method body, or declare abstract
        void area();
             ^
1 error*/

class Shape
{
	void area(); // if you don't know or don't want to give the implementation of method then declare it as abstract.
}
class Square extends Shape{}

class Lab948
{
	public static void main(String[] args)
	{
		Shape shape=new Square();
		shape.area();
	}
}