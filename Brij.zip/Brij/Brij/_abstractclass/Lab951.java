/*Lab951.java:6: error: Square is not abstract and does not override abstract method area() in Shape
class Square extends Shape{ }
^
1 error*/

abstract class Shape			// if their is any abstract method in your class then make class as abstract class.
{
	abstract void area(); 
}
class Square extends Shape{ }	// if any class extending abstract class then that class should do following :-
								// Either implementation all the method of abstract class in your class
								// OR make your class itself as abstract class.

class Lab951
{
	public static void main(String[] args)
	{
		Shape shape=new Square();
		shape.area();
	}
}