class Hello implements Inter1, Inter2
{	// if a class implements interface then it must override all method of interface or make itself as abstract.

	public void m1() 
	{
		System.out.println("Hello ->m1()");
	}
	public void m2() 
	{
		System.out.println("Hello ->m2()");
	}
	public void m3() 
	{
		System.out.println("Hello ->m3()");
		System.out.println(Inter1.A); // use Interface name to access Interface Static datamember.
		System.out.println(Inter2.A); // use Interface name to access Interface Static datamember.
		System.out.println(B);
		System.out.println(C);
		
	}
}
class Lab970
{
	public static void main(String[] args)
	{
		Hello hello =new Hello();
			
		Inter1 inter1=hello;	// inheritance relation b/w interface Inter1 and class Hello , so dynamic dispatch is possible.
		inter1.m1();
		inter1.m2();
		
		Inter2 inter2=hello;	// inheritance relation b/w interface Inter2 and class Hello , so dynamic dispatch is possible.
		inter2.m2();
		inter2.m3();
		
		
	}
}