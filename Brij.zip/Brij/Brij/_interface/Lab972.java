interface Inter1
{
	void show();
}
class A 
{
	public void show()
	{
		System.out.println("A-> show()");
	}
}
class B extends A implements Inter1{}

class Lab972
{
	public static void main(String[] args)
	{
		B bobj=new B();
		bobj.show();
	}
}