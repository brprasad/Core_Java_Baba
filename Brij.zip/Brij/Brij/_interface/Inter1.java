interface Inter1
{
	void m1();
	void m2();
	int A=10;
	int B=20;
	
}
