/*Lab960.java:13: error: no interface expected here
class Hello extends Inter1{} 
                    ^
1 error*/

interface Inter1
{
	void m1();
	public abstract void m2();
	int A=10;
	public final static int B=20;
}
class Hello extends Inter1{} // interface can't be used with extends Keyword.

class Lab960
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");
	}
}