/*Lab963.java:17: error: m1() in Hello cannot implement m1() in Inter1
        void m1()
             ^
  attempting to assign weaker access privileges; was public
1 error*/

interface Inter1
{
	void m1();
	public abstract void m2();
	int A=10;
	public final static int B=20;
}
class Hello implements Inter1
{	// if a class implements interface then it must override all method of interface or make itself as abstract.

	void m1() //m1() in Hello cannot implement m1() in Inter1, attempting to assign weaker access privileges; was public
	{
		System.out.println("Hello ->m1()");
	}
	public void m2()
	{
		System.out.println("Hello ->m2()");
	}	
}

class Lab963
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");	
	}
}