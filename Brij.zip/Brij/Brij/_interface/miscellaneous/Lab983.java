/*Lab983.java:7: error: incomparable types: A and E
                System.out.println(aobj == eobj);
                                        ^
1 error*/

class Lab983
{
	public static void main(String[] args)
	{
		A aobj =new D();	// subclass object ref can be stored in super class ref var aobj, because it in inheritance relationship.
		E eobj =new E();
		System.out.println(aobj == eobj); //comparasion is possible only when class have inheritance relationship.
		
		B bobj =new B();
		C cobj =new C();
			 
		System.out.println(aobj == cobj);	 
	}
}