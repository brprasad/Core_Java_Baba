interface Inter1{}
class A implements Inter1{}
class B extends A{}
class C extends A{}

class Lab988
{
	public static void main(String[] args)
	{
		Inter1 []arr = new A[3]; //creating array of type A just like creating array of type int.
		arr[0]=new A();	//	A class type array can hold A type object .
		arr[1]=new B();	//	A class type array can hold B type object because of inheritance relation B is subclass of A .
		arr[2]=new C();	//	A class type array can hold C type object because of inheritance relation C is subclass of A .
		
		for(int i=0; i<arr.length; i++)
			System.out.println(arr[i]);
	}
}