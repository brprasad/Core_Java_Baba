interface Inter1{}
class A implements Inter1{}
class B extends A{}
class C extends A{}

class Lab990
{
	public static void main(String[] args)
	{
		Inter1 []arr= new B[3]; 	//creating array of type B just like creating array of type int.
		arr[0]=new B();		//B@12fkj
		arr[1]=new B();		//B@sdjf9
		arr[2]=new B();		//B@jksfh
		
		for(int i=0; i<arr.length; i++)
			System.out.println(arr[i]);
	}
}