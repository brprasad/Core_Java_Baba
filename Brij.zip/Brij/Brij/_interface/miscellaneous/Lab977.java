/*Exception in thread "main" java.lang.ClassCastException: D cannot be cast to C
        at Lab977.main(Lab977.java:12)
*/

// compile successfully but at runtime give ClassCastException error.

class Lab977
{
	public static void main(String[] args)
	{
		A aobj =new D();	// subclass object ref can be stored in super class ref var aobj, because it in inheritance relationship.
		C cobj =(C)aobj;	// super class ref var aobj can't be stored in subclass type ref variable cobj by Downcasting
							// because aobj contain subclass(D) Object ref in it and D class is non-subclass of C.
		System.out.println("Hello Guys");							
		
	}
}