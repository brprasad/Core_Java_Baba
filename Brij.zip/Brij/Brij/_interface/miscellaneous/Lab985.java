/*Lab985.java:28: error: cannot find symbol
                inter1.m2();
                      ^
  symbol:   method m2()
  location: variable inter1 of type Inter1
1 error*/

interface Inter1
{
	void m1();
}
class Hello implements Inter1
{
	public void m1()
	{
		System.out.println("Hello-> m1");
	}
	public void m2()
	{
		System.out.println("Hello-> m2");
	}
}
class Lab985
{
	public static void main(String[] args)
	{
		Inter1 inter1=new Hello();	// Ref declaration of interface and abstract class is possible
		inter1.m2();	// if methods are called with interface type ref var then method sign must be present in that interface.
	}
}