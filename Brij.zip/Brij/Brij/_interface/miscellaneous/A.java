class A{}
class B extends A{}
class C extends A{}
class D extends B{}
class E{}

