/*Lab975.java:7: error: incompatible types
                B bobj =aobj;
                        ^
  required: B
  found:    A
Lab975.java:8: error: incompatible types
                D dobj1=aobj;
                        ^
  required: D
  found:    A
2 errors*/

class Lab975
{
	public static void main(String[] args)
	{
		D dobj =new D();
		A aobj =dobj;	// ok because subclass ref valriable dobj can be stored in super class type ref variable aobj.
		B bobj =aobj;	// super class ref variable aobj can't be stored in subclass type ref variable bobj because it is incompatible.
		D dobj1=aobj;	// super class ref variable aobj can't be stored in subclass type ref variable dobj1 because it is incompatible.
	}
}