class Lab982
{
	public static void main(String[] args)
	{
		A aobj =new D();	// subclass object ref can be stored in super class ref var aobj, because it in inheritance relationship.
		D dobj =new D();
		B bobj =new B();
		C cobj =new C();
		System.out.println(aobj == dobj);	 
		System.out.println(aobj == bobj);	 
		System.out.println(aobj == cobj);	 
 
	}
}