class Lab978
{
	public static void main(String[] args)
	{
		A aobj =new D();		// subclass object ref can be stored in super class ref var aobj, because it in inheritance relationship.
		
		if(aobj instanceof C) 	//So to avoid ClassCastException error always use instanceof operator,
		{						// instanceof is use to check wether the given ref var contain given ClassType objet or not.
			C cobj =(C)aobj;	
		}
		System.out.println("Hello Guys");	
	}
}