/*Exception in thread "main" java.lang.ArrayStoreException: C
        at Lab991.main(Lab991.java:13)
*/

interface Inter1{}
class A implements Inter1{}
class B extends A{}
class C extends A{}

class Lab991
{
	public static void main(String[] args)
	{
		Inter1 []arr= new B[3]; 	//creating array of type B just like creating array of type int.
		arr[0]=new B();		
		arr[1]=new B();		
		arr[2]=new C();	//// compile successfully but at runtime give java.lang.ArrayStoreException:C
						//	because B class type array CAN'T store B type object , B is non-subclass type of B.
		
		for(int i=0; i<arr.length; i++)
			System.out.println(arr[i]);
	}
}