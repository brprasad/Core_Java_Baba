/*Lab981.java:6: error: inconvertible types
                System.out.println(aobj instanceof E );
                                   ^
  required: E
  found:    A
1 error*/

class Lab981
{
	public static void main(String[] args)
	{
		A aobj =new D();		// subclass object ref can be stored in super class ref var aobj, because it in inheritance relationship.
		System.out.println(aobj instanceof E );	 
	}
}