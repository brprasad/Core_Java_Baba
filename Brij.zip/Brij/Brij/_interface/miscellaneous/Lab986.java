interface Inter1
{
	void m1();
}
class Hello implements Inter1
{
	public void m1()
	{
		System.out.println("Hello-> m1");
	}
	public void m2()
	{
		System.out.println("Hello-> m2");
	}
}
class Lab986
{
	public static void main(String[] args)
	{
		Inter1 inter1=new Hello();	// Ref declaration of interface and abstract class is possible
		Object obj =inter1;	// Object ref var can hold any type of ref.
		System.out.println(inter1.toString()); // toString() method return String repersentation on which mehtod is called. o/p- Hello@bc678
	}
}