class Lab980
{
	public static void main(String[] args)
	{
		A aobj =new D();		// subclass object ref can be stored in super class ref var aobj, because it in inheritance relationship.
		System.out.println(aobj instanceof A);	//true		
		System.out.println(aobj instanceof B);	//true		
		System.out.println(aobj instanceof C);	//false
		System.out.println(aobj instanceof D);	//true		
	}
}