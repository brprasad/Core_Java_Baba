class Lab976
{
	public static void main(String[] args)
	{
		D dobj =new D();
		A aobj =dobj;		// ok because subclass object dobj can be stored in super class type ref variable aobj.
		
		B bobj =(B)aobj;	// super class ref var aobj can be stored in subclass type ref variable bobj by Downcasting
							// because aobj contain subclass(D) Object ref in it and D is subclass of B.
						
		D dobj1=(D)aobj;	// super class ref var aobj can be stored in subclass type ref variable dobj1 by Downcasting
							// because aobj contain subclass(D) Object ref in it and it's compitable it D ref var dobj1. 
	}
}