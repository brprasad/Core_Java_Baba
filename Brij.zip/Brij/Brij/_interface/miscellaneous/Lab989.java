/*Exception in thread "main" java.lang.ArrayStoreException: A
        at Lab989.main(Lab989.java:13)
*/

interface Inter1{}
class A implements Inter1{}
class B extends A{}
class C extends A{}

class Lab989
{
	public static void main(String[] args)
	{
		Inter1 []arr =null;

		arr= new B[3]; 	//creating array of type B just like creating array of type int.
		arr[0]=new A();	// compile successfully but at runtime give java.lang.ArrayStoreException:A
						//	because B class type array CAN'T store A type object , A is super type of B.
		
		for(int i=0; i<arr.length; i++)
			System.out.println(arr[i]);
	}
}