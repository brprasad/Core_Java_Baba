/*Inter1.java:1: error: interface expected here
interface Inter1 extends Object{}
                         ^
1 error*/

interface Inter1 extends Object{}	//rule: interface can't extends class.


/********* 
Object : important properties:-
1) default super class for all java types.
2) Object class ref var can hold any class type ref i.e (class, interface, enum, array, annotation).
3) Any ref can invoke the methods of Object class.
*********/