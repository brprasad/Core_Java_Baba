class Lab979
{
	public static void main(String[] args)
	{
		A aobj =new D();		// subclass object ref can be stored in super class ref var aobj, because it in inheritance relationship.
		E cobj =(E)aobj;	
		System.out.println("Hello Guys");	
	}
}