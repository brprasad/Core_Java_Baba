class Hello implements Inter1, Inter2
{	// if a class implements interface then it must override all method of interface or make itself as abstract.

	public void m1() 
	{
		System.out.println("Hello ->m1()");
	}
	public void m2() 
	{
		System.out.println("Hello ->m2()");
	}
	public void m3() 
	{
		System.out.println("Hello ->m3()");
		System.out.println(B);
		System.out.println(C);
		
	}
}
class Lab967
{
	public static void main(String[] args)
	{
		Hello hello =new Hello();
		hello.m1();
		hello.m2();
		hello.m3();
	}
}