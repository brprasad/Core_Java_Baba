interface Inter2
{
	void m2();
	void m3();
	int A=11;
	int C=30;
	
}
