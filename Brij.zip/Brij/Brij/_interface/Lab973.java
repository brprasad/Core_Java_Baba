/*Lab973.java:21: error: method show() is already defined in class C
        public int show(){}
                   ^
Lab973.java:18: error: C is not abstract and does not override abstract method show() in Inter2
class C implements Inter1,Inter2
^
Lab973.java:20: error: show() in C cannot implement show() in Inter2
        public void show(){}
                    ^
  return type void is not compatible with int
3 errors*/

// Limintation of Multiple Inheritance 
interface Inter1
{
	void show();
}
interface Inter2
{
	int show();
}

class A implements Inter1 
{
	public void show(){}
}
class B implements Inter2
{
	public int show(){	return 0; }
}
class C implements Inter1,Inter2
{
	public void show(){}	//	compiler don't check method returntype during compilation process 
	public int show(){}		//	so both method is same for compiler i.e why compiler give error.
}

