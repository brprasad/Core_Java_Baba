/*
Inter.java:3: error: <identifier> expected
        Inter1(){}
              ^
Inter.java:4: error: illegal start of type
        {
        ^
Inter.java:5: error: = expected
                System.out.println("Inter1 I.B");
                ^
Inter.java:5: error: ';' expected
                System.out.println("Inter1 I.B");
                      ^
Inter.java:5: error: <identifier> expected
                System.out.println("Inter1 I.B");
                                  ^
Inter.java:5: error: illegal start of type
                System.out.println("Inter1 I.B");
                                   ^
Inter.java:7: error: class, interface, or enum expected
        static{
              ^
Inter.java:9: error: class, interface, or enum expected
        }
        ^
8 errors*/
interface Inter1
{
	Inter1(){} //we can't create constructor of interface because we can't instantiate interface.
	
	{	//we can't place instance block in interface.
		System.out.println("Inter1 I.B");
	}
	static{	//we can't place static block in interface.
		System.out.println("Inter1 S.B");
	}

}
