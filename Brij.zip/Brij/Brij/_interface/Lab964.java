interface Inter1
{
	void m1();
	public abstract void m2();
	int A=10;
	public final static int B=20;
}
class Hello implements Inter1
{	// if a class implements interface then it must override all method of interface or make itself as abstract.

	public void m1() 
	{
		System.out.println("Hello ->m1()"+A);
	}
	public void m2()
	{
		System.out.println("Hello ->m2()"+B);
	}	
}

class Lab964
{
	public static void main(String[] args)
	{
		Inter1 inter1=null;	//creating ref variable of Interface , allowed by rule of dynamic dispatch.
		//inter1 =new Inter1(); // Inter1 is abstract; cannot be instantiated.
		inter1=new Hello();
		inter1.m1();
		inter1.m2();
	}
}