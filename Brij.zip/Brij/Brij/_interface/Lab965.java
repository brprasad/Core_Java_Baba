interface Inter1
{
	void m1();
	public abstract void m2();
	int A=10;
	public final static int B=20;
}
abstract class Hello implements Inter1
{	// if a class implements interface then it must override all method of interface or make itself as abstract.

	public void m1() 
	{
		System.out.println("Hello ->m1()"+A);
	}
}
class Hai extends Hello
{
	public void m2()
	{
		System.out.println("Hai ->m2()"+B);
	}	
	void m3()	// newly create method of Hai class
	{
		System.out.println("Hai ->m3()");
	}
}

class Lab965
{
	public static void main(String[] args)
	{
		Inter1 inter1=null;	//creating ref variable of Interface , allowed by rule of dynamic dispatch.
		inter1=new Hai();
		inter1.m1();	// output - Hello ->m1()10 
		inter1.m2();	// 			Hello ->m2()20
		//inter1.m3(); 
		/*Lab965.java:36: error: cannot find symbol
                inter1.m3();
                      ^
		symbol:   method m3()
		location: variable inter1 of type Inter1
		1 error*/

	}
}