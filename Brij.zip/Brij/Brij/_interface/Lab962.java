interface Inter1
{
	void m1();
	public abstract void m2();
	int A=10;
	public final static int B=20;
}
abstract class Hello implements Inter1{}	// if a class implements interface then it must override all method of interface 
											// or make itself as abstract.

class Lab962
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");	// output is Hello Guys
	}
}