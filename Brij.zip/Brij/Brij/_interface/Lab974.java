/*Lab974.java:15: error: show() in B cannot override show() in A
        public void show(){     }
                    ^
  overridden method is static
1 error*/

//Limitation of Mulitple Inheritance 
interface Inter1
{
	void show();
}

class A 
{
	public static void show()
	{
		System.out.println("show method");
	}
}
class B extends A implements Inter1
{
	public void show(){} //show() in B implemented interface Inter1 method and method of class A is not overridden bucause it is static.
	
}

