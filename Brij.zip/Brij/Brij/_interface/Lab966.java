interface Inter1
{
	void m1();
	int A=10;
}
interface Inter2
{
	void m2();
	int B=20;
}
class Hello implements Inter1, Inter2
{	// if a class implements interface then it must override all method of interface or make itself as abstract.

	public void m1() 
	{
		System.out.println("Hello ->m1()");
	}
	public void m2() 
	{
		System.out.println("Hello ->m2()");
	}
}
class Lab966
{
	public static void main(String[] args)
	{
		Hello hello =new Hello();
		System.out.println(hello.A);
		System.out.println(hello.B);
		hello.m1();
		hello.m2();
	}
}