/*Lab961.java:8: error: Hello is not abstract and does not override abstract method m2() in Inter1
class Hello implements Inter1{}
^
1 error*/

interface Inter1
{
	void m1();
	public abstract void m2();
	int A=10;
	public final static int B=20;
}
class Hello implements Inter1{}	// if a class implements interface then it must override all method of interface 
								// or make itself as abstract.

class Lab961
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");
	}
}