package lab1039;

public class Lab1039 {
	public static void main(String[] args) {
		Student stu1=new Student(99,"Sri");
		Student stu2=new Student(99,"Sri");
		Student stu3=new Student(88,"Manish");
		Student stu4=stu1;
		System.out.println("using == operator");
// when you compare primitive type variable using == operator then it will compare the value available in primitive variables.
// when you compare ref type variable using == operator then it will compare the address available in ref variables.
		System.out.println(stu1 == stu2); // false because == operator compare address in case of ref type variables  
		System.out.println(stu1 == stu3); // false
		System.out.println(stu1 == stu4); // true
		System.out.println(stu2 == stu3); // false
				
		System.out.println("using equals() method");
// Object class equals() method will always compare the address of two objects.
// you can override equals() method in your class when you want to compare content of two objects.	
// usually equals() method is overridden in many java built-in class to compare contents of objects.
		System.out.println(stu1.equals(stu2)); //true because Student class overridden equals() method 
		System.out.println(stu1.equals(stu3)); //false
		System.out.println(stu1.equals(stu4)); //true
		System.out.println(stu2.equals(stu3)); //false
	}
}

class Student
{
	int sid ;
	String name;
	public Student(int sid, String name) {
		// TODO Auto-generated constructor stub
		this.sid=sid;
		this.name=name;
	}
	public boolean equals(Object obj) //Student class equals() method overridden Object class equals() method.
	{
		if(obj instanceof Student)
		{
			Student st=(Student)obj;
			return this.sid==st.sid && this.name.equals(st.name); // here equals() method of String class is called which compare strings character one by one. 
		}
		return false;
	}
}


