package lab1040;

class Hai
{
	int x;
	public Hai(int x) {
		// TODO Auto-generated constructor stub
		this.x=x;
	}
}
class Hello implements Cloneable
{
	int y;
	Hai hai;
	public Hello(int y, Hai hai) {
		// TODO Auto-generated constructor stub
		this.y=y;
		this.hai=hai;	
	}
	void show()
	{
		System.out.println("Hello -> y : "+y);
		System.out.println("Hai -> hai :"+hai.x);
	}
	public Object clone() throws CloneNotSupportedException {
		return super.clone();		
	}
}
public class Lab1040 {
	public static void main(String[] args) throws CloneNotSupportedException{
		Hai hai=new Hai(10);
		Hello hello1 =new Hello(20, hai);
		Hello hello2=(Hello)hello1.clone(); // creating clone or copy of hello1 object.
		hello1.show();
		hello2.show();
		System.out.println(hello1==hello2); // false because both object have different address.
		System.out.println(hello1.hai==hello2.hai); //true because both member object ref sharing same address of hai object .
		
		hello2.y=30;	//modifying the data of cloned object so it will not affect the actual object.
		hello1.show();
		hello2.show();
		
		hello2.hai.x=111;//modifying the data of the member object so it will affect the other objects also.
					     //because they are pointing to the same member object .
		hello1.show();
		hello2.show();
		
		
		
	}
	
}
