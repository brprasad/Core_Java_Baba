package lab1035;

public class Lab1035 {

public static void main(String[] args) {
		
		Student stu1=new Student(99,"Sri");
		System.out.println(stu1);  // lab1035.Student@150bd4d
		System.out.println("Default implementation of toString() in Object class");
		String cname=stu1.getClass().getName();
		int hc=stu1.hashCode();
		String hx=Integer.toHexString(hc);
		String msg = cname+"@"+hx;
		System.out.println(msg);   // lab1035.Student@150bd4d
		
	}
}
 class Student 
 {
	 int sid;
	 String name;
	 public Student(int sid, String name) {
		// TODO Auto-generated constructor stub
		 this.sid=sid;
		 this.name =name;
	}
 }