package lab1049;

class Student
{
		String sid;
		public Student(String sid) {
			// TODO Auto-generated constructor stub
			this.sid=sid;
			System.out.println("Object Created with id: "+sid);
		}
		protected void finalize()
		{
			System.out.println("finalize :"+sid);
		}
}
public class Lab1049 {
	public static void main(String[] args) {
		Student st=new Student("Jlc-001");
		new Student("jlc-002");
		System.runFinalizersOnExit(true);
		System.out.println("Main Completed");
	}
}
