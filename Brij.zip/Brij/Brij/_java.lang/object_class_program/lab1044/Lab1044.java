package lab1044;

public class Lab1044 {
	public static void main(String[] args) {
		Hello h1=new Hello(10);
		Hello h2=h1.clone();
		System.out.println(h1==h2);	//false
		System.out.println(h1.a);	//10
		System.out.println(h2.a);	//10
	}
}
class Hello
{
	int a;
	public Hello(int a) {
		// TODO Auto-generated constructor stub
		this.a=a;
	}
	public Hello clone()
	{
		return new Hello(this.a);
	}
}
