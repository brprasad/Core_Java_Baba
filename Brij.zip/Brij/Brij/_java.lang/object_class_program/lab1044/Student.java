package lab1044;

public class Student implements Cloneable {
	int sid;
	public Student(int sid) {
		// TODO Auto-generated constructor stub
		this.sid=sid;
	}
	public static void main(String[] args) throws Exception {
		Student stu1=new Student(99);
		Student stu2=(Student)stu1.clone();
		System.out.println(stu1==stu2);
		System.out.println(stu1.sid);
		System.out.println(stu2.sid);
		
	}
}
