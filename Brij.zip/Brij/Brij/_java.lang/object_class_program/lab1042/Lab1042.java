/*Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
	The method clone() from the type Object is not visible because it is protected access.

	at lab1042.Lab1042.main(Lab1042.java:12)
*/
package lab1042;

public class Lab1042
{
	public static void main(String[] args) {
		Object obj1 =new Object();
		Object obj2=obj1.clone();
		System.out.println(obj2==obj1);
	}
}