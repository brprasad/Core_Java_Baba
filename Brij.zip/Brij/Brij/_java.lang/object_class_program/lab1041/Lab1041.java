package lab1041;

	class Hai
	{
		int x;
		public Hai(int x) {
			// TODO Auto-generated constructor stub
			this.x=x;
		}
	}
	class Hello implements Cloneable
	{
		int y;
		Hai hai;
		public Hello(int y, Hai hai) {
			// TODO Auto-generated constructor stub
			this.y=y;
			this.hai=hai;	
		}
		void show()
		{
			System.out.println("Hello -> y : "+y);
			System.out.println("Hai -> hai :"+hai.x);
		}
		public Object clone() throws CloneNotSupportedException {
			if(this instanceof Cloneable)
			{
				Hai hai=new Hai(this.hai.x);
				Hello hello1=new Hello(this.y, hai);
				return hello1;
			}
			else 			
			   new CloneNotSupportedException(getClass().getName());
			
			return false;
		}
	}
	public class Lab1041 {
		public static void main(String[] args) throws CloneNotSupportedException{
			Hai hai=new Hai(10);
			Hello hello1 =new Hello(20, hai);
			Hello hello2=(Hello)hello1.clone(); // creating clone or copy of hello1 object.
			
			System.out.println(hello1==hello2); // false because both object have different address.
			System.out.println(hello1.hai==hello2.hai); //false because both member object have different address  .
			
			hello2.y=11;	//modifying the data of cloned object so it will not affect the actual object.
			hello1.show();
			hello2.show();
			
			hello2.hai.x=22;//modifying the data of the member object so it will not affect the other member objects also.
						     //because they are pointing to the different member object .
			hello1.show();
			hello2.show();
			
			
			
		}
		
	}


