package lab1036;

public class Lab1036 {
public static void main(String[] args) {
		
		Student stu1=new Student(99,"Sri");
		Student stu2=new Student(88,"Nivas");
		System.out.println(stu1);
		System.out.println(stu2);  
					
	}
}
 class Student 
 {
	 int sid;
	 String name;
	 public Student(int sid, String name) {
		// TODO Auto-generated constructor stub
		 this.sid=sid;
		 this.name =name;
	}
	public String toString() //overridden toString() method of Object class. 
	{
		return sid+"\t"+name;
	}
 }

