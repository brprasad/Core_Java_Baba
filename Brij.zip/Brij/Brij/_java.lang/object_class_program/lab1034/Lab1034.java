package lab1034;

public class Lab1034 {
	public static void main(String[] args) {
		
		Student stu1=null;
		System.out.println(stu1);//null
		stu1=new Student(99,"Sri");
		System.out.println(stu1);//toString() method of Object class return <Classname>@<HexadecimalofhashCode> 
								 // o/p is lab1034.Student@dc8569
		String str=new String("Java Learning Center");
		System.out.println(str);//toString() method is Overridden in String class return actual data/content
								// o/p is Java Learning Center
		Integer ref=new Integer(123);
		System.out.println(ref);//toString() method is Overridden in Integer class return actual data/content
								// o/p is 123
	}
}
 class Student 
 {
	 int sid;
	 String name;
	 public Student(int sid, String name) {
		// TODO Auto-generated constructor stub
		 this.sid=sid;
		 this.name =name;
	}
 }