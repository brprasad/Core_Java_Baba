package lab1045;

public class Lab1045 {
	public static void main(String[] args) {
		System.out.println("main started");
		Runtime rt=Runtime.getRuntime();
		System.out.println("Total memory"+rt.totalMemory());
		System.out.println("Memory used :"+((rt.totalMemory())-(rt.freeMemory())));
		System.out.println("free memory"+rt.freeMemory());
		System.out.println("Max memory"+rt.maxMemory());
		
	}
}
