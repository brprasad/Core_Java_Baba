package lab1033;

public class Lab1033 {
	public static void main(String[] args) {
		System.out.println("\n ***With Employee");
		Employee emp1=new Employee(63, 13);
		Employee emp2=new Employee(63, 13);
		Employee emp3=new Employee(88, 65799999);
		Employee emp4=emp1;
		
		System.out.println(emp1.hashCode());
		System.out.println(emp2.hashCode());
		System.out.println(emp3.hashCode());
		System.out.println(emp4.hashCode());
		 
		System.out.println(emp1==emp2); // == operator compare the address of object not hashCode i.e why give false.
		System.out.println(emp1==emp3); // == operator compare the address of object not hashCode i.e why give false.
		System.out.println(emp1==emp4); // == operator compare the address of object not hashCode i.e why give false.
		System.out.println(emp3==emp4); // == operator compare the address of object not hashCode 
										// and because emp3, emp4 contain same object address i.e why give true .
	}
}
 class Employee 
 {
	 int eid;
	 long phone;
	 public Employee(int eid, long phone) {
		 this.eid=eid;
		 this.phone=phone;
	}
	public int hashCode() //overriding hashCode() method of Object class. 
	{
		return (int)(phone | eid>>1  );
	}
 }