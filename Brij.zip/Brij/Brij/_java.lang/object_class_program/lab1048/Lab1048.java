package lab1048;

class Student
{
		int sid;
		public Student(int sid) {
			// TODO Auto-generated constructor stub
			this.sid=sid;
		}
		protected void finalize()
		{
			System.out.println("finalize :"+sid);
		}
}
public class Lab1048 {
	public static void main(String[] args) {
		Student st=new Student(88);
		st.finalize();	// only release the resource, so it is eligible for gc
						//but it depend on gc thread that when it clean that unused object.
		System.out.println("sid :"+st.sid);
	}
}
