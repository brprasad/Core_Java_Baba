/*Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
	The method clone() from the type Object is not visible because it is protected access.

	at lab1043.Lab1043.main(Lab1043.java:11)
*/
package lab1043;

public class Lab1043 {
public static void main(String[] args) {
	Student stu1=new Student();
	Student stu2=(Student)stu1.clone();
	System.out.println(stu1==stu2);
	
}
}
class Student{}