package lab1047;

class Employee
{
	String eid;
	double []add =new double[123456];
	
	public Employee(String eid) {
		// TODO Auto-generated constructor stub
		this.eid=eid;
		System.out.println("\n Object created with id :"+eid);
	}
	protected void finalize() {
		System.out.println("finalize  : "+eid);
		
	}
}
public class Lab1047 {
	public static void main(String[] args) {
		Employee emp[]=new Employee[500];
		for (int i = 0; i < emp.length; i++) {
			//new Employee("jlc"+(i+1)); // after each loop object is unrefered or unused so gc is called by jvm. 
			emp[i]=new Employee("jlc"+(i+1)); 	// but in this statement we are storing each object so no object is unused 
												//so after some time jvm heap memory is full so it will throw java.lang.OutofMemoryError.
		}
	}
}
