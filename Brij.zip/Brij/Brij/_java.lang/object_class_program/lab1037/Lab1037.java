package lab1037;

public class Lab1037 {
	public static void main(String[] args) {
		String str1=new String("Sri");
		String str2=new String("Sri");
		String str3=new String("dande");
		System.out.println("using == operator");
// when you compare primitive type variable using == operator then it will compare the value available in primitive variables.
// when you compare ref type variable using == operator then it will compare the address available in ref variables.
		System.out.println(str1 == str2); // false because ref variable have different address.
		System.out.println(str1 == str3); // false because ref variable have different address.
		
		System.out.println("using equals() method");
// Object class equals() method will always compare the address of two objects.
// you can override equals() method in your class when you want to compare content of two objects.	
		System.out.println(str1.equals(str2)); 	// true because str1 and str2 content are same values. 
											   	// equals() method is overridden in java.lang.String class
												
		System.out.println(str1.equals(str3));  // false because str1 and str3 content different values
												// equals() method is overridden in java.lang.String class
	}									
}
