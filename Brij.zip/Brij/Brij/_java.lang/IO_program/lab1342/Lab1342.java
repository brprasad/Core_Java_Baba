package lab1342;

import java.io.File; 
import javax.swing.filechooser.FileFilter;

public class Lab1342 {
	public static void main(String[] args) {
		File file = new File("D:\\java techmentro");
		File javafiles[] = file.listFiles(new ExtFilter(".class"));
		System.out.println(".class Files");
		if(javafiles!=null)
			for (File f : javafiles) {
				System.out.println(f);
			}
		else
			System.out.println("No Java File found");
	}
}
class ExtFilter implements java.io.FileFilter{
	
	String ext;
	public ExtFilter(String ext) {
		this.ext=ext;
	}
	@Override 
	public boolean accept(File file) {
		return file.getName().endsWith(ext);
	}
}