package lab1341;

import java.io.File;
import java.util.Iterator;

public class Lab1341 {
	public static void main(String[] args) {
		File file =new File("D:\\java techmentro");
		File files[] = file.listFiles();
		for (File f : files) {
			System.out.println(f+" is file :"+f.isFile()+", is Directory :"+f.isDirectory());
			// isFile() - Return :true if and only if the file denoted by this abstract pathname exists and is a normal file; false otherwise
			// isDirectory() - Return :true if and only if the file denoted by this abstract pathname exists and is a directory; false otherwise

		}
	}
}
