package lab1335;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

public class Lab1335 {
	public static void main(String[] args) throws FileNotFoundException {
		try(FileInputStream fis=new FileInputStream("d:\\abc.txt");
				//A FileInputStream obtains input bytes from a file in a file system.
				//FileInputStream is meant for reading streams of raw bytes such as image data
	 
				InputStreamReader isr=new InputStreamReader(fis);
				//An InputStreamReader is a bridge from byte streams to character streams: 
				//It reads bytes and decodes them into characters using a specified charset
				
				BufferedReader br=new BufferedReader(isr)){
				//Reads text from a character-input stream, buffering characters so as to provide for the efficient reading of characters, arrays, and lines.
			while(true){
				String id=br.readLine();
				if(id==null)
					break;
				System.out.println(id);
			}
			
		} catch (Exception e) {e.printStackTrace();		}
	}
}
