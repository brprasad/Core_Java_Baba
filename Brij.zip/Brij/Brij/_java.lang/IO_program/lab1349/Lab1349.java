package lab1349;

import java.io.*;

import javax.imageio.stream.FileImageOutputStream;

public class Lab1349 {
	public static void main(String[] args) throws IOException {
			File f = new File("sri\\jlc\\io");
			f.mkdirs();
			File f1 = new File(f,"jlc.txt");
			System.out.println("Name of the File: "+f1.getName());
			System.out.println("Before Creating the file checking that is file exists : "+f1.exists());
			f1.createNewFile();
			System.out.println("File hai.txt is created in sri\\jlc\\io");
			System.out.println("Absolute Path :"+f1.getAbsolutePath());
			System.out.println("Parent "+f1.getParent());
			System.out.println("Path :"+f1.getPath());
			System.out.println("After Creating the file checking that is file exists : "+f1.exists());
			System.out.println("f1.canRead() \t"+f1.canRead());
			System.out.println("f1.canWrite() \t"+f1.canWrite());
			f1.setReadOnly();
			System.out.println("Marked Read only");
			System.out.println("f1.canRead() \t"+f1.canRead());
			System.out.println("f1.canWrite() \t"+f1.canWrite());
			
			File f2 = new File("Hello.txt");
			f2.createNewFile();
			System.out.println("Absolute Path :"+f2.getAbsolutePath());
			System.out.println("Parent "+f2.getParent());
			System.out.println("Path :"+f2.getPath());	
	
	}
}
