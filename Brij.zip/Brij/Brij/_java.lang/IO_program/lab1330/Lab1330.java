package lab1330;

import java.io.IOException;

public class Lab1330 {
	public static void main(String[] args) throws IOException {
		System.out.println("Enter data and press * to Exit");
		int count=0;
		while (true) {
			int asc=System.in.read();
			System.out.println(++count +"\t"+ asc + "\t" +(char)asc);
			if(asc=='*')
				break;
		}
		System.out.println("\n After LOOP ");
		while (true) {
			int asc=System.in.read();
			System.out.println(++count +"\t"+ asc + "\t" +(char)asc);
			if(asc==10)
				break;
		}
	}
}
