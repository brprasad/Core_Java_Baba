package lab1338;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.InputStreamReader;

public class Lab1338 {
	public static void main(String[] args) {
		try(InputStreamReader isr = new InputStreamReader(System.in);
				BufferedReader br = new BufferedReader(isr);
			FileWriter fw = new FileWriter("D:\\xyz.txt", true);
				BufferedWriter bw = new BufferedWriter(fw);
				)
				{
					char ch='Y';
					do {
						System.out.println("Enter Id :");
						String id=br.readLine();
						System.out.println("Enter Name :");
						String name=br.readLine();
						String info = id+"\t"+name;
						bw.write(info);
						bw.newLine();
						
						System.out.println("Do you want to add more : Y/N");
						ch=(char)br.readLine().charAt(0);
					} while (ch =='Y');
					bw.close();
		} catch (Exception e) {e.printStackTrace();	}
	}
}
