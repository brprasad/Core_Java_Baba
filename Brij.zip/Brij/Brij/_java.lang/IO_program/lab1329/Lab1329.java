package lab1329;

import java.io.IOException;

public class Lab1329 {
	public static void main(String[] args) throws IOException {
		System.out.println("Enter 1st character :");  	//when you read from keyword then apart from actual data when you press ENTER then
		int var1=System.in.read();						// some extra ascii value will be stored in the buffer.
		System.out.println(var1+"\t "+(char)var1);		// 13 for \r character(Move the cursor to beginning of the current line)
		System.out.println("Enter 2nd character :");	// 10 for \n character(Move the cursor to the next line)
		int var2=System.in.read();						// when you create the string from those data then you need to ignore the extra ascii value.
		System.out.println(var2+"\t "+(char)var2);
		System.out.println("Enter 3rd character :");
		int var3=System.in.read();
		System.out.println(var3+"\t "+(char)var3);
				
	}
}
