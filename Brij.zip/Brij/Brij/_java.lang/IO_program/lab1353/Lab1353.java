package lab1353;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Lab1353 {	//transient Keyword 
	
	public static void main(String[] args) {
		try(FileOutputStream fos = new FileOutputStream("D:\\info.ser");
				ObjectOutputStream oos = new ObjectOutputStream(fos);) {
			Student st = new Student(99, "Sri", 88888888L);
			Student.count=9;
			System.out.println(st);
			oos.writeObject(st);
			System.out.println("Object Serializied");
			
		} catch (Exception e) {e.printStackTrace();}
	}
} 

class Student implements Serializable {
	
	int sid;
	transient String name = "XXXX"; 
	long phone = 333333L;
	static int count=3;
	public Student(int sid, String name, long phone) {
		this.sid = sid;
		this.name = name;
		this.phone = phone;
	}  
	@Override
	public String toString() {
		return sid+"\t"+name+"\t"+phone+"\t"+count;
	}
	
}