package lab1333;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

public class Lab1333 {
	public static void main(String[] args) {
		try (FileInputStream fis =new FileInputStream("D:\\abc.txt");
				BufferedInputStream bis=new BufferedInputStream(fis)){
			//A FileInputStream obtains input bytes from a file in a file system.
			//FileInputStream is meant for reading streams of raw bytes such as image data
 
			while(true){
				int asc=bis.read(); //Return: the next byte of data, or -1 if the end of the stream is reached.
				if(asc==-1)
					break; 
				char ch=(char)asc;
				System.out.print(ch);
			}
		} catch (Exception e) {e.printStackTrace();}
	}
}

  