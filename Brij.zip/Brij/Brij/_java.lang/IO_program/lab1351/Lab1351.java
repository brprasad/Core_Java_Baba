package lab1351;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import lab1350.Lab1350;

public class Lab1351 {
	public static void main(String[] args) {
		try(FileInputStream fis = new FileInputStream("D:\\info.ser");
				ObjectInputStream ois = new ObjectInputStream(fis);) {
			
					Object o=ois.readObject();
					System.out.println(o);
					System.out.println("Object Deserialized");
		} catch (Exception e) {e.printStackTrace();	}
	}
} 