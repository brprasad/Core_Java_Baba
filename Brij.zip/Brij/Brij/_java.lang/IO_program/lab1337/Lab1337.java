package lab1337;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class Lab1337 {
	public static void main(String[] args) {
		try(FileReader fr = new FileReader("D:\\abc.txt");
				BufferedReader br = new BufferedReader(fr);
			FileWriter fw = new FileWriter("D:\\xyz.txt");
				BufferedWriter bw = new BufferedWriter(fw);){
					while(true){
						String st=br.readLine();
							if(st==null)
								break;
							bw.write(st);
							bw.newLine();
					}
					bw.close();
					System.out.println("Writing Completed.. ");
		} catch (Exception e) {e.printStackTrace();	}
	}
}
