package lab1332;

import java.io.BufferedInputStream;

public class Lab1332 {
	public static void main(String[] args) {
		System.out.println("Enter Data :");
		try (BufferedInputStream bis =new BufferedInputStream(System.in);){ 
			//When the BufferedInputStream is created, an internal buffer array is created.
			//As bytes from the stream are read or skipped, the internal buffer is refilled
			//as necessary from the contained input stream, many bytes at a time.
			while(true){
				int asc=bis.read(); //Return: the next byte of data, or -1 if the end of the stream is reached.
				if(asc==13)
					break;
				char ch=(char)asc;
				System.out.print(ch);
			}
		} catch (Exception e) {e.printStackTrace();}
	}
}
