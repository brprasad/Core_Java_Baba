package lab1345;

import java.io.File;

public class Lab1345 {  
	public static void main(String[] args) {
		System.out.println("File.path.separator: \t"+File.pathSeparator);
		System.out.println("File.path.separator: \t"+File.pathSeparatorChar);
		System.out.println("File.separator: \t"+File.separator);
		System.out.println("File.separator: \t"+File.separatorChar);
	}
}
