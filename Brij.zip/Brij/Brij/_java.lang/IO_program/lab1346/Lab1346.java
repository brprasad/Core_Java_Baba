package lab1346;

import java.io.File;

public class Lab1346 {
	public static void main(String[] args) {
		File far[] = File.listRoots();// List the available filesystem roots. 
		// A particular Java platform may support zero or more hierarchically-organized file systems.
		// Each file system has a root directory from which all other files in that file system can be reached.
		// Windows platforms, for example, have a root directory for each active drive;
		// UNIX platforms have a single root directory, namely "/".
 
		System.out.println(far.length);
		System.out.println("FileName\t isDirectory\t isFile\t   isAbsolute\t    getPath");
		for (int i = 0; i < far.length; i++) {
			System.out.println(far[i]+"\t\t"+far[i].isDirectory()+"\t\t"+far[i].isFile()+"\t\t"+far[i].isAbsolute()+"\t\t"+far[i].getPath());
		}
	}   
}     
                