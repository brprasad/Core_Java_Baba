package lab1334;

import java.io.BufferedReader;
import java.io.InputStreamReader; 

public class Lab1334 {
	public static void main(String[] args) {
		try(InputStreamReader isr=new InputStreamReader(System.in);
				//An InputStreamReader is a bridge from byte streams to character streams: 
				//It reads bytes and decodes them into characters using a specified charset

				BufferedReader br=new BufferedReader(isr)){
				//Reads text from a character-input stream, buffering characters so as to provide for the efficient reading of characters, arrays, and lines. 
				
					System.out.println("Enter Id :");
					String id=br.readLine();
					System.out.println("Enter Name :");
					String name=br.readLine();
					System.out.println(id+"\t"+name);
			
		} catch (Exception e) {e.printStackTrace();		}
	}
}
