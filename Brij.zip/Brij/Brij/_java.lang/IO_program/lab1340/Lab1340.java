package lab1340;

import java.io.File;

public class Lab1340 {
	public static void main(String[] args) {
		File drives[] = File.listRoots(); // List the available filesystem roots. 
		// A particular Java platform may support zero or more hierarchically-organized file systems.
		// Each file system has a root directory from which all other files in that file system can be reached.
		// Windows platforms, for example, have a root directory for each active drive;
		// UNIX platforms have a single root directory, namely "/".

		for (File file : drives) {
			long total = file.getTotalSpace()/1024/1024/1024;	// return - Returns the size of the partition named by this abstract pathname.
			long usable = file.getUsableSpace()/1024/1024/1024; // return -The number of available bytes on the partition.
																// On systems where this information is not available, this method will be equivalent to a call to getFreeSpace().
			long diskOccupied  = total-usable;
			String driveName = file.getPath();
			System.out.println("Drive Name :"+driveName+"\t Total Memory :"+total+"\t Usable Memory :"+usable+"\t Occupied DiskMemory  :"+diskOccupied);
		}
	} 
}
 