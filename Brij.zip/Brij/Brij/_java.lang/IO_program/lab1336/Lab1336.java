package lab1336;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Lab1336 {
	public static void main(String[] args) {
		try (FileInputStream fis = new FileInputStream("D:\\abc.txt");
				FileOutputStream fos = new FileOutputStream("D:\\xyz.txt");){
				
				while(true){
					int asc=fis.read();
					if(asc==-1)
						break;
					fos.write(asc);
					//Writes the specified byte to this file output stream. Implements the write method of OutputStream.
				}
				System.out.println("Writing Completed");
			
		} catch (Exception e) {e.printStackTrace();		}
	}
}
