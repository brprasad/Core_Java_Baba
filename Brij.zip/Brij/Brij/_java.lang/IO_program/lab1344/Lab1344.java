package lab1344;

import java.io.File;
import java.io.IOException;

public class Lab1344 {
	public static void main(String[] args) throws IOException {
		File file = new File("D:\\abc1.txt");
	 	System.out.println("FILE found :"+file.exists());  //Returns: true if and only if the file or directory denoted by this abstract pathname exists; false otherwise
		file.createNewFile(); //return :true if the named file does not exist and was successfully created; false if the named file already exists
		System.out.println("FILE found :"+file.exists());  //Returns: true if and only if the file or directory denoted by this abstract pathname exists; false otherwise.
		
	}
} 

 