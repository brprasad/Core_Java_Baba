package lab1339;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Lab1339 {
	public static void main(String[] args) {
		PrintWriter pw;
		try {
			pw = new PrintWriter("\\abc.txt");
			pw.print(97);
			pw.write(97);
			pw.println(10.0);
			pw.print(true);
			pw.print("JLC");
			
			pw.close();
		} catch (FileNotFoundException e){	e.printStackTrace(); }
		
	}
}
