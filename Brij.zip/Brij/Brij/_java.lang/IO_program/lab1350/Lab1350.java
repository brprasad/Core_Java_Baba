package lab1350;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


public class Lab1350 {	//serialization 
	public static void main(String[] args) {
		try(FileOutputStream fos = new FileOutputStream("D:\\info.ser");
				ObjectOutputStream oos = new ObjectOutputStream(fos);) {
			Student st = new Student(99, "Srinivas", 98989889898L);
			Student.count=9;
			System.out.println(st);
			oos.writeObject(st);
			System.out.println("Object Serializied");
			
		} catch (Exception e) {e.printStackTrace();}
	}
} 

class Student implements Serializable {
	
	int sid;
	String name; 
	long phone;
	static int count=3;
	public Student(int sid, String name, long phone) {
		this.sid = sid;
		this.name = name;
		this.phone = phone;
	}  
	@Override
	public String toString() {
		return sid+"\t"+name+"\t"+phone+"\t"+count;
	}
	
}