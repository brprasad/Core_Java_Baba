package lab1343;

import java.io.File;

public class Lab1343 {
	public static void main(String[] args) {
		File file = new File("D:\\java\\p1\\abc.txt");
	 	System.out.println("DIR found :"+file.exists()); //Returns:	true if and only if the file or directory denoted by this abstract pathname exists; false otherwise
	 	
	 	file.mkdirs();	//Returns: true if and only if the directory was created, along with all necessary parent directories; false otherwise.
		System.out.println("DIR found :"+file.exists());
	}
}
