package lab1239;

public class Lab1239 {
	public static void main(String[] args) {
		System.out.println("Main() Started");
		int r =new Hello().show();
		System.out.println("main :"+r);
		System.out.println("Main() completed");
	}
}
class Hello
{ 
	@SuppressWarnings("finally") 
	int show() // return type is int 
	{
		int a=0;
		try {
			System.out.println("try block begins :"+a);
			a=10/4;
			System.out.println("try block ends :"+a);
			return a;	//store the value of return variable(a) in temp variable before calling to finally block 
						// and after finally block execution, temp value will be returned to caller method.
			
		} catch (ArithmeticException e) {
			a=20;
			System.out.println("catch block :"+a);
			return a; 	
		}
		finally{ 
			System.out.println("finally block :"+a);
			int []arr =new int[-1]; //Exception in thread "main" java.lang.NegativeArraySizeException
									// so JVM terminate abnormally.
		}
	} 
}

