package lab1275;

public class Lab1275 {
	public static void main(String[] args) {
		int x;
		try{
			
		}finally{
			x=99;
		}
		System.out.println(x);
		 //local variable must be initialized before the use.
		 //because compiler is sure that finally block execute in any condition , so it will let you compile.
	}
}
