package lab1242;

public class Lab1242 {
	public static void main(String[] args) {
		System.out.println("st0");
		try {
			System.out.println("st1"); 
			try {
				int x=10/0;
				System.out.println("st2");
			} catch (NullPointerException e) {
				System.out.println("st3");
			}finally{
				System.out.println("st4");
			}
			System.out.println("st5");
		} catch (ArithmeticException e) {
			System.out.println("st6");
			try {
				System.out.println("st7");
			} catch (ArithmeticException e2) {
				System.out.println("st8");
			}finally{
				System.out.println("st9");
			}
			System.out.println("st10");
		}finally{
			System.out.println("st11");
			try {
				System.out.println("st12");
			} catch (ArithmeticException e2) {
				System.out.println("st13");
			}finally{
				System.out.println("st14");
			}
			System.out.println("st15");
		}
		System.out.println("st16");
	}
}
