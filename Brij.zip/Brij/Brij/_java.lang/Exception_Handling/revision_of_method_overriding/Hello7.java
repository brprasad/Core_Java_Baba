package revision_of_method_overriding;

import java.io.IOException;

public class Hello7 {
	void show()throws IOException{}	//super class method is specified with checked method level exception.
	}

class Hai7 extends Hello7{

	void show()throws Exception{} //so subclass method can't throws exception which is super to super class method exception
									//while overriding the method.
}


