package revision_of_method_overriding;

public class Hello11 {

	void show()throws ArrayIndexOutOfBoundsException{}	//super class method is specified with unchecked method level exception.
}

class Hai11 extends Hello11{

	void show() throws RuntimeException{}  //so subclass method can throws any unchecked exception while overriding the method.
}

