package revision_of_method_overriding;

public class Hello10 {

	void show()throws ArrayIndexOutOfBoundsException{}	//super class method is specified with unchecked method level exception.
}

class Hai10 extends Hello10{

	void show() throws NullPointerException{}  //so subclass method can throws any unchecked exception while overriding the method.
}

