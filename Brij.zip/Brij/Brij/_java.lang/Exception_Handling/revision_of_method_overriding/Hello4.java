package revision_of_method_overriding;

import java.io.IOException;

public class Hello4 {

	void show()throws IOException{}	//super class method is specified with checked method level exception.
}

class Hai4 extends Hello4{

	void show()throws IOException{}	 //so subclass method can throws same exception while overriding the method.
}

