package revision_of_method_overriding;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Hello6 {

	void show()throws IOException{}	//super class method is specified with checked method level exception.
}

class Hai6 extends Hello6{

	void show()throws FileNotFoundException{} //so subclass method can throws exception which is subclass to super class method exception
												//while overriding the method.
}

