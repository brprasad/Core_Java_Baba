package revision_of_method_overriding;

public class Hello12 {

	void show()throws ArrayIndexOutOfBoundsException{}	//super class method is specified with unchecked method level exception.
}

class Hai12 extends Hello12{

	void show() throws Exception{}  //so subclass method can't throws any checked exception while overriding the method.
}

