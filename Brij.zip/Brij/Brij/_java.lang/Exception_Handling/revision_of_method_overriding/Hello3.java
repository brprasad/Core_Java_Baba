package revision_of_method_overriding;

import java.io.IOException;

public class Hello3 {
	void show()throws IOException{}	//super class method is specified with checked method level exception.
}

class Hai3 extends Hello3{

	void show(){} //so subclass method can ignore exception while overriding the method.
}
