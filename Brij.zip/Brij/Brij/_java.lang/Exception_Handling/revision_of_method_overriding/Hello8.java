package revision_of_method_overriding;

import java.io.IOException;

public class Hello8 {
	void show()throws IOException{}	//super class method is specified with checked method level exception.
}

class Hai8 extends Hello8{

void show()throws ClassNotFoundException{} //so subclass method can't throws exception which is non-sub class to super class method exception
											//while overriding the method.
}
