package revision_of_method_overriding;

public class Hello2 {

	
	void show(){}	//super class method is not specified with method level exception.
}

class Hai2 extends Hello2{
	
	void show()throws CloneNotSupportedException{} //so subclass method can't throws checked exception while overriding the method
}


