package revision_of_method_overriding;

public class Hello13 {
	
	void show()throws ArrayIndexOutOfBoundsException{}	//super class method is specified with unchecked method level exception.
}

class Hai13 extends Hello13{

	void show() throws ClassNotFoundException{} //so subclass method can't throws any checked exception while overriding the method.
}

