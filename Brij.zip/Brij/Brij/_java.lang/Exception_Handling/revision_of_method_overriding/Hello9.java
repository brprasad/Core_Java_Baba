package revision_of_method_overriding;

public class Hello9 {

	void show()throws ArrayIndexOutOfBoundsException{}	//super class method is specified with unchecked method level exception.
}

class Hai9 extends Hello9{

	void show(){}  //so subclass method can ignore exception while overriding the method.
}

