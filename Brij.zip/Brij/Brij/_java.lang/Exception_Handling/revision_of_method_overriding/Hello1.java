package revision_of_method_overriding;

class Hello1 {
	void show(){}
	void display(){}	//super class method is not specified with method level exception.
}

class Hai1 extends Hello1{
	void show(){}
	void display()throws NullPointerException{} //so subclass method can throws any unchecked exception while overriding the method
											
}

