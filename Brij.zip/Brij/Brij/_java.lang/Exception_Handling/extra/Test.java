package extra;

public class Test {
	public static void main(String[] args) {
		try {
				int a =10/0;
		} catch (ArithmeticException e) {
			System.out.println("getMessage() output");
			System.out.println(e.getMessage());
			
			System.out.println("toString() output");
			System.out.println(e.toString());
			
			System.out.println("printStackTrace() output");
			e.printStackTrace();
			
			System.out.println("JVM default message output");
			throw e;
			
		}
	}
}
