package lab1263;

public class Lab1263 {
	public static void main(String[] args) {
		System.out.println("Main Starts");
		myException ex=null;
		throw ex;	// any thing you call on null will result in NullPointerException always
	}
}
class myException extends RuntimeException{ } // its ok because RuntimeEcxeption is a subclass of Throwable.

