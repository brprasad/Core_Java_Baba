package lab1273;

public class Lab1273 {
	public static void main(String[] args) {
		int x;	
		try {
			x=99; //because compiler is not sure that this try block will execute or not, so it will not let you compile.
		}catch (Exception e){
			
		}
		
		System.out.println(x); 
		//local variable must be initialized before the use.

	}
}