package lab1276;

public class Lab1276 {
	public static void main(String[] args) {
		Student sarr[]=new Student[500];
		try {
			for (int i = 0; i < sarr.length; i++) {
				sarr[i]=new Student();
				System.out.println((i+1)+"Object created");
			}
		} catch(Error e){
			System.out.println("Error Occured :"+e);			
		}
		System.out.println("After Handling");
		Student st=new Student();
	}
}
class Student {
	long arr[]=new long[215833];
}