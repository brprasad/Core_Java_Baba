package lab1274;

public class Lab1274 {
	public static void main(String[] args) {
		int x;
		try {
			x=99;  
		}catch (Exception e){
			x=88; 
		}
		
		System.out.println(x);
		 //local variable must be initialized before the use.
		 //because compiler is sure that either try block will execute or catch block, so it will let you compile.
	}
}
