package lab1272;

public class Lab1272 {
	public static void main(String[] args) {
		int x;	
		try {
			x=99; 	//local variable must be initialized before the use.
			System.out.println(x); //99 
		} catch (Exception e) {

		}
	}
}
