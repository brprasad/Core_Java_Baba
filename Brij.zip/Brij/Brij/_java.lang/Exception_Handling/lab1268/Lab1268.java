package lab1268;

public class Lab1268 {
	public static void main(String[] args) {

		System.out.println("Main started ");
		try(
				JLCResource res1 = new JLCResource(1); 	//only initialization not allowed, we have to declare as well as initialize
				JLCResource res2 = new JLCResource(2);	//a statement in try-with resource signature.
			){
			
			// statements  
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Main ends ");
	}
}

class JLCResource { // not implementing AutoClosable interface Rule:- you must implement AutoClosable interface if you want to use 
	int id;			// try-with resource statement.

	JLCResource(int id) {
		this.id = id;
	}

	public void close() {
		System.out.println("JLCResource closed :" + id);
	}

}
