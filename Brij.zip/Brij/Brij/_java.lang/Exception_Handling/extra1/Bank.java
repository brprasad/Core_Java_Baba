package extra1;

public interface Bank {
	public void deposit(double amt)throws InvalidAmountException;
	public double withdraw(double amt)throws InsufficientAmountException;
	public void balanceEnquiry();
}
