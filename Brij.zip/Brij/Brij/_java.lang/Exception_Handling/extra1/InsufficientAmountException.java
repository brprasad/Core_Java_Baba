package extra1;

public class InsufficientAmountException extends Exception {
	public InsufficientAmountException() {
		super();
	}
	public InsufficientAmountException(String msg) {
		super(msg);
	}
	
}
