package extra1;

import java.io.IOException;
import java.util.Scanner;

public class Clerk {
	public static void main(String[] args) {
		try {
			Scanner scanner = new Scanner(System.in);

			Bank acc = new HdfcBank();
			String option="";
			do{
				System.out.println("1. Deposite");
				System.out.println("2. Withdraw");
				System.out.println("3. Balance Enquiry");

				System.out.println("Enter option :");
				option = scanner.nextLine();

				switch(option){
					case "1":{
						System.out.println("Enter deposite amount :");
						String s = scanner.nextLine();
						double amt = Double.parseDouble(s);

						acc.deposit(amt);
						acc.balanceEnquiry();

						break;
					}
					case "2":{
						System.out.println("Enter withdraw amount :");
						String s = scanner.nextLine();
						double amt = Double.parseDouble(s);

						double withDraw = acc.withdraw(amt);
						System.out.println("Withdraw amount: "+withDraw);
						acc.balanceEnquiry();

						break;
					}
					case "3":{
						
						acc.balanceEnquiry();
						break;
					}
					default: 
						System.out.println("Invalid Option ");
						System.out.println("Please choose correct");
					
				}
				System.out.println("Do you want to continue (YES/NO):");
				option = scanner.nextLine();
				
			}while(option.equals("yes"));
			
		} catch (InvalidAmountException e) {
			 System.out.println(e.getMessage());
		} catch (InsufficientAmountException e) {
			System.out.println(e.getMessage());
		} catch (NumberFormatException e) {
			System.out.println("Please enter number");
		}
	}
}
