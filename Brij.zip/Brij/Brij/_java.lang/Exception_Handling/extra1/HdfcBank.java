package extra1;

public class HdfcBank implements Bank{

	private double balance;
	@Override
	public void deposit(double amt) throws InvalidAmountException {
		if(amt<=0){
			throw new InvalidAmountException(amt+"is invalid amount");
		}
		balance = balance+amt;
		
	}

	@Override
	public double withdraw(double amt) throws InsufficientAmountException {
		if(balance<amt)
		{
			throw new InsufficientAmountException("Insufficent Funds");
		}
		balance = balance-amt;
		return amt;
	}

	@Override
	public void balanceEnquiry() {
		System.out.println("Current Balance: "+balance);		
	}

}
