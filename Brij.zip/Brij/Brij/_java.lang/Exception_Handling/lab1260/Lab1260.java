package lab1260;

public class Lab1260 {

	public static void main(String[] args) {
		System.out.println("Main Starts");
		throw new NumberFormatException() ; 
		System.out.println("Main ends"); //unreachable code
		//so we should not write any statement after throw and return.
	}
}
