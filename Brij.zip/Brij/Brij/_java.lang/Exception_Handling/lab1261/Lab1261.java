package lab1261;

public class Lab1261 {
	public static void main(String[] args) {
		System.out.println("Main Starts");
		throw new myException(); //No exception of type myEcxeption can be thrown; an exception type must be a subclass of Throwable
	}
}
class myException{ }
