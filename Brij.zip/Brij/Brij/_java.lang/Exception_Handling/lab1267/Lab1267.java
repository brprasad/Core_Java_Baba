package lab1267;

public class Lab1267 {
	public static void main(String[] args) {

		System.out.println("Main started ");
		try(
				JLCResource res1 = new JLCResource(1); 	//only initialization not allowed, we have to declare as well as initialize
				JLCResource res2 = new JLCResource(2);	//a statement in try-with resource signature.
			){
			
			// statements  
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Main ends ");
	}
}

class JLCResource implements AutoCloseable {
	int id;

	JLCResource(int id) {
		this.id = id;
	}

	public void close() {
		System.out.println("JLCResource closed :" + id);
	}

}
