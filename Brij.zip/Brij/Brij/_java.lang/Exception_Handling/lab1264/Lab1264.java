package lab1264;

public class Lab1264 {
	public static void main(String[] args) {
		System.out.println("Main Starts");
		Student st1=new Student("JLC-099");
		System.out.println(st1.sid);
		Student st2=new Student(null); // throws NullPointerException  
		System.out.println(st2.sid); 
	}
}
class Student{
	String sid;
	public Student(String sid) throws NullPointerException {  // you can use or specify throws for constructor also
		if(sid==null)
			throw new NullPointerException();
		else 
			this.sid=sid;
	}
}
