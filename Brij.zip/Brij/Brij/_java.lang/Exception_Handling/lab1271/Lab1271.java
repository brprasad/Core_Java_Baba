package lab1271;

public class Lab1271 {
	public static void main(String[] args) throws Exception{
		System.out.println("Main Starts");
		try(JLCResource res=new JLCResource();){  
			Lab ref =new Lab();
			Object obj=ref.clone();
		}
		System.out.println("Main Ends");
	}
}

class JLCResource implements AutoCloseable{
	
	@Override
	public void close() throws Exception {
			
	}
}
class Lab implements Cloneable{@Override
	protected Object clone() throws CloneNotSupportedException {
	// TODO Auto-generated method stub
	return super.clone();
	}	
}