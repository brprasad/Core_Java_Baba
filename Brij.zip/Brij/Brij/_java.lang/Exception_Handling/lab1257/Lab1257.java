package lab1257;

public class Lab1257 {
	
	//Either you can use throw or return in method at a time, not both allowed.
	
	int show(){		
		throw new ArithmeticException(); 
	}
	long getPhone(String sid){ 		//conditionally use of return and throw is allowed
		if(sid!=null)				//both condition doesn't true at a time so its ok for complier.  
			return 32903290;				
		else 
			throw new NullPointerException(); 
	}
}
