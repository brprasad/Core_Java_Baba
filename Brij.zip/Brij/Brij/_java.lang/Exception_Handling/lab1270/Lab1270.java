package lab1270;

public class Lab1270 {
	public static void main(String[] args) throws Exception{
		System.out.println("Main Starts");
		try(){	//invalid try-with resource, we must write resource code which we want to clean on close.  
			int x=10/0;
		}
		System.out.println("Main Ends");
	}
}

class JLCResource implements AutoCloseable{
	
	@Override
	public void close() throws Exception {
			
	}
}
