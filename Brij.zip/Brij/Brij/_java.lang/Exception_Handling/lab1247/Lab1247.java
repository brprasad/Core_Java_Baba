package lab1247;

public class Lab1247 {
	public static void main(String[] args) {
		try {
			int res=10/0; //unchecked exception 
		} catch (CloneNotSupportedException e) { //checked exception CAN'T be caught without raising it in try block.
			
		}
	}
}
