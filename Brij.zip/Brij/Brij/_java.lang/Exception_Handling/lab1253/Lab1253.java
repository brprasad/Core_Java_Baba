package lab1253;

public class Lab1253 {
	public static void main(String[] args) {  // main have to handle either using  try-catch or propagate using throws to caller method ie JVM. 
		System.out.println("Main Started");
		
		StudentService serv =new StudentService();
		serv.getNameBySid(null); 

		System.out.println("Main End");
	}
}

class StudentService{
	String getNameBySid(String sid) throws StudentNotFoundException { //propagate to caller of the method ie main() have to handle
		if(sid==null ||sid.isEmpty() ||!sid.equals("JLC-99"))
			throw new StudentNotFoundException(sid);	//(either to handle with try-catch or to propagate with throws)
		else 
			return "Srinivas";
	}
}

class StudentNotFoundException extends Exception{ 		//checked exception so it is mandatory to report about this exception
														
	
	public StudentNotFoundException(String sid) {			 
		super(sid);	
	}
}

