package lab1240;

public class Lab1240 {
	public static void main(String[] args) {
		System.out.println("Main() Started");
		new Hello().show("3");
		System.out.println("Main() completed");
	}
}
class Hello
{ 
	void show(String str) // return type is String
	{
		System.out.println("show() called");
		try {
			System.out.println("try block begins");
			int a=Integer.parseInt(str);
			int b=10/a;
			System.out.println("try block ends :"+b);
			System.exit(0); //if JVM will be terminated before executing the finally block then the finally block will not be executed.
							//By using System.exit(0); you can terminate JVM explicitly.
		} catch (ArithmeticException e) {
			System.out.println("catch block ");
		}
		finally{ 
			System.out.println("finally block ");
		}
	} 
}

