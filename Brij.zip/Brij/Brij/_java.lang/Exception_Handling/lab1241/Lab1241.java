package lab1241;

public class Lab1241 {
	public static void main(String[] args) {
		System.out.println("Main() Started");
		new Hello().show("0");
		System.out.println("Main() completed");
	}
}
class Hello
{ 
	void show(String str) // return type is String
	{
		System.out.println("show() called");
		try {
			System.out.println("try block begins");
			int a=Integer.parseInt(str);
			int b=10/a;
			System.out.println("try block ends :"+b);
			
		} catch (ArithmeticException e) {
			System.out.println("catch block ");
			System.exit(0); //if JVM will be terminated before executing the finally block then the finally block will not be executed.
							//By using System.exit(0); you can terminate JVM explicitly.
		}
		finally{ 
			System.out.println("finally block ");
		}
	} 
}
