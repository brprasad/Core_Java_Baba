package lab1269;

public class Lab1269 {
	public static void main(String[] args) throws Exception{
		System.out.println("Main Starts");
		try(JLCResource res =new JLCResource();){
			int x=10/0;
		}
		System.out.println("Main Ends");
	}
}

class JLCResource implements AutoCloseable{
	
	@Override
	public void close() throws Exception {
			
	}
}