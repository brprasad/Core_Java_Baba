package lab1245;

import javax.crypto.NullCipher;

public class Lab1245 {
	public static void main(String[] args) {
		Exception ex1= new CloneNotSupportedException();
		Exception ex2=new NullPointerException();
		System.out.println(ex1 instanceof RuntimeException);
		System.out.println(ex2 instanceof RuntimeException);
	}
}
