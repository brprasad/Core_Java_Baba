package lab1262;

public class Lab1262 {
	public static void main(String[] args) {
		System.out.println("Main Starts");
		throw new myException(); //No exception of type myEcxeption can be thrown; an exception type must be a subclass of Throwable
	}
}
class myException extends RuntimeException{ } // its ok because RuntimeEcxeption is a subclass of Throwable.
