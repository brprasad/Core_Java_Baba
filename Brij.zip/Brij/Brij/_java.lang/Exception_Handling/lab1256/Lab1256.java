package lab1256;

public class Lab1256 {
	
	//Either you can use throw or return in method at a time, not both allowed. 
	
	int show(){		
		throw new ArithmeticException();
		return 0; //unreachable code 
	}
	long getPhone(String sid){
		if(sid!=null)
			return 32903290;
		else 
			return 6579999;
			throw new NullPointerException(); // unreachable code
	}
}
