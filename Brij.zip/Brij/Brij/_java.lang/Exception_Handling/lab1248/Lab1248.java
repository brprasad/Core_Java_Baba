package lab1248;

public class Lab1248 {
	public static void main(String[] args) {
		try {
			/// NO	STATEMENT
			
		} catch (Exception e) { // Exception class itself is partially checked and partially unchecked. depending on condition.
			
		}
	}
}
