package lab1250;

public class Lab1250 {
	public static void main(String[] args) {
		System.out.println("Main Started");
		
		try {
			StudentService serv =new StudentService();
			serv.getNameBySid(null); 
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Main End");
	}
}

class StudentService{
	String getNameBySid(String sid){
		if(sid==null ||sid.isEmpty() ||!sid.equals("JLC-99"))
			throw new StudentNotFoundException(sid);
		else 
			return "Srinivas";
	}
}

class StudentNotFoundException extends RuntimeException{ // unchecked exception so it is optional to report about this exception
														//not mandatory (to handle with try-catch or to propagate with throws)
	
	public StudentNotFoundException(String sid) {			 
		super(sid);	
	}
}
