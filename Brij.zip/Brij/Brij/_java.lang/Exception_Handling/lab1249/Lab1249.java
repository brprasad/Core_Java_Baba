package lab1249;

public class Lab1249 {
	public static void main(String[] args) {
		System.out.println("Main Started");
		String nm="";
		
		try {
			StudentService serv =new StudentService();
			//nm=serv.getNameBySid(null);         	case 4
			//nm=serv.getNameBySid("");				case 3
			//nm=serv.getNameBySid("JLC-88");		case 2
			nm=serv.getNameBySid("JLC-99");		  //case 1
			System.out.println("Name :"+nm); 
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Main End");
	}
}
class EmptySidException extends RuntimeException{ } // unchecked exception 

class StudentService{
	String getNameBySid(String sid){
		if(sid==null)
			throw new NullPointerException();
		else if(sid.isEmpty())
			throw new EmptySidException();
		else if(sid.equals("JLC-99"))
			return "Srinivas";
		else 
			throw new StudentNotFoundException(sid);			
	}
}

class StudentNotFoundException extends RuntimeException{
	public StudentNotFoundException(String sid) {
		super(sid);	
	}
}