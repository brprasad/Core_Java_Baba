package lab1244;

public class Lab1244 {
	public static void main(String[] args) {
		System.out.println("Main Start");
		int x=10/0;	//unchecked exception so compiler don't given any problem 
					// regarding to report the exception.
		System.out.println("Main Ends");
	}
}
