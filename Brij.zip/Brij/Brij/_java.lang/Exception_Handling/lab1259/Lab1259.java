package lab1259;

public class Lab1259 {
	public static void main(String[] args) {
		System.out.println("Main Starts");
		new A().m1();
		System.out.println("Main ends");
	}
}
class A{
	void m1(){
		System.out.println("A-> m1() starts");
		int x=m2();
		System.out.println("X:"+x);
		System.out.println("A-> m1() ends");
	}
	int m2(){
		System.out.println("A-> m2() starts");
		throw new NullPointerException();
	}
}
