package lab1252;

public class Lab1252 {
	public static void main(String[] args) { 
		System.out.println("Main Started");
		
		try {
			StudentService serv =new StudentService();
			serv.getNameBySid(null); 
			
		} catch (Exception e) {			// main handling using  try-catch or propagate using throws to caller method 
			e.printStackTrace();
		}
		System.out.println("Main End");
	}
}

class StudentService{
	String getNameBySid(String sid) throws StudentNotFoundException { //propagate to caller of the method ie main() have to handle
		if(sid==null ||sid.isEmpty() ||!sid.equals("JLC-99"))
			throw new StudentNotFoundException(sid);	//(either to handle with try-catch or to propagate with throws)
		else 
			return "Srinivas";
	}
}

class StudentNotFoundException extends Exception{ 		//checked exception so it is mandatory to report about this exception
														
	
	public StudentNotFoundException(String sid) {			 
		super(sid);	
	}
}

