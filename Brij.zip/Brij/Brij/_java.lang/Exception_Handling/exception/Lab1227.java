package exception;

public class Lab1227 {
	public static void main(String[] args) { // if you have multiple catch block with same code of statement.
											 // then use a single catch block with more than one type of exception.
											
		System.out.println("Main Started");
		try {
			String data=args[0];
			int x=Integer.parseInt(data);
			int res=10/x;
			System.out.println("Result is:"+res);
		}catch (ArrayIndexOutOfBoundsException e) { 
			System.out.println("Provide one non zero int value as CLA");
		}catch (NumberFormatException e) { 
			System.out.println("Provide one non zero int value as CLA");
		}catch (ArithmeticException e) { 
			System.out.println("Provide one non zero int value as CLA");
		}
		System.out.println("Main Ends");
	} 
}
