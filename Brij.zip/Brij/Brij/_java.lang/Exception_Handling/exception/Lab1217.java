package exception;

public class Lab1217 {
	public static void main(String[] args) {
		System.out.println("Main Started");
		String data=args[0];			//case 1: java Lab1217 (When value is not provided from CommandLine)
										// Main Started 
										// Exception in thread"main" java.lang.ArrayIndexOutofBoundsException:0
		
		int x=Integer.parseInt(data);	//case 2: java Lab1217 JLC (When String or char is provided as CLA) 
										//Main Started
										// Exception in thread "main" java.lang.NumberFormatException: For input string: "JLC"
		
		int result=10/x;				//case 3: java Lab1217 0 (When 0 is provided as CLA)
										//Main Started
										// Exception in thread "main"  java.lang.ArithmeticException: / by zero
		
										//case 4: java Lab1217 3(When 3 is provided as CLA)
										//Main Started
										//Result is: 3
										//Main Ends
		
		System.out.println("Result is: "+result);
		System.out.println("Main Ends");
	}
}
 