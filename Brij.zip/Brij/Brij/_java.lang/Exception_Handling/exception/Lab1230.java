package exception;

public class Lab1230 {
	public static void main(String[] args) {
		try {
			//......
			//.....
			
		} catch (NullPointerException|ArithmeticException e) { 
			// when you are writing multiple exception in one catch block then
			// 1) multiple exception must be unique
			// 2) multiple exception must not have any Inheritance relationship
			// so if you want to place super type exception then write another catch block
			System.out.println("Provide one non zero int value as CLA ");
		}catch (Exception e) {
			System.out.println("Provide one non zero int value as CLA ");
		}
	}

}
