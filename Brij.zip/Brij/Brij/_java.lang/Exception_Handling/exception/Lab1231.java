package exception;

public class Lab1231 {
	public static void main(String[] args) {
		System.out.println("Main Statred");
		try {
			int res=10/0;
			System.out.println("Result id"+res);
		} catch (NumberFormatException e) {
			System.out.println("Invalid Input");
		}
		System.out.println("Main Ends"); //when exception occurs in try block and matching catch is not present then 
										 //then statement after catch block will not executed.
	}
}
