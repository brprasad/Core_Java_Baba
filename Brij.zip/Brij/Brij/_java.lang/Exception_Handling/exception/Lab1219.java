package exception;

public class Lab1219 {
	public static void main(String[] args) {
		System.out.println("Main Strated");
		try {
			String data=args[0];
			int x=Integer.parseInt(data);
			int res=10/x;
			System.out.println("Result is:"+res);
		} catch (ArrayIndexOutOfBoundsException e) { 
			System.out.println("Enter one value as CLA");
		}catch (NumberFormatException e) { 
			System.out.println("Enter int value as CLA");
		}catch (ArithmeticException e) { 
			System.out.println("Enter non zero value as CLA");
		}
		
		System.out.println("Main Ends");
	}
}
