package exception;

public class Lab1222 { 
	public static void main(String[] args) {
		System.out.println("Main Started");
		try {
			int res=10/0;	//when matching catch is not found then error will be handled by JVM and program will be terminated abnormally.
			System.out.println("Result is: "+res);
		} catch (NumberFormatException e) { 
			System.out.println("Invalid input");
		}
		System.out.println("Main Ends");
	}
}
