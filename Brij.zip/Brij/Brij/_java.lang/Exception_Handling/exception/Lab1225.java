package exception;

public class Lab1225 {
	public static void main(String[] args) {
		System.out.println("Main Started");
		try {
			int res=Integer.parseInt("JLC");
			System.out.println("Result is: "+res);
		} catch (NumberFormatException e) {
			System.out.println("Invalid Input");
			int x=10/0; // if the problem rise in the statement which is (before try, inside catch, after catch) 
						//then it will be handled by JVM always. 
		} catch(ArithmeticException e){
			System.out.println("Divide by Zero");
		}
		System.out.println("Main End");
	}	
}
