package exception;

public class Lab1234 {
	public static void main(String[] args) {
		System.out.println("Main Statred");
		try {
			int res=10/3;
			System.out.println("Result is :"+res);
			return;	// return statement transfer the control to caller method(ie main method) but before transferring control 
					// it will check whether any finally block is their for this try block, if yes then execute that finally block
					// and then transfer the control to caller method.
			
		} catch (Exception e) {
			System.out.println("Invalid Input");
		}
		finally{
			System.out.println("finally block");	
			System.out.println("Main Ends");		
		}
	} 
}
