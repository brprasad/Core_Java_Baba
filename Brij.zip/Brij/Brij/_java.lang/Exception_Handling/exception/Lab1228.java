package exception;

public class Lab1228 {
	public static void main(String[] args) {
		// if you have multiple catch block with same code of statement in each catch block.
		// then use single catch block with more than one type of exception separated with "|" .
		// this is new feature added in java7 and it reduce code duplication.
		
		System.out.println("Main Started");
		try {
			String data=args[0];
			int x=Integer.parseInt(data);
			int res=10/x;
			System.out.println("Result is:"+res);
		}catch (ArrayIndexOutOfBoundsException|NumberFormatException|ArithmeticException e) { 
			System.out.println("Provide one non zero int value as CLA");
		}
		System.out.println("Main Ends");
	}
}