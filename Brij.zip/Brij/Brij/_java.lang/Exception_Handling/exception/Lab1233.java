package exception;

public class Lab1233 {
	public static void main(String[] args) {
		System.out.println("Main Statred");
		try {
			int res=10/3;
			System.out.println("Result is: "+res);
			return;	// return statement transfer the control to caller method(ie main method) so statement after catch block will not executed.
			
		} catch (Exception e) {
			System.out.println("Invalid Input");
		}
		System.out.println("Main Ends");	//when you have return in try block, then statement after catch block will not executed.
	}
}
 