package exception;

public class Lab1224 {
	
	public static void main(String[] args) {
		System.out.println("Main Started");
		try {
			int res=10/0;	
			System.out.println("Result is: "+res);
		}catch (NumberFormatException e) { 
			System.out.println("Invalid input");
		}System.out.println("JLC");  //  their should not be any statement b/w two catch block.
		catch (Exception e) {
			System.out.println("Enter correct input");
		}
		System.out.println("Main End");
	}
}

