package exception;

public class Lab1226 {
	public static void main(String[] args) { // so all the exception is handled successfully and program terminate normally.
		System.out.println("Main Started");
		String data=null;
		try {
			data=args[0];	
		} catch (ArrayIndexOutOfBoundsException e) { 
			System.out.println("Provide one value as CLA");
		}
		int x=0;			
		try {
			x=Integer.parseInt(data);	
		} catch (NumberFormatException e) {
			System.out.println("Provide int value as CLA");
		}
		try {
			int res=10/x;
			System.out.println("Result is :"+res);
		} catch (ArithmeticException e) {
			System.out.println("Provide non zero value as CLA");
		}
		System.out.println("Main Ends");
	}
}
/*
	//case 1: java Lab1226 (When value is not provided from CommandLine)
	Main Started
	Provide one value as CLA
	Provide int value as CLA
	Provide non zero value as CLA
	Main Ends
	
	//case 2: java Lab1226 JLC (When String or char is provided as CLA)
	Main Started
	Provide int value as CLA
	Provide non zero value as CLA
	Main Ends
	
	//case 3: java Lab1226 0 (When 0 is provided as CLA)
	Main Started
	Provide non zero value as CLA
	Main Ends
	
	//case 4: java Lab1226 5 (When 5 is provided as CLA)
	Main Started
	Result is :2
	Main Ends
	
 */