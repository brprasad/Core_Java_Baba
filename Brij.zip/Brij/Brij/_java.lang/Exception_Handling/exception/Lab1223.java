package exception;

public class Lab1223 {
	public static void main(String[] args) {
		System.out.println("Main Started");
		try {
			int res=10/0;	
			System.out.println("Result is: "+res);
		}System.out.println("JLC");  // their should not be any statement b/w try block and catch block. 
		catch (NumberFormatException e) { 
			System.out.println("Invalid input");
		}
		System.out.println("Main End");
	}
}
