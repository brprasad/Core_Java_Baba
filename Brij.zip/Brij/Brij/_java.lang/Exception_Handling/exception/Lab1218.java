package exception;

public class Lab1218 {
	public static void main(String[] args) {
		System.out.println("Main Strated");
		try {
			String data=args[0];
			int x=Integer.parseInt(data);
			int res=10/x;
			System.out.println("Result is:"+res);
		} catch (Exception e) { //for Any type of Exception it only throwing single statement and it's not relevance,
								//i.e    which type of exception is actually coming and what correct value user have to provide is unknown.
			System.out.println("Enter correct value");
		}
		System.out.println("Main Ends");
	}
}
