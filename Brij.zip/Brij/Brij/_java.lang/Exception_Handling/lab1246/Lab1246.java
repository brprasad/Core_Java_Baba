package lab1246;

public class Lab1246 {
	public static void main(String[] args) {
		try {
			int res=10/0;  //unchecked exception 
		} catch (NumberFormatException e) { //unchecked exception can be caught without raising it in try block.
			
		}
	}
}
