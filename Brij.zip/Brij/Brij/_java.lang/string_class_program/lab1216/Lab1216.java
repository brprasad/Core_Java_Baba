package lab1216;

public class Lab1216 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder("Sri");
		long arr1[]=new long[]{31903290, 657999999};
		Student st=new Student(99, sb1, arr1);
		System.out.println(st);
		
		System.out.println("Modifiying the sb and arr");
		sb1.append(" Nivas");
		arr1[0]=78787878;
		System.out.println(st); 
		
		System.out.println("Accessing name and phone and modifying");
		StringBuilder sb2=st.getName();
		long arr2[]=st.getPhone();
		sb2.append(" Dande");
		arr2[1]=96969689;
		System.out.println(st);
	}
}
final class Student{	//this class is mutable class, because it have mutable object available as member(StringBuilder name and long[] phone).
						//so we can modify the object of StringBuilder class and Array[] class.
	
	// steps to define custom immutable class
	//1) define class as final.
	//2) define the variables as private final
	//3) define the getter method to access the values
	//4) don't define setter method
	//5) if any mutable object available as member then while initializing or accessing the mutable object,
	//	create the object and use that.
	
	private final int sid;			
	private final StringBuilder name;
	private final long []phone;
	public Student(int sid, StringBuilder name,long []phone) {
		this.sid=sid;
		this.name=new StringBuilder(name);
		this.phone=new long[phone.length];
		System.arraycopy(phone, 0, this.phone, 0, phone.length); 
	}
	public int getSid(){
		return sid;
	}
	public StringBuilder getName(){
		return new StringBuilder(name);
	}
	public long []getPhone(){
		long arr[]=new long[phone.length];
		System.arraycopy(phone, 0, arr, 0, phone.length);
		return arr;
	}
	@Override
	public String toString() {
		String msg= sid+","+name;
		for (long val : phone) 
			msg+=","+val;
		return msg;
	}
}


