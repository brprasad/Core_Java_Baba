package lab1209;

public class Lab1209 {
		public static void main(String[] args) {
			Hello h=Hello.getHello();
			System.out.println(h);
			System.out.println(Hello.getHello());
			System.out.println(Hello.getHello());
		}
}	
class Hello // singleton class ie one object of a particular class is created 
			//and  all further references to the object of singleton class refer to the same instance.  
{											
	//steps required to make a class singleton :
	//1)define constructor as private to restrict instantiation of the from outside.
	//2)declare private static variable of the same class that holds single instance of the class.
	//3)define public static method that returns the single instance(object) of the class.
	
	private static Hello INS =null;			
	static{
		INS=new Hello(); // static variable can be initialize directly in same statement or via static block or via object creation.  				
	}
	private Hello(){};	
	public static Hello getHello()			
	{
		return INS;
	}
	
}

