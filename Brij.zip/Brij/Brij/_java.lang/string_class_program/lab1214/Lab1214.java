package lab1214;

public class Lab1214 {
	public static void main(String[] args) {
		Student s=new Student(99, "Sri", 989898989);
		System.out.println(s);
	}
}
final class Student{	//immutable class because we can't modify object once it is created.
	// steps to define custom immutable class
	//1) define class as final.
	//2) define the variables as private final
	//3) define the getter method to access the values
	//4) don't define setter method
	//5) if any mutable object available as member then while initializing or accessing the mutable object,
	//	create the object and use that.
	
	private final int sid;			
	private final String name;
	private final long phone;
	public Student(int sid, String name,long phone) {
		this.sid=sid;
		this.name=name;
		this.phone=phone;
	}
	public int getSid(){
		return sid;
	}
	public String getName(){
		return name;
	}
	public long getPhone(){
		return phone;
	}
	@Override
	public String toString() {
		return "sid=" + sid + "\t name=" + name + "\t phone=" + phone;
	}
	
}
