package string_class;

public class Lab1104 {
	public static void main(String[] args) {
		String pattern="[A-Z]";	// -> only one occurrence of upper case letter is valid
		
		System.out.println("H".matches(pattern)); //true
		System.out.println("S".matches(pattern)); //true
		System.out.println("HI".matches(pattern)); //false
		
	}
}
