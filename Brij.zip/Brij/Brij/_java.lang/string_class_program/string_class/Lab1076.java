package string_class;

public class Lab1076 {
	public static void main(String[] args) {
		System.out.println(null.length()); 	// error: <null> cannot be dereferenced
											
	}
}
