package string_class;

public class Lab1066 {
	public static void main(String[] args) {
		int ab=98;
		String str1=ab;	// can't assign int to String.
		String str2=(String)ab; //can't cast int to String.
		System.out.println(str1+"\t"+str2);
	}
}
