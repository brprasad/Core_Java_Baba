package string_class;

public class Lab1115 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder("JLC");
		System.out.println(sb1);
		System.out.println("Capacity :"+sb1.capacity());
		System.out.println("Length :"+sb1.length());
		
		sb1.append("WELCOME TO JLC,(JAVA LEARING CENTER.)");
		System.out.println(sb1);
		System.out.println("Capacity :"+sb1.capacity());
		System.out.println("Length :"+sb1.length());
	}
}
