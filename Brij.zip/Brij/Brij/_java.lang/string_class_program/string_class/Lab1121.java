package string_class;

public class Lab1121 {

		public static void main(String[] args) {
			StringBuilder sb1=new StringBuilder("JLCINDIA");
			System.out.println(sb1);//JLCINDIA
			System.out.println("Capacity :"+sb1.capacity()); //24
			System.out.println("Length :"+sb1.length());//8
			
			sb1.ensureCapacity(12);
			System.out.println("Capacity :"+sb1.capacity());//24
			System.out.println("Length :"+sb1.length());//8
			
			sb1.ensureCapacity(59);
			System.out.println("Capacity :"+sb1.capacity());//59
			System.out.println("Length :"+sb1.length());//8
			
			
		}
}
