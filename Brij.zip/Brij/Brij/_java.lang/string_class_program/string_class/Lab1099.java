package string_class;

public class Lab1099 {
	public static void main(String[] args) {
		
		// split this string around matches of the given regExp.
		// if regular expression syntax match/valid then return the array of string computed by splitting this String 
		// else throws PatternSyntaxException
		
		//The limit parameter controls the number of times the pattern is applied ie index=length-1; 


		String str="JLC,Java Learing Center No 1 in Java Training and Placement. Java is a popular language";
		String res[]=str.split("Java",1); // 1-1=0, ie string split is not perform, str is return as it is.
		System.out.println("Length :"+res.length);
		for (int i = 0; i < res.length; i++) {
			String str1=res[i];
			System.out.println(i+"\t"+str1);
		}
		
		String res1[]=str.split("Java",2);// 2-1=1, string split is perform 1 time at regEx ie "Java", str1 is return acc to string array generated.
		System.out.println("Length :"+res1.length);
		for (int i = 0; i < res1.length; i++) { 
			String str1=res1[i];
			System.out.println(i+"\t"+str1);
		}
	}
}
