package string_class;

public class Lab1127 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder("JLC");
		System.out.println(sb1);
		System.out.println("Capacity :"+sb1.capacity());//19
		System.out.println("Length :"+sb1.length());//3
		
		sb1.trimToSize(); //reduce the capacity to the length.
		System.out.println("Capacity :"+sb1.capacity());//3
		System.out.println("Length :"+sb1.length());//3
		
		
	}
}
 