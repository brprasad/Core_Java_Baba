package string_class;

public class Lab1109 {
	public static void main(String[] args) {
		String str1="AB";
		String str2=new String("AB");
		System.out.println(str1.hashCode());// "AB" -> 65*31^1+66*31^0 = 2081 , hashCode is overridden in String class 
		System.out.println(str2.hashCode());// "AB" -> 65*31^1+66*31^0 = 2081 , hashCode is overridden in String class
		System.out.println(str1==str2);//false, i.e compare the address 
	}
}
