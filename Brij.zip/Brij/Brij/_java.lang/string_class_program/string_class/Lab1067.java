package string_class;

public class Lab1067 {
	public static void main(String[] args) {
		int ab=98;
		String str1=String.valueOf(ab);
		String str2=String.valueOf(true);
		System.out.println(str1+"\t"+str2); // 98 true 
	}
}
