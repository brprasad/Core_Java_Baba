package string_class;

public class Lab1105 {
	public static void main(String[] args) {
		String pattern="[A-Z]*";	// -> zero or more occurrence of upper case letter is valid
		
		System.out.println("".matches(pattern)); //true
		System.out.println("H".matches(pattern)); //true
		System.out.println("SRINIVAS".matches(pattern)); //true
		System.out.println("JLCINDIA".matches(pattern)); //true
		System.out.println("jlc".matches(pattern)); //false 
		
	}
}
