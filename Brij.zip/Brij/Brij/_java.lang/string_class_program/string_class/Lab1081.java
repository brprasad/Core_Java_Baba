package string_class;

public class Lab1081 {
	public static void main(String[] args) {
		String str="Welcome to JLC, Java Training Center, No 1 in Java Training and Placement";
		
		System.out.println(str.indexOf('J'));//11
		//Returns the index within this string of the first occurrence of the specified character.
		//else return -1 
	
		System.out.println(str.indexOf('J',11));//11
		//Returns the index within this string of the first occurrence of the specified character, 
		//starting the search at the specified index. else return -1 
		System.out.println(str.indexOf('J',12));//16
		System.out.println(str.indexOf('J',17));//46
		
	}
}
