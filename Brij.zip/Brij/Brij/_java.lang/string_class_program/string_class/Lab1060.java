package string_class;

public class Lab1060 {
	public static void main(String[] args) {
		String str1="JLC";		// created without using new operator, because value is known to compiler.
		String str2="INDIA";			// created without using new operator, because value is known to compiler.		
		String str3=str1.concat(str2);  // concat() method always created using new operator, because value is unknown to compiler.
		System.out.println(str3); //JLCINDIA
		String str4="JLCINDIA";   // created without new operator, because value is known to compiler.
		System.out.println(str3==str4);  //false because both have different address 
	}
}
