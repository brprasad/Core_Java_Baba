package string_class;

public class Lab1102 {
	public static void main(String[] args) {
		String dir="D:\\B81\\abc\\java\\abc.txt";
		System.out.println(dir);
		
		String res[]=dir.split("\\"); 	// split based on '\' then you have place 4 forward \
										// else give Exception in thread "main" java.util.regex.PatternSyntaxException: Unexpected internal error near index 1
		System.out.println("Length :"+res.length);
		for (int i = 0; i < res.length; i++) {
			String str1=res[i];
			System.out.println(i+"\t"+str1);
		}
	}
}
