package string_class;

public class Lab1129 {
	public static void main(String[] args) {
		String str="JLC";
		StringBuilder sb=new StringBuilder("JLC");
		System.out.println(str.contentEquals(sb)); //true 
						// so to compare content of StringBuilder class object use contentEquals() method
	}
}
