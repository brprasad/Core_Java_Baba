package string_class;

public class Lab1083 {
	public static void main(String[] args) {
		String str="Welcome to JLC, Java Training Center, No 1 in Java Training and Placement";
		//Returns the index within this string of the last occurrence of the specified character.
		//else return -1 
		System.out.println(str.lastIndexOf(97));//66
		System.out.println(str.lastIndexOf('a'));//66
	}

} 