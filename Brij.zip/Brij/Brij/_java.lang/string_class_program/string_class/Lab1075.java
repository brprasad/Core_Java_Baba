package string_class;

public class Lab1075 {
	public static void main(String[] args) {
		String str=null;
		System.out.println(str.isEmpty()); // NullPointerException because we are calling isEmpty() on null.
	}

}
