package string_class;

public class Lab1077 {
	public static void main(String[] args) {
		String str="Hai, Welcome to JLC";
		System.out.println(str.startsWith("Hai")); 	
//true if the character sequence represented by the argument is a prefix of the character sequence 
//represented by this string; false otherwise. Note also that true will be returned if the argument is an empty string 
//or is equal to this String object as determined by the equals(Object) method.

		System.out.println(str.startsWith("Welcome"));
		System.out.println(str.startsWith("Welcome", 5));
	}
}
 