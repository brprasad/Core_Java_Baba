package string_class;

public class Lab1073 {
	public static void main(String[] args) {
		String str="";
		System.out.println(str.length());
		System.out.println(str.isEmpty());
	}
}
