package string_class;

public class Lab1126 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder();
		sb1.insert(2, null);
		System.out.println(sb1);
	}
}
