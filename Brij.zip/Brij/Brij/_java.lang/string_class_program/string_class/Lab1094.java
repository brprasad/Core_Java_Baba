package string_class;

public class Lab1094 {
	public static void main(String[] args) {
		//custom logic implementation to convert charArray to String
		char []chArr={'J','L','C','I','N','D','I','A'};
		String str="";
		for (int i = 0; i < chArr.length; i++) {
			char ch=chArr[i];
			str+=ch;
		}
		System.out.println(str); //JLCINDIA
	}
}
