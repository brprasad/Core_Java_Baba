package string_class;

public class Lab1095 {
	public static void main(String[] args) {
		
		byte []bArr ={65,66,67,97,98,99,49,50};
		String str="";
		for (int i = 0; i < bArr.length; i++) {
			byte b=bArr[i];
			str+=b;
		}
		System.out.println("From byte array :"+str);
		//custom logic implementation to convert byteArray to String
		String str1="";
		for (int i = 0; i < bArr.length; i++) {
			byte b=bArr[i];
			str1+=(char)b;
		}
		System.out.println("From byte array :"+str1);
	}
}
