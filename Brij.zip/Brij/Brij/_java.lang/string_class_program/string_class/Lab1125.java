package string_class;

public class Lab1125 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder();
		sb1.append(null);
		/*Lab1125.java:6: error: reference to append is ambiguous, both method append(StringBuffer) in StringBuilder and method append(char[]) in StringBuilder match
        sb1.append(null);
           ^
           1 error*/
		System.out.println(sb1);
	}
}
