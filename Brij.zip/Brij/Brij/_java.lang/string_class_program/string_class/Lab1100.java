package string_class;

public class Lab1100 {
	public static void main(String[] args) {
		String str="JLC,Java Learing Center No 1 in Java Training and Placement. Java is a popular language";
		String res[]=str.split("Java",0); 
		// 0-1= -1, if the limit is less or greater beyond the occurrence 
		// then string split is perform max occurrence times at regEx ie "Java", 
		// str1 is return acc to string array generated.
		
		System.out.println("Length :"+res.length); //length is no. of times string is split. 
		for (int i = 0; i < res.length; i++) {
			String str1=res[i];
			System.out.println(i+"\t"+str1);
		}
		
		System.out.println("\n*********************");
		String res1[]=str.split("Java",5);
		// 5-1= 4, if the limit is less or greater beyond the occurrence 
		// then string split is perform max occurrence time at regEx ie "Java",
		// str1 is return acc to string array generated.
				
		System.out.println("Length :"+res.length); //length is no. of times string is split.
		for (int i = 0; i < res1.length; i++) {
			String str1=res1[i];
			System.out.println(i+"\t"+str1);
		}
	}
}
