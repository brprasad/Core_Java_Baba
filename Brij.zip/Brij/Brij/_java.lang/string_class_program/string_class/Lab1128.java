package string_class;

public class Lab1128 {
	
	public static void main(String[] args) {
		String str="JLC";
		StringBuilder sb=new StringBuilder("JLC");
		System.out.println(str.equals(sb)); //false because equals() method is not overridden in StringBuilder class
											// so it will call Object class equals() method which compare address 
											// so to compare content of StringBuilder class use contentEquals() method
	}
}
