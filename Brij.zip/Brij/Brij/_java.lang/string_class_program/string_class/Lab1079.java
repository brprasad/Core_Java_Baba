package string_class;

public class Lab1079 {
	public static void main(String[] args) {
		String str="Hi, Welcome to JLC(Java Learning Center), Java World";
		String str1=str.replace('J', 'X');
		//Returns a new string resulting from replacing all occurrences of oldChar in this string with newChar. 
		//If the character oldChar does not occur in the character sequence represented by this String object,
		//then a reference to this String object is returned. Otherwise, a new String object is created that 
		//represents a character sequence identical to the character sequence represented by this String object, 
		//except that every occurrence of oldChar is replaced by an occurrence of newChar.
		
		System.out.println(str1);////Hi, Welcome to XLC(Xava Learning Center), Xava World
		
		String str2=str.replaceFirst("Java", "SD");
		
		//Replaces the first substring of this string that matches the given regular expression with the given replacement. 
		//Note that backslashes (\) and dollar signs ($) in the replacement string may cause the results to be different than 
		//if it were being treated as a literal replacement string. 
		
		System.out.println(str2);//Hi, Welcome to JLC(SD Learning Center), Java World
		
		String str3=str.replaceAll("Java", "SD"); 
		
		//Replaces each substring of this string that matches the given regular expression with the given replacement. 
		//Note that backslashes (\) and dollar signs ($) in the replacement string may cause the results to be different than
		//if it were being treated as a literal replacement string. 

		System.out.println(str3);//Hi, Welcome to JLC(SD Learning Center), SD World
		
		System.out.println(str);//Hi, Welcome to JLC(Java Learning Center), Java World
	
	}
}
