package string_class;

public class Lab1057 {
	public static void main(String[] args) {
		String str1="JLCINDIA";		// created without using new operator, because value is known to compiler.
		String str2="JLC"+"INDIA";	// created without using new operator, because value is known to compiler.
		final String str3="JLC";	// created without using new operator, because value is known to compiler.
		final String str4="INDIA";	// created without using new operator, because value is known to compiler.
		String str5=str3+str4;		// created without using new operator, because value is known to compiler.
		
		System.out.println(str1==str2); // true because both have same address.
		System.out.println(str1==str5);	// true because both have same address.
	}
}
