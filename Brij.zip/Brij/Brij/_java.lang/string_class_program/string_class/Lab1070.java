package string_class;

public class Lab1070 {
	public static void main(String[] args) {
		String st=String.valueOf(null); // if you call any thing on null then it will throw NullPointerException
		System.out.println(st);	
	}
}
 