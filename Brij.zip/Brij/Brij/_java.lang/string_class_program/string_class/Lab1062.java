package string_class;

public class Lab1062 {
	public static void main(String[] args) {
		int ab=98; 
		int bc=98;
		System.out.println("Result="+ab==+bc);//Incompatible operand types String and int
	}

}
