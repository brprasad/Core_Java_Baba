package string_class;

public class Lab1117 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder("JLCINDIA");
		System.out.println(sb1);
		System.out.println("Capacity :"+sb1.capacity());
		System.out.println("Length :"+sb1.length());
		
		sb1.setLength(3); //it change only length of StringBuilder, and will not change capacity.
		System.out.println(sb1);
		System.out.println("Capacity :"+sb1.capacity());
		System.out.println("Length :"+sb1.length());
		
	}
}
