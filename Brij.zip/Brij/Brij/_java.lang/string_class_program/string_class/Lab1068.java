package string_class;

public class Lab1068 {
	public static void main(String[] args) {
		Student stu=new Student();
		String st1=String.valueOf(stu);
		System.out.println(st1); 	// whenever you print ref variable then it always call toString(), 
									//either your overridden toString() method or Object class toString() method. 
			// in this case toString() of Object class is called and it print fqclassname@Hexdecimalof Hashcode ie lab1068.Student@c3c749
		Employee emp=new Employee();
		String st2=String.valueOf(emp);
		System.out.println(st2);	// whenever you print ref variable then it always call toString(), 
									//either your overridden toString() method or Object class toString() method. 
			// in this case toString() of Employee class is called and it print eid of current object ie 0
	}
}
class Student{}
class Employee{
	int eid;
	public String toString()
	{
		return "Eid :"+eid;
	}
}