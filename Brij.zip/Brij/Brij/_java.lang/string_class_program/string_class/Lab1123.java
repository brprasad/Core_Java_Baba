package string_class;

public class Lab1123 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder("JLCINDIA");
		System.out.println(sb1);//JLCINDIA
		System.out.println("Capacity :"+sb1.capacity()); 
		System.out.println("Length :"+sb1.length());
		
		sb1.ensureCapacity(879898767);// exception:java.lang.OutofMemoryError: Java Heap space
		//ie JVM will not be able to allocate that much of memory(capacity) to StringBuilder object array. 
		System.out.println("Capacity :"+sb1.capacity());
		System.out.println("Length :"+sb1.length());
		
	}
}
