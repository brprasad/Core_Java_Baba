package string_class;

public class Lab1056 {
	public static void main(String[] args) {
		String str1="JLC";// created without using new operator.
		String str2="INDIA";// created without using new operator.
		String str3=str1+str2;	// created using new operator.
		String str4=str1+"INDIA";// created using new operator.
		String str5="JLC"+str2;// created using new operator.
		
		System.out.println(str3+"\t"+str4+"\t"+str5); // JLCINDIA	JLCINDIA	JLCINDIA
		
		System.out.println(str3==str4); // false because both have different address.
		System.out.println(str3==str5);	// false because both have different address.
		System.out.println(str4==str5);	// false because both have different address.
	}
}
