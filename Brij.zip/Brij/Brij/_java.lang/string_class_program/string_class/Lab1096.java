package string_class;

public class Lab1096 {
	public static void main(String[] args) {
		//Built-in implementation to convert charArray to String
		//Built-in implementation to convert byteArray to String
		char []chArr={'J','L','C','I','N','D','I','A'};
		byte []bArr ={65,66,67,97,98,99,49,50};
		String str1=new String(chArr);
		String str2=new String(bArr);
		System.out.println(str1);
		System.out.println(str2);
	}
}
