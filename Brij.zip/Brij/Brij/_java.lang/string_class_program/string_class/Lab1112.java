package string_class;

public class Lab1112 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder();
		System.out.println("Capacity :"+sb1.capacity());
		System.out.println("Length :"+sb1.length());
		System.out.println();
		
		StringBuilder sb2=new StringBuilder("JLC");
		System.out.println("Capacity :"+sb2.capacity());
		System.out.println("Length :"+sb2.length());
		System.out.println();
		
		StringBuilder sb3=new StringBuilder(25);
		System.out.println("Capacity :"+sb3.capacity());
		System.out.println("Length :"+sb3.length());
		
	}
}
