package string_class;

public class Lab1130 {
	public static void main(String[] args) {
		String str="A";
		StringBuilder sb=new StringBuilder("A");
		System.out.println(str.hashCode());//65 hashcode() method is overridden in String class so it generate hashcode as per content of object. 
		System.out.println(sb.hashCode());//16197143 hashcode() method is not overridden in StringBuilder class/StringBuffer class
											// so Object class hashCode() generate hashcode acc to the address of object.
						
	}

}
