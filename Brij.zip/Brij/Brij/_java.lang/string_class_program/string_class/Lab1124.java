package string_class;

public class Lab1124 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder(null);
		System.out.println(sb1); // java.lang.NullPointerException 
	}
}
 