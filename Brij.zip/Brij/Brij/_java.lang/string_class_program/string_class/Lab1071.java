package string_class;

public class Lab1071 {
	public static void main(String[] args) {
		String str="jLcIndia";
		int len=str.length();
		System.out.println(str+"\t"+len);
		String str1=str.toLowerCase();
		String str2=str.toUpperCase();
		System.out.println(str1+"\t"+str2);
	}
}
