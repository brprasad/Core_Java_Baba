package string_class;

public class Lab1082 {
	public static void main(String[] args) {
		String str="Welcome to JLC, Java Training Center, No 1 in Java Training and Placement";
		
		System.out.println(str.indexOf("Java"));//16
		System.out.println(str.indexOf("Java",16));//16
		System.out.println(str.indexOf("Java",17));//46
	}
}