package string_class;

public class Lab1122 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder("JLCINDIA");
		System.out.println(sb1);//JLCINDIA
		System.out.println("Capacity :"+sb1.capacity()); 
		System.out.println("Length :"+sb1.length());
		
		sb1.ensureCapacity(-2);
		
		//Ensures that the capacity is at least equal to the specified minimum. 
		//If the current capacity is less than the argument, then a new internal array is allocated with greater capacity. 
		//The new capacity is the larger of: The minimumCapacity argument. and	Twice the old capacity, plus 2.
		//If the minimumCapacity argument is nonpositive, this method takes no action and simply returns.
		System.out.println("Capacity :"+sb1.capacity());
		System.out.println("Length :"+sb1.length());
		
	}
}
