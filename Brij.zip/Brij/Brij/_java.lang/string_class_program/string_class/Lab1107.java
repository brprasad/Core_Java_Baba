package string_class;

public class Lab1107 {
	public static void main(String[] args) {
		String pattern="^[A-Z][A-Za-z0-9]*";	
// ->first char must be upper case and from 2nd char zero or more occurrence of upper case letter, lower case letter, digit  is valid
		
		System.out.println("".matches(pattern)); //false
		System.out.println("H".matches(pattern)); //true
		System.out.println("SRI".matches(pattern)); //true
		System.out.println("sri".matches(pattern)); //false
		System.out.println("JLC99".matches(pattern)); //true
		System.out.println("99jlc".matches(pattern)); //false 
		
	}
}
