package string_class;

public class Lab1131 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder("A");
		StringBuilder sb2=new StringBuilder("A");
		System.out.println(sb1.equals(sb2));  	
		//false because equals() method is not overridden in StringBuilder class
		// so it will call Object class equals() method which compare address 
		// so to compare content of StringBuilder class  either use contentEquals() method or 
		// first convert StringBuilder object to String object using toString() 
		// then compare using equals() method. 
												
	}
}
