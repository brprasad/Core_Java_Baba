package string_class;

import java.util.Scanner;

public class Lab1055 {
	public static void main(String[] args) {
		String str1="JLC";
		
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter JLC String :");
		String str3=sc.nextLine();
		System.out.print("Re Enter JLC String");
		String str4=sc.nextLine();
		String str5=str3.intern();	// In case of intern() method if String literal is available then it will do following task :
									// 1-> it check whether any object which is created without using new operator is pointing to this literal.
									// 2-> if object available then address will be assigned.
									// 3-> otherwise it will create the new String object(without using new operator) and that address will be assigned to ref var.
		String str6=str4.intern();
		
		System.out.println(str3==str4); //false because both String are created using new operator 
										//so they have different address stored in ref variable. 
		System.out.println(str5==str6);	// true because both String are create without using new operator 
										// so they have same address stored in ref variable.
		System.out.println(str1==str6);	// true because both String are create without using new operator 
										// so they have same address stored in ref variable.
	}
}
