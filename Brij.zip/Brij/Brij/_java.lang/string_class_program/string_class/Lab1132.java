package string_class;

public class Lab1132 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder("A");
		StringBuilder sb2=new StringBuilder("A");
		String str1=sb1.toString();
		String str2=sb2.toString();
		System.out.println(str1.equals(str2)); //true
		
		// to compare content of StringBuilder class  either use contentEquals() method or 
		// first convert StringBuilder object to String object using toString() 
		// then compare using equals() method. 
												
	}
}
