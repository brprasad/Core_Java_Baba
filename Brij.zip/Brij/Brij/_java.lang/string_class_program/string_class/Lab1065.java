package string_class;

public class Lab1065 {
	public static void main(String[] args) {
// comapreTo() will return ASCII value difference if length is same, else return length difference b/w ASCII value. 
		System.out.println("ABC".compareTo("ABC"));//0
		System.out.println("ABC".compareTo("ADO"));//-2
		System.out.println("ABC".compareTo("ABCDEFG"));//-4
		System.out.println("ABCDEFG".compareTo("ABC"));//4
		System.out.println("ABC".compareTo("DEF"));//-3
		System.out.println("ABC".compareTo("abc"));//-32
		System.out.println("ABC".compareToIgnoreCase("abc"));//0
	}
}
