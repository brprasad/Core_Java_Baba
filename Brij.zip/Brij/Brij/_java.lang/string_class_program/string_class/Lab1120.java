package string_class;

public class Lab1120 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder("JLCINDIA");
		System.out.println(sb1);//JLCINDIA
				
		sb1.insert(3, true); // insert method is overload with all data type arguments
							 // in case of boolean it will only take true/false only
							 // it is case sensitive so you can't write True/False
		System.out.println(sb1);
		
		sb1.deleteCharAt(2);	//delete char at index 2
		System.out.println(sb1);
		
		sb1.delete(3, 8);	// delete char start fromIndex to endIndex-1
		System.out.println(sb1);
		}
}
