package string_class;

public class Lab1074 {
	public static void main(String[] args) {
		String str=null;
		System.out.println(str.length());	// NullPointerException because we are calling length() on null.
	}

}
