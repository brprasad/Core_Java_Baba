package string_class;

public class Lab1113 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder(-3);
		System.out.println("Capacity :"+sb1.capacity());
		System.out.println("Length :"+sb1.length());
	}
}
