package string_class;

public class Lab1064 {
	public static void main(String[] args) {
		String str1=new String("JLC");
		String str2=new String("JLC");
		String str3=new String("jlc");
		System.out.println(str1+"\t"+str2+"\t"+str3);
		System.out.println(str1==str2);//false
		System.out.println(str1==str3);//false
		System.out.println();
		System.out.println(str1.equals(str2));//true
		System.out.println(str1.equals(str3));//false
		System.out.println(str1.equalsIgnoreCase(str3));//true
	}
}
