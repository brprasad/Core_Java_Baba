package string_class;

public class Lab1097 {
	public static void main(String[] args) {
		char []chArr={'J','L','C','I','N','D','I','A'};
		byte []bArr ={65,66,67,97,98,99,49,50};
		//if you want to copy a portion of charArray or byteArray to String then use these String overloaded constructor
		String str1=new String(chArr, 3, 5);// charArray name , starting index , number of char you want to copy. 
		String str2=new String(bArr, 3, 5);// byteArray name , starting index , number of byte you want to copy.
		System.out.println(str1);
		System.out.println(str2);
	}
}
