package string_class;

public class Lab1110 {
	public static void main(String[] args) {
		String []name={"Mainsh","Shobha","Sri","Nivas","Kumar","Dharmendra","Rahul"};
		System.out.println("\n Names: ");
		for (int i = 0; i < name.length; i++) {
			String nm=name[i];
			System.out.println(nm);
		}
		for (int i = 0; i < name.length; i++) {
			for (int j = i; j < name.length; j++) {
				if(name[i].compareTo(name[j])>0)
				{
					String temp=name[i];
					name[i]=name[j];
					name[j]=temp;
				}
			}
		}
		System.out.println("*************name in sort **************");
		for (int i = 0; i < name.length; i++) {
			String nm=name[i];
			System.out.println(nm);
		}
	}
}
