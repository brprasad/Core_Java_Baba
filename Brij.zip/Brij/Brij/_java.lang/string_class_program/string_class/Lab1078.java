package string_class;

public class Lab1078 {
	public static void main(String[] args) {
		String str="Hai, Welcome to JLC";
		System.out.println(str.endsWith("JLC"));
//true if the character sequence represented by the argument is a suffix of the character sequence 
//represented by this object; false otherwise. Note that the result will be true if the argument is the empty string 
//or is equal to this String object as determined by the equals(Object) method.
		System.out.println(str.endsWith("Welcome"));
		System.out.println();
		System.out.println(str.startsWith(""));//
		System.out.println(str.endsWith(""));//
	}
}
  