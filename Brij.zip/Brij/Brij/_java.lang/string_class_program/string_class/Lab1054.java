package string_class;

import java.util.Scanner;

public class Lab1054 {
	public static void main(String[] args) {
		String str1="JLC";
		String str2="JLC";
		System.out.println(str1==str2); // true because both String are create without using new operator 
										// so they have same address stored in ref variable.
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter JLC String :");
		String str3=sc.nextLine();
		System.out.print("Re Enter JLC String");
		String str4=sc.nextLine();
		System.out.println(str3==str4);	//false because both String are created using new operator 
										//so they have different address stored in ref variable.
	}
}
  