package string_class;

public class Lab1086 {
	public static void main(String[] args) {
		String str="JLCINDIA";
		System.out.println(str.subSequence(3, 9)); 
	}
} 