package string_class;

public class Lab1108 {
	public static void main(String[] args) {
		String str1="Website is www.jlcindia.com";
		String str2="info@jlcindia.com is id to send email";
		boolean b1=str1.regionMatches(2, str2, 5, 10); //false
		/*	1) toffset - the starting offset of the subregion in this string.
			2) other - the string argument.
			3) ooffset - the starting offset of the subregion in the string argument.
			4) len - the number of characters to compare.
		return :-
			true if the specified subregion of this string exactly matches the specified subregion of the string argument; false otherwise.
		*/ 

		System.out.println(b1);
		boolean b2=str1.regionMatches(15, str2, 5, 9); //true
		System.out.println(b2);
		boolean b3=str1.regionMatches(15, str2, 5, 12);//true
		System.out.println(b3);
		boolean b4=str1.regionMatches(15, str2, 5, 13);//false
		System.out.println(b4);
		
		String str3="INFO@JLCINDIA.COM is id to send email";
		boolean b5=str1.regionMatches(15, str3, 5, 12);//false
		System.out.println(b5);
		boolean b6=str1.regionMatches(false, 15, str3, 5, 12);//false
		/*	1) ignoreCase - if true, ignore case when comparing characters.
		 	2) toffset - the starting offset of the subregion in this string.
			3) other - the string argument.
			4) ooffset - the starting offset of the subregion in the string argument.
			5) len - the number of characters to compare.
		return :-
			true if the specified subregion of this string matches the specified subregion of the string argument; false otherwise.
			Whether the matching is exact or case insensitive depends on the ignoreCase argument.
	*/ 
		System.out.println(b6);
		boolean b7=str1.regionMatches(true, 15, str3, 5, 12);//true
		System.out.println(b7); 
		
	}
}
