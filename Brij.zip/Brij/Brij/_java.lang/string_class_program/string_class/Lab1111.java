package string_class;

public class Lab1111 {
	public static void main(String[] args) {
		String str="Welcome to JLC,Java Learing Center No 1 in Java Training and Placement. Java is a popular language";
		System.out.println(str);

		int count=0;
		for (int i = 0; i <str.length(); i++) {
			int indx=str.indexOf("Java", i);
			if(indx>=0)
			{
				i=indx;
				count++;
			}
		}
		System.out.println("Count"+count);
	}
}


