package string_class;

public class Lab1072 {
	public static void main(String[] args) {
		String str="JLC";
		String str1=str.trim();
		System.out.println(str+"\t"+str1); //JLC	JLC
		System.out.println(str==str1);//true because their is no leading and trailing space so no new String  object is created.
		
		String str2="  JLC  ";
		String str3=str.trim();
		System.out.println(str2+"\t"+str3);//  JLC  	JLC
		System.out.println(str2==str3);	//false because their is 2 leading and 2 trailing space omitted 
										//so new String object is created (without using new operator) and their address is stored in str3.
		System.out.println(str2+"\t"+str2.length());//  JLC		7
		System.out.println(str3+"\t"+str3.length());//JLC		3
	}
}
