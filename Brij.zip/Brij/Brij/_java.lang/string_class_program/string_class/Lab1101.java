package string_class;

public class Lab1101 {
	public static void main(String[] args) {
		String str="Hi, This is JLC Java Learning Center. No 1 in Java Training and Placement. Java is a popular Language";
		System.out.println(str);
		String res[]=str.split("\\."); // split based on '.' then you have place 2forward \\ and dot 
		System.out.println("Length :"+res.length);
		for (int i = 0; i < res.length; i++) {
			String str1=res[i];
			System.out.println(i+"\t"+str1);
		}
	}
}
