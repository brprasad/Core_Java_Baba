package string_class;

public class Lab1058 {

	public static void main(String[] args) {
		String str1="JLC99";		// created without using new operator, because value is known to compiler.
		String str2="JLC";			// created without using new operator, because value is known to compiler.
		final int ab=99;			
		String str3=str2+ab;		// created using new operator, because value is unknown to compiler.
		
		System.out.println(str1+"\t"+str3); //JLC99		JLC99	
		System.out.println(str1==str3);	// false because both have different address.
	}
}
