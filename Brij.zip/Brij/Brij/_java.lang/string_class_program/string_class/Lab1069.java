package string_class;

public class Lab1069 {
	public static void main(String[] args) {
		Student stu=null;
		String st=String.valueOf(stu); 	//if the argument is null, then a string equal to "null";
										//otherwise, the value of obj.toString() is returned.
		System.out.println(st);	//o/p- null;
	}
}
class Student{}