package string_class;

public class Lab1098 {
	public static void main(String[] args) {
		
		// split this string around matches of the given regExp.
		// if regular expression syntax match/valid then return the array of string computed by splitting this String 
		// else throws PatternSyntaxException 
		String str="JLC,Java Learing Center No 1 in Java Training and Placement. Java is a popular language";
		String res[]=str.split("Java"); 
		System.out.println("Length :"+res.length);
		for (int i = 0; i < res.length; i++) {
			String str1=res[i];
			System.out.println(i+"\t"+str1);
		}
	}
}
