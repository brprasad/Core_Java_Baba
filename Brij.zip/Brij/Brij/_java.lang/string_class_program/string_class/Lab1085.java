package string_class;

public class Lab1085 {
	public static void main(String[] args) {
		String str="JLCINDIA";
		//Returns a new string that is a substring of this string.
		//The substring begins with the character at the specified index and extends to the end of this string. 
		
		System.out.println(str.substring(0));
		System.out.println(str.substring(3));
		
		//Returns a new string that is a substring of this string. 
		//The substring begins at the specified beginIndex and extends to the character at index endIndex - 1.
		//Thus the length of the substring is endIndex-beginIndex. 
		System.out.println(str.substring(0,4));
		System.out.println(str.substring(3,5));
	}
}
