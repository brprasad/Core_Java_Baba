package string_class;

public class Lab1061 {
	
	public static void main(String[] args) {
		int x=10;
		System.out.println("X="+x=="X="+x);//false, it's created using new operator because compiler don't know value. 
		final int a=10;
		System.out.println("A="+a=="A="+a);//true, it's created without using new operator because compiler know value.
	}

}
