package string_class;

public class Lab1106 {
	public static void main(String[] args) {
		String pattern="[A-Za-z0-9]*";	// -> zero or more occurrence of upper case letter, lower case letter, and digit  is valid
		
		System.out.println("".matches(pattern)); //true
		System.out.println("H".matches(pattern)); //true
		System.out.println("SRI".matches(pattern)); //true
		System.out.println("sri".matches(pattern)); //true
		System.out.println("JLC99".matches(pattern)); //true
		System.out.println("99jlc".matches(pattern)); //true 
		
	}
}
