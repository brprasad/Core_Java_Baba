package string_class;

public class Lab1114 {
	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder(879898767);
		System.out.println("Capacity :"+sb1.capacity());
		System.out.println("Length :"+sb1.length());
	}
}
