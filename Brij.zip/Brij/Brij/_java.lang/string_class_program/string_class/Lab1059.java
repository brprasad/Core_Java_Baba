package string_class;

public class Lab1059 {
	public static void main(String[] args) {
		String str1="JLC99";		// created without using new operator, because value is known to compiler.
		final String str2="JLC";			// created without using new operator, because value is known to compiler.
		final int ab=99;			
		String str3=str2+ab;// created without new operator, because value is known to compiler due to final variable.
		String str4="JLC"+99;// created without new operator, because value is known to compiler.
		System.out.println(str1+"\t"+str3+"\t"+str4); //JLC99		JLC99	
		System.out.println(str1==str3);	// true because both have same address.
		System.out.println(str1==str4); // true because both have same address.
	}
}
