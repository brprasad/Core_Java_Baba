package string_class;

public class Lab1119 {

	public static void main(String[] args) {
		StringBuilder sb1=new StringBuilder("JLCINDIA");
		System.out.println(sb1);//JLCINDIA
				
		sb1.setCharAt(2, 'X');//at index 2 set X in sb1
		System.out.println(sb1);//JLXINDIA
				
		sb1.replace(4,7, "SRINIVAS");//1)start replacing from substring to this string at startindex  
									 //2)end replacing at endindex of this string.
									 //3)string you want to replace 
		System.out.println(sb1);
		
		sb1.reverse();// Reverse the string .
		System.out.println(sb1);
		

	}
}
