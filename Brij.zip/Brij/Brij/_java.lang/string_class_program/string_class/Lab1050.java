package string_class;

public class Lab1050 {
		
	public static void main(String[] args) {
		String str1="JLC";
		String str2="JLC";
		String str3="JLC";
		System.out.println(str1);//JLC
		System.out.println(str2);//JLC
		System.out.println(str3);//JLC
		System.out.println(str1==str2);//true
		System.out.println(str1==str3);//true
	}
}
  