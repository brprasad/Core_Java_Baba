package string_class;

public class Lab1053 {
	public static void main(String[] args) {
		Stud st=new Stud("SRI");
		Emp em=new Emp("SRI");
		System.out.println(st.snm==em.enm);//true
		st.show(em);
		
	}
}

class Stud
{
	String snm;
	public Stud(String snm) {
		// TODO Auto-generated constructor stub
		this.snm=snm;
	}
	void show(Emp em)
	{
		String msg="SRI";
		System.out.println(em.enm==msg);//true
		System.out.println(em.enm==snm);//true
		em.display(this);
	}
}

class Emp
{
	String enm;
	public Emp(String enm) {
		// TODO Auto-generated constructor stub
		this.enm=enm;
	}
	void display(Stud st)
	{
		String var="SRI";
		System.out.println(st.snm==var);//true
		System.out.println(st.snm==enm);//true
	}
}