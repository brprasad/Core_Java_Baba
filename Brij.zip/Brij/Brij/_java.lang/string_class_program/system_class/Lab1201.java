package system_class;

public class Lab1201 {
	public static void main(String[] args) {
		Runtime rt=null;
		//rt.new Runtime(); you can't create object of Runtime class because constructor of Runtime class is private.
		
		System.out.println(Runtime.getRuntime());
		System.out.println(Runtime.getRuntime());
		 
		rt=Runtime.getRuntime();	//because getRuntime is static method so you can call with class name.
		System.out.println(rt);
		
		System.out.println("Available Processor: "+rt.availableProcessors());
		System.out.println("Max Memory:"+rt.maxMemory());
		System.out.println("Total Memory: "+rt.totalMemory());
		System.out.println("Free Memory: "+rt.freeMemory());
		
	}
}
