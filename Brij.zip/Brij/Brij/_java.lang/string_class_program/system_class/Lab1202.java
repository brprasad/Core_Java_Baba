package system_class;

import java.io.IOException;

public class Lab1202 {
	public static void main(String[] args) throws Exception {
		Runtime rt=Runtime.getRuntime();
		Process p1=rt.exec("mspaint");
		
		String cmd[]={"notepad","D:\\abc.txt"};
		Process p2=rt.exec(cmd);
		
		String cmd1[]={"C:\\Users\\Sanjeev!99\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe","http://www.fb.com"};
		Process p3=rt.exec(cmd1);
		System.out.println("Please Enter to close all process");
		System.in.read();
		p1.destroy();
		p2.destroy();
		p3.destroy();
		System.out.println("Main Completed");
	}
}
