package system_class;

public class Lab1198 {
	public static void main(String[] args) throws Exception{
		Object ref1=new int[]{10,20,30,4,12,32};
		Object ref2=new int[]{101,102,29,125,98};
		int obj[]=new int[10];
		System.arraycopy(ref1, 0, obj, 0, 6); // use to copy array data quickly
		
		//System.arraycopy(Object src, int srcPos, Object dest, int destPos, int length)
		//fields are as following src(Source Array), srcPos(start index of srcArray),
		//dest(destination Array), destPos(start index of destArray), length(number of elements to copy)
		
		
		System.out.println("First Array Data");
		for (int i = 0; i < obj.length; i++) {
			System.out.println(i+"\t"+obj[i]); 	//First Array Data index:  0	1	2	3	4	5	6	7	8	9	
												//						  10    20  30  4  12  32   0	0	0	0
		}
		
		System.arraycopy(ref2, 1, obj, 6, 3);
		System.out.println("Second Array Data");
		for (int i = 0; i < obj.length; i++) {	//First Array Data index:  0	1	2	3	4	5	6	7	8	9
			System.out.println(i+"\t"+obj[i]);	//						  10    20  30  4  12  32  102	29 125	0
		}
	}
}
