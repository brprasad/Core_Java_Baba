
package system_class;

import java.util.Date;

public class Lab1195 {

	public static void main(String[] args) {
		long curTime =System.currentTimeMillis(); // Returns the current time in milliseconds.
		System.out.println(curTime);
		Date dt=new Date(curTime); 	//Allocates a Date object and initializes it to represent the specified number of milliseconds 
									//since the standard base time known as "the epoch", namely January 1, 1970, 00:00:00 GMT. 
		System.out.println(dt);
		
		String properties=System.getProperty("os.name");//Gets the system property indicated by the specified key.
		//Returns: the string value of the system property, or null if there is no property with that key. 
		System.out.println(properties);//Window 8
		
		System.setProperty("os.name", "win");//Sets the system property indicated by the specified key. 
		//Parameters:	key - the name of the system property.	value - the value of the system property. 

		String properties1=System.getProperty("os.name");
		System.out.println(properties1);
		
		System.setProperty("jlc.website", "www.jlcindia.com"); //Sets the system property indicated by the specified key. 
		//Parameters:	key - the name of the system property.	value - the value of the system property. 

		System.out.println(System.getProperty("jlc.website"));
		
	}
}
