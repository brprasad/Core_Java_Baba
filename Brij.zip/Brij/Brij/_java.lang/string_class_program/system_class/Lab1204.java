package system_class;

public class Lab1204 {
	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			System.out.println(Math.random());
		}
		System.out.println("************");
		for (int i = 0; i < 10; i++) {
			System.out.println(10*Math.random());
		}
	}
}
