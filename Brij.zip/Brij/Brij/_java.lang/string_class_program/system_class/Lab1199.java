package system_class;

public class Lab1199 {
	public static void main(String[] args) {
		int []arr ={40,50,60,70};
		String []arr1=new String[5];
		System.arraycopy(arr, 0, arr1, 0, arr1.length); // java.lang.ArrayStoreException 
		// int array is not compatible with String array, must be type compatible to copy an array to another.
		}
}
