package system_class;

public class Lab1203 {
	public static void main(String[] args) {
		System.out.println(Math.E);
		System.out.println(Math.PI);
		System.out.println(Math.sqrt(16));
		System.out.println(Math.pow(3, 2));
		System.out.println(Math.abs(-99));
		System.out.println(Math.max(20, 10));
		System.out.println(Math.min(20, 10));
		System.out.println(Math.max(99.9, 20.5));
		System.out.println(Math.min(99.9, 20.5));
		System.out.println(Math.ceil(10.2));
		System.out.println(Math.ceil(10.5));
		System.out.println(Math.ceil(10.9));
		System.out.println(Math.floor(10.2));
		System.out.println(Math.floor(10.5));
		System.out.println(Math.floor(10.9));
		System.out.println(Math.round(10.2));
		System.out.println(Math.round(10.5));
		System.out.println(Math.round(10.9));
		
	}
}
