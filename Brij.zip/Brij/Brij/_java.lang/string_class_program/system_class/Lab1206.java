package system_class;

import java.math.BigInteger;

public class Lab1206 {
	public static void main(String[] args) {
		//BigInteger bigint=new BigInteger("9223372036854775807");
		BigInteger bigint2=new BigInteger("-7");
		//BigInteger result=bigint.add(bigint2);
		//System.out.println(result);
		System.out.println(bigint2.bitCount()); // count total number of 1's occur in variable in bit representation.
		System.out.println(bigint2.bitLength());// count the length of variable in bits 
	
	}
}
