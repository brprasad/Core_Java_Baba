package system_class;

import java.io.FileNotFoundException;
import java.io.PrintStream;

public class Lab1197 {
	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("MESSAGE Using OUT");
		System.err.println("MESSAGE Using ERR");
		System.setOut(new PrintStream("D:\\my.txt"));
		
		for (int i = 0; i < args.length; i++) {
			System.out.println("Value:"+i);
		}
		System.err.println("MESSAGE 2 Using ERR");
	}
}
