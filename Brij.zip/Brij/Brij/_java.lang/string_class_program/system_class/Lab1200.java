package system_class;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Lab1200 {
	public static void main(String[] args) {
		String pathval=System.getenv("path"); //get the ENVIRONMENT VARIABLE value from java 5
		System.out.println(pathval);
		System.out.println();
		
		Map<?, ?> map = System.getenv(); // get the ENVIRONMENT VARIABLE in the form of key and corresponding values.
		Set<?> set=map.entrySet();
		Iterator<?> it=set.iterator();
		while (it.hasNext()) {
			Map.Entry ent = (Map.Entry)it.next();
			System.out.println(ent.getKey()+"\t"+ent.getValue());			
		}
		
	}
}
