package system_class;

import java.math.BigInteger;

public class Lab1205 {
	public static void main(String[] args) {
		BigInteger bigint=new BigInteger("4");
		System.out.println(bigint.bitCount()); // count total number of 1's occur in variable in bit representation.
		System.out.println(bigint.bitLength());// count the length of variable in bits 
		//System.out.println(Long.MAX_VALUE);
		
		long val1=9223372036854775807L;
		long val2=100;
		long result=val1+val2;
		System.out.println(result);
	}
}
