package wrapper_class;

public class Lab1136 {
	public static void main(String[] args) {
		
		// to convert Wrapper Object to Primitive you have to use of following :-
		
		Character cref= new Character('A'); // for char type use charValue() 
		char ch=cref.charValue();//Returns:the primitive char value represented by this Character object.
		System.out.println(ch); // A
		
		Boolean bolref=new Boolean(true); // for boolean type use booleanValue()
		boolean bol=bolref.booleanValue(); // Return: the primitive boolean value of this Boolean object
		System.out.println(bol);//true
		
		Float fref=new Float(300.301); // for other numeric type use xValue()  x: represent all the primitive type
		float f=fref.floatValue(); // Returns the float value of this Float object. 
		System.out.println(f);
		byte b=fref.byteValue();	//Returns the value of this Float as a byte (by casting to a byte). Overrides :	byteValue in class Number 
		System.out.println(b);
		short s=fref.shortValue(); //Returns the value of this Float as a short (by casting to a short). Overrides : shortValue in class Number
		System.out.println(s);
		int i=fref.intValue();     //Returns the value of this Float as a int (by casting to a int). Overrides : intValue in class Number
		System.out.println(i);
		long l=fref.longValue();   //Returns the value of this Float as a long (by casting to a long). Overrides : longValue in class Number
		System.out.println(l);
		double d=fref.doubleValue();//Returns the double value of this Float .Specified by:	doubleValue in class Number 
		System.out.println(d);
		
		
	}
}
