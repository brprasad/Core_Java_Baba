package wrapper_class;

public class Lab1150 {
	public static void main(String[] args) {
		Integer b1=128;	
		Integer b2=130;
		Integer b3=126;
		Integer iref1=new Integer(b1);
		Integer iref2=new Integer(b2);
		Integer iref3=new Integer(b3);
		
		System.out.println("---------compareTo(Integer)---------");
		System.out.println(iref1.compareTo(iref1));
		System.out.println(iref1.compareTo(iref2));
		System.out.println(iref1.compareTo(iref3));
		
		System.out.println("---------compare(Integer,Integer)---------");
		System.out.println(Integer.compare(iref1,iref1));
		System.out.println(Integer.compare(iref1,iref2));
		System.out.println(Integer.compare(iref1,iref3));
	}
}

