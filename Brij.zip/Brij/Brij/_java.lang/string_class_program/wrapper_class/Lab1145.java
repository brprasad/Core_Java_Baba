package wrapper_class;

public class Lab1145 {
	public static void main(String[] args) {
		Short b1=128;	
		Short b2=130;
		Short b3=126;
		Short sref1=new Short(b1);
		Short sref2=new Short(b2);
		Short sref3=new Short(b3);
		
		System.out.println("---------compareTo(Short)---------");
		System.out.println(sref1.compareTo(sref1));
		System.out.println(sref1.compareTo(sref2));
		System.out.println(sref1.compareTo(sref3));
		
		System.out.println("---------compare(Short,Short)---------");
		System.out.println(Short.compare(sref1,sref1));
		System.out.println(Short.compare(sref1,sref2));
		System.out.println(Short.compare(sref1,sref3));
	}
}
