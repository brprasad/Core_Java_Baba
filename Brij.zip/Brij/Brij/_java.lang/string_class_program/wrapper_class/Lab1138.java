package wrapper_class;

public class Lab1138 {
	public static void main(String[] args) {
		
		// to convert Wrapper Object to String use toString() method of specified Wrapper class.
		// note:- toString() method of Object class is overridden in all the Wrapper classes and it will return contents of object.
		
		Integer iref=new Integer(1234);
		String str1=iref.toString();
		System.out.println(str1);//1234
		
		Boolean bref=new Boolean("JLC");
		String str2=bref.toString();
		System.out.println(str2);//false
		
		Character cref=new Character('a');
		String str3=cref.toString();
		System.out.println(str3);//a		
	}
}
