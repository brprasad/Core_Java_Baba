package wrapper_class;

public class Lab1135 {
	
	public static void main(String[] args) {
		
		int a=10;			
		// to convert Primitive to Wrapper Object you have to use of following :-
		
		Integer iref=new Integer(a); // 1) use constructor of wrapper class with primitive as parameter
		System.out.println(iref);
		
		byte b=123;
		Byte bref =new Byte(b);		//use constructor of wrapper class with primitive as parameter
		System.out.println(bref);
		
		char ch='A';
		Character cref=new Character(ch);
		System.out.println(cref);  // use constructor of wrapper class with primitive as parameter
		
		Boolean bolref=new Boolean("10");
		System.out.println(bolref); // use constructor of wrapper class with primitive as parameter
		
		Integer iref1 =Integer.valueOf(a);	// 2) use static X.valueOf(Y val) where X:Byte,Short,Integer,Long,Float,Double
		System.out.println(iref1);         		//	Y:Corresponding primitive type 
		
		Byte bref1 =Byte.valueOf(b);		// use static X.valueOf(Y val) where X:Byte,Short,Integer,Long,Float,Double
		System.out.println(bref1);         		 //	Y:Corresponding primitive type
		
		Character cref1 =Character.valueOf(ch);	// use static X.valueOf(Y val) where X:Byte,Short,Integer,Long,Float,Double,Character,Boolean
		System.out.println(cref1);          		//	Y:Corresponding primitive type
			
		Boolean bolref1=Boolean.valueOf("true"); // use static X.valueOf(Y val) where X:Byte,Short,Integer,Long,Float,Double,Character,Boolean
		System.out.println(bolref1);
	
	} 
}
