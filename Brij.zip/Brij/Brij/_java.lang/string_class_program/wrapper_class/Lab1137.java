package wrapper_class;

public class Lab1137 {
	public static void main(String[] args) {
		
		// to convert String to Wrapper Object use the following : 
		
		String str="12345";
		Integer iref=new Integer(str); //1) use Constructor of Wrapper class with String as parameter.
		System.out.println(iref);//12345
		
		String str1="123";
		Byte bref=new Byte(str1);// use Constructor of Wrapper class with String as parameter.
		System.out.println(bref); //123
		
		Integer iref1 =Integer.valueOf(str); // 2) use X.valueOf(String val) where X:Byte,Short,Integer,Long,Float,Double,Boolean 
		System.out.println(iref1);			 // note: Character class does not have constructor with String as parameter.
		
		Boolean bolref=Boolean.valueOf(true);
		System.out.println(bolref); 
		
		String s="A";
		Character ch=new Character(s.charAt(0)); // 3) for Character class first we have to take char from String using charAt(int index)   
		System.out.println(ch);					 // then have to pass it to Character Object as parameter.
	}
}
