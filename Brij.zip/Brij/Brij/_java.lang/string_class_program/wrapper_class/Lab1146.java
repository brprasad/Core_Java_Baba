package wrapper_class;

public class Lab1146 {
	public static void main(String[] args) {
		Short b1=126;	
		Short b2=130;
		Short b3=126;
		Short sref1=new Short(b1);
		Short sref2=new Short(b2);
		Short sref3=new Short(b3);
		
		System.out.println("---------hashCode()---------");
		System.out.println(sref1.hashCode());
		System.out.println(sref2.hashCode());
		System.out.println(sref3.hashCode());
		
		System.out.println("---------equals(Byte)---------");
		System.out.println(sref1.equals(sref2));
		System.out.println(sref1.equals(sref3));
	}
}
