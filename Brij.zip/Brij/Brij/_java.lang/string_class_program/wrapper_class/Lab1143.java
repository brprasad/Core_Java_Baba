package wrapper_class;

public class Lab1143 {
	public static void main(String[] args) {
		System.out.println(Short.MAX_VALUE);
		System.out.println(Short.MIN_VALUE);
		System.out.println(Short.SIZE);
	}
}
