package wrapper_class;

public class Lab1133 {
	public static void main(String[] args) {
		 int a=123;
		 //String s1=a; inconvertible type
		 //String s2=(String)a; incompatible type 
		  
		 // so to convert Primitive value  to String value you have to use any of following :-
		 
		 String s3=""+a;	// 1) concatenate empty string with primitive value.
		 String s4=a+"";
		 System.out.println(s3);//123
		 System.out.println(s4);//123
		 
		 String s5=String.valueOf(a); // 2) use valueOf() method of String class.
		 System.out.println(s5);//123
		 
		 String s6=Integer.toString(a); // 3) use toString() method of Wrapper class
		 System.out.println(s6);//123
	}
	
}
