package wrapper_class;

public class Lab1154 {
	public static void main(String[] args) {
		long l=Long.parseLong("1010",2);
		System.out.println(l);
		Long lref=Long.valueOf("101", 2);
		System.out.println(lref);
		System.out.println(Long.parseLong("101",8));
		System.out.println(Long.valueOf("101",8));
		System.out.println(Long.parseLong("101",10));
		System.out.println(Long.valueOf("101",10));
		System.out.println(Long.parseLong("101",16));
		System.out.println(Long.parseLong("983AC",16));
		//System.out.println(Long.parseLong("983AC",8));
		//System.out.println(Long.parseLong("983TAC",8));
		
	}
}
