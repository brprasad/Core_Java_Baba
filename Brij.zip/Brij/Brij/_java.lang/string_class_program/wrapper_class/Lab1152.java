package wrapper_class;

public class Lab1152 {
	public static void main(String[] args) {
		System.out.println(Long.MAX_VALUE);
		System.out.println(Long.MIN_VALUE);
		System.out.println(Long.SIZE);
	}
}
