package wrapper_class;

public class Lab1156 {
	public static void main(String[] args) {
		Long b1=126L;	
		Long b2=130L;
		Long b3=126L;
		Long lref1=new Long(b1);
		Long lref2=new Long(b2);
		Long lref3=new Long(b3);
		
		System.out.println("---------hashCode()---------");
		System.out.println(lref1.hashCode());
		System.out.println(lref2.hashCode());
		System.out.println(lref3.hashCode());
		
		System.out.println("---------equals(Byte)---------");
		System.out.println(lref1.equals(lref2));
		System.out.println(lref1.equals(lref3));
	}
}
