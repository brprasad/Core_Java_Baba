package wrapper_class;

public class Lab1153 {
	public static void main(String[] args) {
		String str=Long.toBinaryString(65L);
		System.out.println(str);
		System.out.println(Long.toHexString(65L));
		System.out.println(Long.toOctalString(65L));
	}
}
