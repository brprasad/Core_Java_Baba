package wrapper_class;

public class Lab1144 {
	public static void main(String[] args) {
		Short b1=Short.parseShort("101",2);
		System.out.println(b1);
		Short bref=Short.valueOf("101",2);
		System.out.println(bref);
		System.out.println(Short.parseShort("101",8));
		System.out.println(Short.valueOf("101",8));
		System.out.println(Short.parseShort("101",10));
		System.out.println(Short.valueOf("101",10));
		System.out.println(Short.parseShort("101",16)); 
		System.out.println(Short.valueOf("101",16));
		//System.out.println(Short.parseShort("128",8));	// 128 is not represented in radix:8
															//because it contain number in 0-7 digit range only. 		
	
	}
}
