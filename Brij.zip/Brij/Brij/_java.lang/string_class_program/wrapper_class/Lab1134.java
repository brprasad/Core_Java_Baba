package wrapper_class;

public class Lab1134 {
	public static void main(String[] args) {
		 String str="99";
		 //int a = str; inconvertible type
		 //int a1=(int)str; incompatible type
		  
		 // so to convert String value to Primitive value you have to use of following :-
		 
		char ch=str.charAt(3);	// for char type use charAt(int index) method;
		System.out.println(ch);
		
		int a=Integer.parseInt(str); // for other numeric type use Y.parseX(String s) where X:Byte,Short,Integer,Long,Float,Double
		System.out.println(a);			//	Y:Corresponding primitive type , Note value must be assignment compatible to method call 
										//	else it throw java.lang.NumberFormatExeption
		
		//byte b=Byte.parseByte("129"); throw java.lang.NumberFormatExeption
		//int x=Integer.parseInt("9898945345235"); throw java.lang.NumberFormatExeption
		//int y=Integer.parseInt("12.0"); throw java.lang.NumberFormatExeption
		
		boolean bol=Boolean.parseBoolean(str); // for boolean type use Boolean.parseBoolean(String s)
		System.out.println(bol);			   //Parses the string argument as a boolean. 
											   // The boolean returned represents the value true if the string argument is not null 
											   // and is equal ignoring case to the string "true" else return "false"
		
		
	}
	
}
