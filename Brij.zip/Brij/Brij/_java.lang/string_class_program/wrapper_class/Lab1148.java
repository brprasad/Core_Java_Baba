package wrapper_class;

public class Lab1148 {
	public static void main(String[] args) {
		String str=Integer.toBinaryString(65);
		System.out.println(str);
		System.out.println(Integer.toHexString(65));
		System.out.println(Integer.toOctalString(65));
	}
}
