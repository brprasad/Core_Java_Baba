package lab1213;

public class Lab1213 {
	public static void main(String[] args) throws CloneNotSupportedException {
		Student s1=new Student(99);
		System.out.println(s1.sid);
		Student s2=s1.myclone();
		System.out.println(s2.sid);
		System.out.println(s1==s2);
	}
}
 
interface JLCCloneable{} //marker interface used to provide special message to JVM about our class. 

class Student implements JLCCloneable{
	int sid;
	Student(int sid){
		this.sid=sid;
	}
	public Student myclone() throws CloneNotSupportedException
	{
		if(this instanceof JLCCloneable)
			return new Student(sid);
		else
			throw new CloneNotSupportedException("Implements JLCCloneable ");
	}
}
