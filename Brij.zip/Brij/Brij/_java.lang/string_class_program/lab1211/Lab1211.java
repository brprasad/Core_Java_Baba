package lab1211;

public class Lab1211 { // singleton class
	public static void main(String[] args) {
		Hello h =Hello.getHello();
		System.out.println(h);
		System.out.println(Hello.getHello());
		System.out.println(Hello.getHello());
		Hello h2=(Hello)h.clone();
		System.out.println(h2);
		System.out.println(h2==h);
	}
}
class Hello{
	private static Hello INS=new Hello();
	private Hello(){}
	public static Hello getHello(){
		return INS;
	}
	protected Object clone() // since we are not overriding clone() method in Hello class 
	{// so other user can't clone the Hello class object , it simply return current class object only.
		return this;
	}
}
