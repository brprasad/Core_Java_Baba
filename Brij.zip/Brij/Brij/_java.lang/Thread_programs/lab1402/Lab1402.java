package lab1402;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Lab1402 { 		// Thread Pool
	public static void main(String[] args) {
		MyThread th1= new MyThread();
		ExecutorService ser = Executors.newFixedThreadPool(2); 	
		//Creates a thread pool that reuses a fixed number of threads operating off a shared unbounded queue.
		//At any point, at most nThreads threads will be active processing tasks.
		//If additional tasks are submitted when all threads are active, they will wait in the queue until a thread is available.
		//If any thread terminates due to a failure during execution prior to shutdown, a new one will take its place
		//if needed to execute subsequent tasks. The threads in the pool will exist until it is explicitly shutdown.
		//Parameters: nThreads the number of threads in the pool 		Returns: the newly created thread pool 
		//Throws: IllegalArgumentException - if nThreads <= 0
		
		for (int i = 0; i < 5; i++) {
			ser.execute(th1); //Executes the given command at some time in the future.
			//The command may execute in a new thread, in a pooled thread, or in the calling thread, at the discretion of the Executor implementation.

		} 
	}
}
class MyThread implements Runnable {
	@Override
	public void run() {
		Thread th=Thread.currentThread();
		for (int i = 0; i < 5; i++) {
			try {
					Thread.sleep(500);
			} catch (Exception e) { e.printStackTrace(); }
			
			System.out.println(th.getName()+" task Completed");
		}
	}
}
