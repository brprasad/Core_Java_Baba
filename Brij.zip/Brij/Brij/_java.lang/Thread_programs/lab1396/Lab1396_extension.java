package lab1396;

public class Lab1396_extension {
	public static void main(String[] args) {
		
		Hello h = new Hello();
		h.start();
		try {
			h.join();
		} catch (Exception e) {	}
		System.out.println("Happy New Year 2015");
	}
}

class Hello extends Thread {
	@Override
	public void run() {

		try {
			for (int i = 10; i >= 1; i--) {
				System.out.println("Tick-Tick :" + i);
				Thread.sleep(500);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
 