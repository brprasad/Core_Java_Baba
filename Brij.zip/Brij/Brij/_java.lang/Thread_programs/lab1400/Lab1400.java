package lab1400;

public class Lab1400 { 
	public static void main(String[] args) {
		CThread th1=new CThread("nivas", "jlcindia");
		CThread th2=new CThread("dande", "javasri");
		th1.start();
		th2.start();
	}
}

class CThread extends Thread{
	static Service sev=new Service();
	String unm;
	String pwd;
	public CThread(String unm, String pwd) {
		this.unm=unm;
		this.pwd=pwd;
	}
	@Override
	public void run() {
		sev.verifyUser(unm, pwd);
	}
}

class Service{
	void verifyUser(String unm, String pwd){
		Thread th=Thread.currentThread();
		for (int i = 0; i < 5; i++) {
			System.out.println(th.getName()+"\t"+i+"\t verifing "+unm+"\t"+pwd);
			try {
					Thread.sleep(500);
			} catch (Exception e) {e.printStackTrace();	}
		}
	}
}
