package lab1390;

public class Lab1390 {
	public static void main(String[] args) {
		Hello h1=new Hello();
		MyThread t1=new MyThread(h1);
		MyThread t2=new MyThread(h1);
		t1.start();
		t2.start();
	}
}
class MyThread extends Thread{
	Hello h=null;
	public MyThread(Hello h) {
		this.h=h;
	}
	@Override
	public void run() {
		h.show();
	}
}

class Hello{
	synchronized void show(){	// synchronized method 
		for (int i = 0; i < 5; i++) {
			try {
					System.out.println(Thread.currentThread().getName()+ " SHOW() is "+i+" by "+this);
					wait(500);	// calling wait() will place thread into WAIT state by release the object lock immediately.
								// note:- wait() method have to release the lock of an object, so before calling wait() method 
								// that object lock must be enable, else it will throw IllegalMonitorStateException.
					
					//Thread.sleep(500); //--> calling sleep() method will place the thread to SLEEP state 
										 //and in SLEEP state thread will hold the resource lock (ie object lock). 	
					
			} catch (Exception e) {e.printStackTrace();	}
		}
		
	}
}