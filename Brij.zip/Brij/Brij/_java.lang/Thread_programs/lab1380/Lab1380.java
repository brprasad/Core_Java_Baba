package lab1380;

public class Lab1380 {
	public static void main(String[] args) {
		MyThread t=new MyThread();
		t.setPriority(0);		//Exception in thread "main" java.lang.IllegalArgumentException
								// at java.lang.Thread.setPriority(Unknown Source)	at lab1380.Lab1380.main(Lab1380.java:6)
		
		t.setPriority(11);
		System.out.println(t);
	}
}
class MyThread extends Thread{ }