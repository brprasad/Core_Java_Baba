package lab1392;

import java.util.ArrayList;

public class Lab1392 {
	public static void main(String[] args) {
		Hello h1=new Hello();
		MyThread t1=new MyThread(h1);
		MyThread t2=new MyThread(h1);
		t1.start();
		t2.start();
	}
}
class MyThread extends Thread{
	Hello h=null;
	public MyThread(Hello h) {
		this.h=h;
	}
	@Override 
	public void run() {
		h.show();
	}
}

class Hello{
	void show(){	
		
		ArrayList al=new ArrayList();
		
		synchronized(al){	// Locking 3rd party object
			for (int i = 0; i < 5; i++) {
				try {
						System.out.println(Thread.currentThread().getName()+ " SHOW() is "+i+" by "+this);
						//wait(500);	// java.lang.IllegalMonitorStateException because current object is not locked by any thread 
										// and we are calling wait() on current object.
						
						al.wait(1000);  //o/p in case al.wait(1000) --- both thread run concurrently(parallel)
										 
						 	
				} catch (Exception e) {e.printStackTrace();	}
			}
		}
	}
}