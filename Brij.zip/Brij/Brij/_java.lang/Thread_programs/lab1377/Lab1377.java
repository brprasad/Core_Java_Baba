package lab1377;

public class Lab1377 {
	ThreadGroup tg=new ThreadGroup("JLC");
	MyThread t1= new MyThread(tg,"Hello");
	MyThread t2= new MyThread(tg, "Hai");
}

class MyThread implements Runnable{
	public MyThread(ThreadGroup tg, String tname) {
		Thread t=new Thread(tg,this,tname);
		t.start();
	}
	@Override
	public void run() {
		Thread t=Thread.currentThread();
		ThreadGroup tg=t.getThreadGroup();
		System.out.println("Thread Name: "+t.getName());
		System.out.println("ThreadGroup Name :"+tg.getName());
		
	}
} 