package lab1372;

public class Lab1372 {
	public static void main(String[] args) {
		MyThread t1=new MyThread();
		MyThread t2=new MyThread();
	}
}

class MyThread extends Thread{
	public MyThread() {
		this.start();	//Causes this thread to begin execution; the Java Virtual Machine calls the run method of this thread. 
//The result is that two threads are running concurrently: the current thread (which returns from the call to the start method) and the other thread (which executes its run method). 
//It is never legal to start a thread more than once. In particular, a thread may not be restarted once it has completed execution.

	}
	@Override
	public void run() {
		Thread th=Thread.currentThread();	//Returns a reference to the currently executing thread object.
		ThreadGroup tg=th.getThreadGroup();	//Returns the thread group to which this thread belongs. 
											//This method returns null if this thread has died (been stopped).
		System.out.println("Thread Name :"+th);
		System.out.println("ThreadGroup Name :"+tg.getName());
	}
}