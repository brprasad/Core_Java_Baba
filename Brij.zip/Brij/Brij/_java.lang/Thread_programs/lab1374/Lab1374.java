package lab1374;

public class Lab1374 {
	public static void main(String[] args) {
		MyThread t1=new MyThread("Hello");
		MyThread t2=new MyThread("Hai");
	}
}

class MyThread extends Thread{
	public MyThread(String name) {
		super(name);
		start();
	}
	@Override
	public void run() {
		Thread th=Thread.currentThread();
		ThreadGroup tg=th.getThreadGroup();
		System.out.println("Thread Name: "+th.getName());
		System.out.println("ThreadGroup Name:"+tg.getName());
	}
}