package lab1383;

public class Lab1383 {
	public static void main(String[] args) {
		ThreadGroup tg=new ThreadGroup("JLC");
		MyThread t=new MyThread(tg,"Hello");
		
		t.setPriority(9);			//Changes the priority of this thread. 
		System.out.println(t);		//Thread[Hello,9,JLC] 
		}
}
class MyThread extends Thread{ 
	MyThread(ThreadGroup tg, String tname){
		super(tg, tname);
	}
}

