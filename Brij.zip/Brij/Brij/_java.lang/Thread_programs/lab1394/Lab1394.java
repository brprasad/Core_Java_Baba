package lab1394; 

public class Lab1394 {
	public static void main(String[] args) {	
		Thread th1=Thread.currentThread();		// if you are executing multiple threads then separate STACK will be created for each thread. 
		MyThread th2=new MyThread(th1);			// when any exception is occurred in one thread execution then other thread execution will not be terminated. 
		th2.start();
		
		for (char ch='A'; ch<'L';ch++) {
			System.out.println(th1.getName()+"\t"+ch+"\t Main "+th1.isAlive()+" MyThread : "+th2.isAlive()+" Threadcount : "+Thread.activeCount());
	
			if(ch=='F'){	int x=10/0;		}	//main thread is not active but thread activeCount is 2 because main thread is parent thread 
												//so it will not destroy until all its child thread complete their work. 
			try {
				Thread.sleep(500);
			} catch (Exception e) {
				
			}
		}
	} 
}

class MyThread extends Thread{
	Thread main;
	public MyThread(Thread main) {
		this.main=main;
	} 	
	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println(getName()+"\t"+i+"\t Main "+main.isAlive()+" MyThread : "+isAlive()+" Threadcount: "+Thread.activeCount());
	
			try {
					Thread.sleep(500);
			} catch (Exception e) {e.printStackTrace();		}
		}
	}
}