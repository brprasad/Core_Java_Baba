package lab1393;

import java.util.concurrent.PriorityBlockingQueue;

public class Lab1393_extension {	//PriorityBlockingQueue (Producer-Consumer Problem Solution)
	public static void main(String[] args) {
		PriorityBlockingQueue st = new PriorityBlockingQueue();
		PThread pt=new PThread(st);
		CThread ct=new CThread(st);
		
	}
	
	
}

class PThread extends Thread{
	PriorityBlockingQueue st;
	
	public PThread(PriorityBlockingQueue st) {
		this.st=st;
		start();
	}
	@Override
	public void run() {
		for (int i = 1; i <=5; i++) {
			try {
					st.put(i);
					System.out.println(i+" is produced");
					Thread.sleep(1000);
			} catch (Exception e) {e.printStackTrace();	}
		}
	}
} 

class CThread extends Thread{
	PriorityBlockingQueue st;
	
	public CThread(PriorityBlockingQueue st) {
		this.st=st;
		start();
	}
	@Override
	public void run() {
		for (int i = 1; i <=5; i++) {
			try {
					while(true)
					{
						System.out.println(st.take()+" is consumed ");
						Thread.sleep(1000);
					}
					
			} catch (Exception e) {e.printStackTrace();	}
		}
	}
}