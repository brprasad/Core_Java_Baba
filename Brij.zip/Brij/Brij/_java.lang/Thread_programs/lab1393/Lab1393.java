package lab1393;
	
public class Lab1393 {								// ITC(interThreadCommunication) 
													// solution of Producer-Consumer Problem
	public static void main(String[] args) {
		Stack s=new Stack();
		A aobj =new A(s, "A");
		B bobj =new B(s, "B");
	}
}
class A implements Runnable{
	Stack s=null; 
	public A(Stack s, String tname) {
		Thread t1=new Thread(this, tname);
		this.s=s;
		t1.start();
	}
	@Override
	public void run() {
		for (int i = 1; i < 5; i++) {
			s.push(i);
		}
	}
}
class B implements Runnable{
	Stack s=null;
	public B(Stack s, String tname) {
		Thread t2=new Thread(this, tname);
		this.s=s;
		t2.start();
	}
	@Override
	public void run() {
		for (int i = 1; i < 5; i++) {
			s.pop();
		}
	}
}
class Stack{
	int x;
	boolean flag=false;
	public synchronized void push(int x){
		if(flag){
			try {
					wait();
			} catch (Exception e) {e.printStackTrace();	}
		}
		this.x=x;
		System.out.println(x +" is Pushed");
		try {
			Thread.sleep(1000);
		} catch (Exception e){e.printStackTrace();	}
		flag=true;
		notify();
	}
	public synchronized int pop(){
		if(!flag){
			try {
					wait();
			} catch (Exception e) {e.printStackTrace();	}
		}
		System.out.println(x +" is Poped");
		try {
			Thread.sleep(1000);
		} catch (Exception e){e.printStackTrace();	}
		flag=false;
		notify();
		return x;
	}
}
