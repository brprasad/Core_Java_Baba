package lab1391;

import java.util.ArrayList;

public class Lab1391 {
	public static void main(String[] args) {
		Hello h1=new Hello();
		MyThread t1=new MyThread(h1);
		MyThread t2=new MyThread(h1);
		t1.start();
		t2.start();
	}
}
class MyThread extends Thread{
	Hello h=null;
	public MyThread(Hello h) {
		this.h=h;
	}
	@Override 
	public void run() {
		h.show();
	}
}

class Hello{
	synchronized void show(){	//Locking Current object
		
		ArrayList al=new ArrayList();
		for (int i = 0; i < 5; i++) {
			try {
					System.out.println(Thread.currentThread().getName()+ " SHOW() is "+i+" by "+this);
					wait(500);		// o/p in case wait(1000) --- both thread run concurrently(parallel)
					
					//al.wait(1000); //o/p in case al.wait(1000) 
									 // java.lang.IllegalMonitorStateException because object al is not locked by any thread 
									// and we are calling wait() on al.
					
			} catch (Exception e) {e.printStackTrace();	}
		}
		
	}
}
