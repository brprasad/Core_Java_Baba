package lab1371;

public class Lab1371 {
	public static void main(String[] args) {
		
		MyThread th= new MyThread();	//step 4
		Thread t1=new Thread(th);		//step 5
		Thread t2=new Thread(th);
		t1.start();						//step 6
		t2.start();
		
		Thread t=Thread.currentThread();
		for (int i = 0; i < 5; i++) {
			System.out.println(t.getName()+"\t value is "+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

class MyThread implements Runnable{		//step 1
	@Override
	public void run() {		//step 2
		Thread th=Thread.currentThread();							//step 3
		for (int i = 0; i < 5; i++) {								//
			System.out.println(th.getName()+"\t value is "+i);		//
			try {													//
				Thread.sleep(1000);									//	
			} catch (InterruptedException e) {						//
				e.printStackTrace();								//
			}														//
		}															//
	}																															
}