package lab1370;

public class Lab1370 {
	public static void main(String[] args) {
		MyThread t1=new MyThread();	//step 4
		MyThread t2=new MyThread();		
		t1.start();	//step 5
		t2.start();
		
		Thread t=Thread.currentThread();
		for (int i = 100; i <105; i++) {
			System.out.println(t.getName()+"\t value is"+i);
			try {
				Thread.sleep(500);
			} catch (Exception e) {
				
			}
		}
		
	}
}

class MyThread extends Thread{ 	//step 1
	@Override
	public void run() {	//step 2
		Thread th =Thread.currentThread();   						//step 3 
		for (int i = 0; i <5; i++) {								//
			System.out.println(th.getName()+"\t value is"+i);		//
			try {													//
				Thread.sleep(500);									//
			} catch (Exception e) {	}								//
		}															//
	}																//	
}