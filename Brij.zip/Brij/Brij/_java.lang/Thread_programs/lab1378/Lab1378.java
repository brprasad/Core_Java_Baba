package lab1378;

public class Lab1378 {

	ThreadGroup tg=new ThreadGroup("JLC");
	MyThread t1= new MyThread(tg);
	MyThread t2= new MyThread(tg);
}

class MyThread implements Runnable{
	public MyThread(ThreadGroup tg) {
		Thread t=new Thread(tg,this); // this denote current thread and is passed to thread constructor so that
									  // jvm would be able to set threadGroupname, ie current thread is belong to which Threadgroup. 
		t.start();
	}
	@Override
	public void run() {
		Thread t=Thread.currentThread();
		ThreadGroup tg=t.getThreadGroup();
		System.out.println("Thread Name: "+t.getName());
		System.out.println("ThreadGroup Name :"+tg.getName());
		
	}
} 
