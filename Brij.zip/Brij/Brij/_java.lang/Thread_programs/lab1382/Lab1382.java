package lab1382;

public class Lab1382 {
	public static void main(String[] args) {
		MyThread t=new MyThread();
		t.setName("Hello");			//Changes the name of this thread to be equal to the argument name. 
		System.out.println(t);		//Thread[Hello,5,main] 
		}
}
class MyThread extends Thread{ }
