package lab1376;

public class Lab1376 {
	public static void main(String[] args) {
		ThreadGroup tg=new ThreadGroup("JLC");
		MyThread t1 =new MyThread(tg, "Hello");
		MyThread t2 =new MyThread(tg, "Hai");
	}
}
class MyThread extends Thread{
	public MyThread(ThreadGroup tg, String tname) {
		super(tg, tname);
		start();
	}
	@Override
	public void run() {
		Thread th=Thread.currentThread();
		ThreadGroup tg=th.getThreadGroup();
		System.out.println("Thread Name: "+th.getName());
		System.out.println("ThreadGroup Name:"+tg.getName());
	}
}