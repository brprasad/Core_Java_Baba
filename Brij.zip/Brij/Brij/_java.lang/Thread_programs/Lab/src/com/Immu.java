package com;

public class Immu {
	public static void main(String args) {
		Student stu = new Student(1, "Rahul", "rahul@ignou.com", 9999);
		System.out.println(stu);
	}
}

final class Student {
	private final int sid;
	private final String sname;
	private final String email;
	private final int phone;

	Student(int sid, String sname, String email, int phone) {
		this.sid = sid;
		this.sname = sname;
		this.email = email;
		this.phone = phone;
	}

	public int getSid() {
		return sid;
	}

	public String getSname() {
		return sname;
	}

	public String getEmail() {
		return email;
	}

	public int getPhone() {
		return phone;
	}

	public String toString() {
		return sid + " " + sname + " " + email + " " + phone;

	}
}