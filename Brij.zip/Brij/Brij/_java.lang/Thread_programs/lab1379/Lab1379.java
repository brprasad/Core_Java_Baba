package lab1379;

public class Lab1379 {
	public static void main(String[] args) {
		MyThread t1=new MyThread();
		MyThread t2=new MyThread();
		t1.setName("Hello");
		t2.setName("Hai");
		t1.start();		
		t2.start();
	}
}

class MyThread extends Thread{
	public void run() {
		Thread th=Thread.currentThread();
		ThreadGroup tg=th.getThreadGroup();
		System.out.println("Thread Name: "+th.getName());
		System.out.println("ThreadGroup Name:"+tg.getName());
	}
}

