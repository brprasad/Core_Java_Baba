package lab1397;

public class Lab1397 {
	public static void main(String[] args) {	
		Thread th1=Thread.currentThread();		// if you are executing multiple threads then separate STACK will be created for each thread. 
		MyThread th2=new MyThread(th1);			// when any exception is occurred in one thread execution then other thread execution will not be terminated. 
		th2.start();
		
		for (char ch='A'; ch<'L';ch++) {
			System.out.println(th1.getName()+"\t"+ch+"\t Main "+th1.isAlive()+" MyThread : "+th2.isAlive()+" Threadcount : "+Thread.activeCount());
			try {
					Thread.sleep(500);
			} catch (Exception e) {	}
		}
	} 
}

class MyThread extends Thread{
	Thread main;
	public MyThread(Thread main) {
		this.main=main;
	} 	
	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println(getName()+"\t"+i+"\t Main "+main.isAlive()+" MyThread : "+isAlive()+" Threadcount: "+Thread.activeCount());
			try {
					if(i==3) 
						main.join();	 // if condition is true then Thread-main will join the current thread ie Thread-0
										//and after completing the task of Thread-main control will return to Thread-0 for remaining task.
			
					Thread.sleep(500);
			} catch (Exception e) {e.printStackTrace();		}
		}
	}
}

