package lab1384;

public class Lab1384 {
	public static void main(String[] args) throws InterruptedException {
		MyThread t1=new MyThread();
		System.out.println(t1.getState());
		t1.start();
		System.out.println(t1.getState());
		Thread.sleep(100);
		System.out.println(t1.getState());
		t1.sleep(5000);
		System.out.println(t1.getState());
		
	}
}

class MyThread extends Thread {
	@Override
	public void run() {
		Thread th= Thread.currentThread();
		for (int i = 0; i < 5; i++) {
			System.out.println("Thread Name: "+th.getName()+"\t value is "+i+"\t state :"+th.getState());			
			try {
				Thread.sleep(500);
			} catch (Exception e) { e.printStackTrace(); }
		}
	}
}