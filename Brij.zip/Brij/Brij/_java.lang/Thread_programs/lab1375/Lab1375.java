package lab1375;

public class Lab1375 {
	public static void main(String[] args) {
		MyThread t1=new MyThread("Hello");
		MyThread t2=new MyThread("Hai");
	}
}

class MyThread implements Runnable{
	public MyThread(String name) {
		Thread t=new Thread(this,name);
		t.start();
	}
	@Override
	public void run() {
		Thread th=Thread.currentThread();
		ThreadGroup tg=th.getThreadGroup();
		System.out.println("Thread Name: "+th.getName());
		System.out.println("ThreadGroup Name:"+tg.getName());
	}
}