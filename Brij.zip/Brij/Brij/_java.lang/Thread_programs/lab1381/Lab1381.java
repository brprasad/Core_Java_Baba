package lab1381;

public class Lab1381 {
	public static void main(String[] args) {
		MyThread t=new MyThread();
		t.setPriority(10);	//Changes the priority of this thread. 
		System.out.println(t);		// Thread[Thread-0,10,main]
	}
}
class MyThread extends Thread{ }
