package lab1395;

public class Lab1395 {
	public static void main(String[] args) {	
		Thread th1=Thread.currentThread();		// if you are executing multiple threads then separate STACK will be created for each thread. 
		MyThread th2=new MyThread(th1);			// when any exception is occurred in one thread execution then other thread execution will not be terminated. 
		th2.start();
		
		for (char ch='A'; ch<'L';ch++) {
			System.out.println(th1.getName()+"\t"+ch+"\t Main "+th1.isAlive()+" MyThread : "+th2.isAlive()+" Threadcount : "+Thread.activeCount());
	
			try {
				Thread.sleep(500);
			} catch (Exception e) {
				
			}
		}
	} 
}

class MyThread extends Thread{
	Thread main;
	public MyThread(Thread main) {
		this.main=main;
	} 	
	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println(getName()+"\t"+i+"\t Main "+main.isAlive()+" MyThread : "+isAlive()+" Threadcount: "+Thread.activeCount());

			if(i==3){	int x=10/0;		}	//Thread-0 thread is not active so thread activeCount is 1 because Thread-0 is child thread of main thread.
			try {
					Thread.sleep(500);
			} catch (Exception e) {e.printStackTrace();		}
		}
	}
}
