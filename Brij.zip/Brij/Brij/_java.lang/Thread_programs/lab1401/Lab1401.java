package lab1401;

public class Lab1401 {
	public static void main(String[] args) {  
		Runnable r=new Runnable() {	// anonymous class
			public void run() {	
				Thread th=Thread.currentThread();
				for (int i = 0; i < 5; i++) {
					System.out.println(th.getName()+"\t"+i);
				}
			}	
		};
		
		Thread t1=new Thread(r);
		Thread t2=new Thread(r);
		t1.start();
		t2.start();
	}
}


