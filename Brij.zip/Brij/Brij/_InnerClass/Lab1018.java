abstract class Person
{
	public abstract void sleeping();
}
class Student extends Person
{
	public void sleeping()
	{
		System.out.println("Student -> sleeping()");
	}
}
class Lab1018
{
	public static void main(String[] args)
	{
		Person person =new Student();
		person.sleeping();
	}
}