class Outer
{	
	interface Inter1{}
	interface Inter2 extends Inter1{}
	class Inner1 implements Inter2{}
	class Inner2 extends Inner1{}
	private abstract class Inner3{}
	class Hello extends Inner3{}
	
}
class Lab1000
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");
	}
}