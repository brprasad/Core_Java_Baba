class Outer
{
	int a=10;
	static int b=20;
	void m1()
	{
		System.out.println("Outer-> m1()");
	}
	static void m2()
	{
		System.out.println("Outer-> m2()");
	}
	class Inner		// instance Inner class
	{				// all the static & instance member of Outer class can be access in instance class Directly.
		int x=11;
		void show()
		{
			System.out.println("Inner ->show()");
			System.out.println(a);
			System.out.println(b);
			System.out.println(x);
			m1();
			m2();
		}
	}
}


class Lab992
{
	public static void main(String[] args)
	{
		Outer out=new Outer();
		out.m1();	
		out.m2();
		Outer.Inner in=new Outer().new Inner();
		in.show();
	}
}