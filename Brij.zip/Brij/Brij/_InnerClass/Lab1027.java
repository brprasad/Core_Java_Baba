import java.io.*;
abstract class Hello{}
class Hai extends Hello{}
interface Ball{}
interface Shape{}

class Lab1027
{
	public static void main(String[] args)
	{
		// all object creation are valid.
		Hello h1=new Hai();						// object of Hai class.
		Hello h2=new Hai(){};					// sub class of Hai class or anonymous inner class .
		Hello h3=new Hello(){};					// sub class of Hello class or anonymous inner class .
		Cloneable c=new Cloneable(){};			// sub class of Cloneable interface or anonymous inner class.
		Serializable s=new Serializable(){};	// sub class of Serializable interface or anonymous inner class.
		Ball b=new Ball(){};					// sub class of Ball interface or anonymous inner class .
		Shape shape =new Shape(){};				// sub class of Shape interface or anonymous inner class .
	}
}