/* Lab1019.java:10: error: Person is abstract; cannot be instantiated
                Person person =new Person();
                               ^
1 error*/

abstract class Person
{
	public abstract void sleeping();
}

class Lab1019
{
	public static void main(String[] args)
	{
		Person person =new Person(); //Person is abstract; cannot be instantiated
	}
}