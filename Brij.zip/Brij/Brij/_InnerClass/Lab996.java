class Outer
{
	class Inner
	{
		final static int A=10;  	// only final static variable i.e constant variable declarations is allowed in inner class.
	}
}
class Lab996
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");
	}
}