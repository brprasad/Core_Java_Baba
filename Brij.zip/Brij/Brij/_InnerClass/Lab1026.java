/*Lab1026.java:11: error: Hello is abstract; cannot be instantiated
                Hello h=new Hello();                            
                        ^
Lab1026.java:12: error: Cloneable is abstract; cannot be instantiated
                Cloneable c=new Cloneable();           
                            ^
Lab1026.java:13: error: Serializable is abstract; cannot be instantiated
                Serializable s=new Serializable();      
                               ^
Lab1026.java:14: error: Ball is abstract; cannot be instantiated
                Ball b=new Ball();                                      
                       ^
Lab1026.java:15: error: Shape is abstract; cannot be instantiated
                Shape shape =new Shape();                      
                             ^
5 errors*/

import java.io.*;
abstract class Hello{}
class Hai extends Hello{}
interface Ball{}
interface Shape{}

class Lab1026
{
	public static void main(String[] args)
	{
		Hello h=new Hello();				// 
		Cloneable c=new Cloneable();		//
		Serializable s=new Serializable();	// all object creation are invalid.
		Ball b=new Ball();					//
		Shape shape =new Shape();			//
	}
}