/*Lab1029.java:12: error: incomparable types: <anonymous Hello> and <anonymous Hello>
                System.out.println(new Hello(){} == new Hello(){});
                                                 ^
1 error*/

class Hello{}

class Lab1029
{
	public static void main(String[] args)
	{
		Hello h1=new Hello(){};					// sub class of Hello class or anonymous inner class.
		Hello h2=new Hello(){};					// sub class of Hello class or anonymous inner class.
		System.out.println(h1);					// contain object h1 address
		System.out.println(h2);					// contain object h2 address
		System.out.println(h1==h2);				// o/p is false because two object address will never be same.
		System.out.println(new Hello(){} == new Hello(){});	// we can't compare anonymous class object at run time(dynamically)	
															// because no inheritance relation so give error incomprable types.
		
	}
}