/*Lab1023.java:29: error: cannot find symbol
                person.reading();
                      ^
  symbol:   method reading()
  location: variable person of type Person
1 error*/

abstract class Person
{
	public abstract void sleeping();
}

class Lab1023
{
	public static void main(String[] args)
	{
		Person person =new Person()
		{ // anonymous inner class declaration or creating subclass of Person 
			void reading()  //new method in sub class. so achive dynamic dispatch sub class method sign must be present 
			{				// in super class 
				System.out.println("Student -> reading()");
			}
			public void sleeping()// overriden method of Person class in sub class.
			{
				System.out.println("Student -> sleeping()");
			}
		};
		person.sleeping();
		person.reading(); 
	}
}