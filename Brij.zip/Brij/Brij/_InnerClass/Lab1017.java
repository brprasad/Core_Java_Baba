class Outer
{
	void m1() // method is non-static 
	{
		final int a=10;
		class Inner1 // local inner class in method m1 i.e scope of that class Inner1 is method m1() scope.
		{ 
			void show()
			{
				System.out.println(a); 
			}
		}
	new Inner1().show();
	}
}
class Lab1017
{
	public static void main(String[] args)
	{
		new Outer().m1();
	}
}