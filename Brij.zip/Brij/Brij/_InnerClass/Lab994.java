class Outer
{
	void show()
	{
		System.out.println("Outer-> show()");
		
		Inner in =new Inner();
		System.out.println(in.x); // inner class member can be accessed in Outer class by creating Object.
		in.m1(); // inner class member can be accessed in Outer class by creating Object.
	}
	class Inner
	{
		int x=11;
		void m1()
		{
			System.out.println("Inner ->m1()");
		}
	}
}
class Lab994
{
	public static void main(String[] args)
	{
		Outer out=new Outer();
		out.show();	
	}
}