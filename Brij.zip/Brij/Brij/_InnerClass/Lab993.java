/*Lab993.java:6: error: cannot find symbol
                System.out.println(x);
                                   ^
  symbol:   variable x
  location: class Outer
Lab993.java:7: error: cannot find symbol
                m1();
                ^
  symbol:   method m1()
  location: class Outer
2 errors*/

class Outer
{
	void show()
	{
		System.out.println("Outer-> show()");
		System.out.println(x); 	// inner class member can't be accessed in Outer class directly.
		m1(); // inner class member can't be accessed in Outer class directly.
	}
	class Inner
	{
		int x=11;
		void m1()
		{
			System.out.println("Inner ->m1()");
		}
	}
}
class Lab993
{
	public static void main(String[] args)
	{
		Outer out=new Outer();
		out.show();	
	}
}