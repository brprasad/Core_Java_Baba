class Outer
{	
	// following are the modifier allowed for inner interface.
	private interface Inner1{}
	protected interface Inner2{}
	public interface Inner3{}
	static interface Inner4{}
	abstract interface Inner5{}
	private abstract interface Inner6{} // inner interface is only interface who use private and abstract modifier both at a time.
	
}
class Lab999
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");
	}
}