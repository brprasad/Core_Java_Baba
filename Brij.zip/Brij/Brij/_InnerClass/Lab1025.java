
abstract class Person
{
	public abstract void sleeping();
}

class Lab1025
{
	public static void main(String[] args)
	{
		new Person(){ // anonymous inner class declaration or creating subclass of Person 
			void reading()  //new method in sub class
			{
				System.out.println("Student -> reading()");
			}
			public void sleeping()// overriden method of Person class in sub class.
			{
				System.out.println("Student -> sleeping()");
			}
		}.reading();
	}
}