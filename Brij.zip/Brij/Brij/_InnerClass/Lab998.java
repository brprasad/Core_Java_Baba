class Outer
{	
	// following are the modifier allowed for inner class.
	private class Inner1{}
	protected class Inner2{}
	public class Inner3{}
	static class Inner4{}
	abstract class Inner5{}
	private abstract class Inner6{} // inner class is only class who use private and abstract modifier both at a time.
	
}
class Lab998
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");
	}
}