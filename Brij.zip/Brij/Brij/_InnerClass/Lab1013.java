class Outer
{
	int a=10;
	static int b=20;
	void show() // method is non-static 
	{
		System.out.println("Outer -> show()");
		class Inner // local inner class in method show i.e scope of that class Inner is method show() scope.
		{
			int a=10;	
			final static int c=30;
			void m1()
			{
				System.out.println("Inner -> m1()");
			}
		}
	}
}
class Lab1013
{
	public static void main(String[] args)
	{
		Outer out =new Outer();
		out.show();
	}
}