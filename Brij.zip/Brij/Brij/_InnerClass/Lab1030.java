class A
{
	int x=10;
}
class B
{
	char x='J';
}
class Outer extends A
{
	String x="JLC";
	class Inner extends B
	{
		boolean x=true;
		void show()
		{
			float x=10.0F;
			System.out.println(x);	//10.0
			System.out.println(this.x); //true
			System.out.println(Inner.this.x); //true
			System.out.println(Inner.super.x); //J
			System.out.println(Outer.this.x);  //JLC
			System.out.println(Outer.super.x); //10
		}
	}
}
class Lab1030
{
	public static void main(String[] args)
	{
		new Outer().new Inner().show();
	}
}