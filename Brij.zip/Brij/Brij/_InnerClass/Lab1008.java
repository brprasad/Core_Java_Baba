class Hello
{
	{
		System.out.println("I.B Hello");
		class Inner{} // Local inner class in instance Block
	}
	static
	{
		System.out.println("S.B Hello");
		class Inner{} // Local inner class in static block
	}
	Hello()
	{
		System.out.println("D.C Hello");
		class Inner{} // Local inner class in Default coonstructor
	}
	void m1()
	{
		System.out.println("m1()- Hello");
		class Inner{} // Local inner class in method.
	}
}
class Lab1008
{
	public static void main(String[] args)
	{
		System.out.println("Hello guys");
	}
}