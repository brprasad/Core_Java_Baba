class A
{
	static class B
	{
		public static void main(String[] args)
		{
			System.out.println("Main in A.B"); 
		}
	}
}
