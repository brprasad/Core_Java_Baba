class Outer
{
	int a=10;
	static int b=20;
	void show() // method is static 
	{
		System.out.println("Outer -> show() Begin");
		class Inner // local inner class in method show i.e scope of that class Inner is method show() scope.
		{
			void m1()
			{
				System.out.println("Inner -> m1()");
				System.out.println(b);
			}
		}
		new Inner().m1();
		System.out.println("Outer -> show() End");
	}
}
class Lab1011
{
	public static void main(String[] args)
	{
		Outer out =new Outer();
		out.show();
	}
}