abstract class Person
{
	public abstract void sleeping();
}
class Hello
{
	Person person =new Person()
	{ // anonymous inner class declaration or creating subclass of Person 
		public void sleeping()
		{
			System.out.println("Student -> sleeping()");
		}
	};
	
	void m1()
	{
		person.sleeping();
	}
}
class Lab1022
{
	public static void main(String[] args)
	{
		Hello h =new Hello();
		h.m1();
		h.person.sleeping();
	}
}