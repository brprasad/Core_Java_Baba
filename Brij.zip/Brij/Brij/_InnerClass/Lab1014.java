/*Lab1014.java:13: error: cannot find symbol
                Inner1 obj1=new Inner1();//
                ^
  symbol:   class Inner1
  location: class Outer
Lab1014.java:13: error: cannot find symbol
                Inner1 obj1=new Inner1();//
                                ^
  symbol:   class Inner1
  location: class Outer
Lab1014.java:14: error: cannot find symbol
                Inner2 obj2=new Inner2();//
                ^
  symbol:   class Inner2
  location: class Outer
Lab1014.java:14: error: cannot find symbol
                Inner2 obj2=new Inner2();//
                                ^
  symbol:   class Inner2
  location: class Outer
4 errors*/

class Outer
{
	void m1() // method is non-static 
	{
		class Inner1{} // local inner class in method m1 i.e scope of that class Inner1 is method m1() scope.
	}
	void m2() // method is non-static 
	{
		class Inner2{} // local class inner in method m2 i.e scope of that class Inner2 is method m2() scope.
	}
	void m3()
	{
		Inner1 obj1=new Inner1();// Local inner class must be instantiated in same scope only.
		Inner2 obj2=new Inner2();// Local inner class must be instantiated in same scope only.
	}
}
class Lab1014
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");
	}
}