/*Lab1010.java:13: error: non-static variable a cannot be referenced from a static context
                                System.out.println(a);
                                                   ^
1 error*/

class Outer
{
	int a=10;
	static int b=20;
	static void show() // method is static 
	{
		System.out.println("Outer -> show() Begin");
		class Inner // local inner class in method show i.e scope of that class Inner is method show() scope.
		{
			void m1()
			{
				System.out.println("Inner -> m1()");
				System.out.println(a); //non-static variable a cannot be referenced from a static context
				System.out.println(b);
			}
		}
		new Inner().m1();
		System.out.println("Outer -> show() End");
	}
}
class Lab1010
{
	public static void main(String[] args)
	{
		Outer out =new Outer();
		out.show();
	}
}