abstract class Person
{
	public abstract void sleeping();
}

class Lab1021
{
	public static void main(String[] args)
	{
		Person person =new Person()
		{// anonymous inner class declaration or creating subclass of Person 
			public void sleeping()
			{
				System.out.println("Student -> sleeping()");
			}
		};	
		person.sleeping();
	}
}