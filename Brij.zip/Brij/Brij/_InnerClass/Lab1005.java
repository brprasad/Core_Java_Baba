class Outer
{
	int a=10;
	static int b=20;
	void m1()
	{
		System.out.println("Outer-> m1()");
	}
	static void m2()
	{
		System.out.println("Outer-> m2()");
	}
	static class Inner
	{
		int x=11;
		static int y=22;
		void show()
		{
			System.out.println("Inner-> show()");
			System.out.println(b);
			System.out.println(x);
			System.out.println(y);
			m2();
		}
		static void m3()
		{
			System.out.println("Inner-> m3()");
		}
	}
}

class Lab1005
{
	public static void main(String[] args)
	{
		Outer out =new Outer();
		out.m1();	out.m2();
		Outer.Inner in =new Outer.Inner();
		in.show();	in.m3();
	}
}