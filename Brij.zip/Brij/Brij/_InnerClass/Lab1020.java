/*Lab1020.java:10: error: <anonymous Lab1020$1> is not abstract and does not override abstract method sleeping() in Person
                Person person =new Person(){};
                                           ^
1 error*/

abstract class Person
{
	public abstract void sleeping();
}

class Lab1020
{
	public static void main(String[] args)
	{
		Person person =new Person(){};	// <anonymous Lab1020$1> is not abstract and 
										// does not override abstract method sleeping() in Person
	}
}