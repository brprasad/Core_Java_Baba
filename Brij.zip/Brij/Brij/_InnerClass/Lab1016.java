/*Lab1016.java:10: error: local variable a is accessed from within inner class; needs to be declared final
                                System.out.println(a);
                                                   ^
1 error*/

class Outer
{
	void m1() // method is non-static 
	{
		int a=10;
		class Inner1 // local inner class in method m1 i.e scope of that class Inner1 is method m1() scope.
		{ 
			void show()
			{
				System.out.println(a); // local variable a is accessed from within inner class; needs to be declared final
			}
		}
	new Inner1().show();
	}
}
class Lab1016
{
	public static void main(String[] args)
	{
		new Outer().m1();
	}
}