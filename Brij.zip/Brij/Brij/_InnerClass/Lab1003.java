class Outer		
{	
	private int a=10;
	class Inner	
	{
		private int a=20; //private member of Inner class can be access from Outer class by creating onject of Inner class.
		void showInner()
		{
			System.out.println("Inner-> showInner()");	
			System.out.println(a);	
			System.out.println(this.a); 
			
		}
	}
	void showOuter()
	{
		System.out.println("Outer-> showOuter()");	
		System.out.println(a);	
		System.out.println(this.a); 		
		System.out.println(new Inner().a); 	//private member of Inner class can be access from Outer class 
											//by creating onject of Inner class. o/p is 20
	}
}
class Lab1003	
{
	public static void main(String[] args)
	{
		new Outer().new Inner().showInner();
		new Outer().showOuter();
	}
}