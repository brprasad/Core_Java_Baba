class Outer
{
	void showOuter()
	{
		System.out.println("Outer-> showOuter()");
											// member of static inner class can't be access directly in outer class.
		System.out.println(new Inner().x);	// instance member can be accessed by creating object of inner class.
		System.out.println(Inner.y);	// static member can be access by using class name.
		Inner.m1();	// static member can be access by using class name.
	}
	static class Inner
	{
		int x=11;
		static int y=22;
		static void m1()
		{
			System.out.println("Inner-> m1()");
		}
	}
}

class Lab1007
{
	public static void main(String[] args)
	{
		Outer out =new Outer();
		out.showOuter();
	}
}