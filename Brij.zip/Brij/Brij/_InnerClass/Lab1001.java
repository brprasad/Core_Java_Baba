// nested inner class and .class file name generated as following:-
class Outer		//Outer.class
{	
	class Inner1	// Outer$Inner1.class
	{
		class Inner2{} 	// Outer$Inner1$Inner2.class
		class Inner3	// Outer$Inner1$Inner3.class
		{
			class Inner4	//Outer$Inner1$Inner3$Inner4.class
			{
				class Inner5{}	//Outer$Inner1$Inner3$Inner4$Inner5.class
			}
		}
	}
	
}
class Lab1001	// Lab1001.class
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");
	}
}