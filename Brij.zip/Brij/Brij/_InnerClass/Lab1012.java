/*Lab1012.java:12: error: Illegal static declaration in inner class Inner
                        static int b=20;
                                   ^
  modifier 'static' is only allowed in constant variable declarations
Lab1012.java:18: error: Illegal static declaration in inner class Inner
                        static void m2()
                                    ^
  modifier 'static' is only allowed in constant variable declarations
2 errors */
class Outer
{
	int a=10;
	static int b=20;
	void show() // method is non-static 
	{
		System.out.println("Outer -> show()");
		class Inner // local inner class in method show i.e scope of that class Inner is method show() scope.
		{
			int a=10;	
			static int b=20;	// modifier 'static' is only allowed in constant variable declarations 
			final static int c=30;
			void m1()
			{
				System.out.println("Inner -> m1()");
			}
			static void m2()
			{
				System.out.println("Inner -> m2()");
			}
		}
	}
}
class Lab1012
{
	public static void main(String[] args)
	{
		Outer out =new Outer();
		out.show();
	}
}