class Outer		
{	
	int a=11;
	class Inner1	
	{
		int a=22;
		void show()
		{
			int a=33;
			System.out.println(a);	// 33
			System.out.println(this.a); // current class object ref : 22
			System.out.println(Inner1.this.a); //Inner1 class object and this ref contain same address : 22 
			//System.out.println(super.a); because inheritance relation is not present so we can't use super keyword.
			System.out.println(Outer.this.a); // call this on Outer class :11
		}
	}
	
}
class Lab1002	
{
	public static void main(String[] args)
	{
		new Outer().new Inner1().show();
	}
}