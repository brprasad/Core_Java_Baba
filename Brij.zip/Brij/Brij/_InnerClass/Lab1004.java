/*Lab1004.java:20: error: non-static variable a cannot be referenced from a static context
                        System.out.println(a);
                                           ^
Lab1004.java:24: error: non-static method m1() cannot be referenced from a static context
                        m1(); m2();
                        ^
2 errors*/

class Outer
{
	int a=10;
	static int b=20;
	void m1()
	{
		System.out.println("Outer-> m1()");
	}
	static void m2()
	{
		System.out.println("Outer-> m2()");
	}
	static class Inner
	{
		int x=11;
		static int y=22;
		void show()
		{
			System.out.println("Inner-> show()");
			System.out.println(a);	// non-static variable a cannot be referenced from a static context
									//only static member of outer class can be accessed inside Static Inner class directly.
			System.out.println(b);
			System.out.println(x);
			System.out.println(y);
			m1();	//non-static method m1() cannot be referenced from a static context
					//only static member of outer class can be accessed inside Static Inner class directly.
			m2();
		}
		static void m3()
		{
			System.out.println("Inner-> m3()");
		}
	}
}

class Lab1004
{
	public static void main(String[] args)
	{
		Outer out =new Outer();
		out.m1();	out.m2();
		Outer.Inner in =new Outer.Inner();
		in.show();	in.m3();
	}
}