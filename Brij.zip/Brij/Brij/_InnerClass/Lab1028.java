class Hello{}

class Lab1028
{
	public static void main(String[] args)
	{
		Hello h1=new Hello(){};					// sub class of Hello class or anonymous inner class.
		Hello h2=new Hello(){};					// sub class of Hello class or anonymous inner class.
		System.out.println(h1);					// contain object h1 address
		System.out.println(h2);					// contain object h2 address
		System.out.println(h1==h2);				// o/p is false because two object address will never be same.
	}
}