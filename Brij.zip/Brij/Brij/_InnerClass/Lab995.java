/*Lab995.java:5: error: Illegal static declaration in inner class Outer.Inner
                static int a=10;
                           ^
  modifier 'static' is only allowed in constant variable declarations
Lab995.java:6: error: Illegal static declaration in inner class Outer.Inner
                static void m1(){}
                            ^
  modifier 'static' is only allowed in constant variable declarations
2 errors*/

class Outer
{
	class Inner
	{
		static int a=10;  	// static variable are not allowed in instance inner class,
							// only final static variable i.e constant variable declarations is allowed in inner class.
		static void m1(){} 	// static methods are not allowed in instance inner class.
	}
}
class Lab995
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");
	}
}