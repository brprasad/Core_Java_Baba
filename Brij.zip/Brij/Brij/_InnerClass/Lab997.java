class Outer
{
	class Inner
	{
		int A=10;  	
		void m1(){}
	}
}
class Lab997
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");
	}
}