/*Lab1006.java:6: error: cannot find symbol
                System.out.println(x);
                                   ^
  symbol:   variable x
  location: class Outer
Lab1006.java:7: error: cannot find symbol
                System.out.println(y);
                                   ^
  symbol:   variable y
  location: class Outer
Lab1006.java:8: error: cannot find symbol
                m1();
                ^
  symbol:   method m1()
  location: class Outer
3 errors*/

class Outer
{
	void showOuter()
	{
		System.out.println("Outer-> showOuter()");
											// member of static inner class can't be access directly in outer class.
		System.out.println(x);	// instance member can be accessed by creating object of inner class.
		System.out.println(y);	// static member can be access by using class name.
		m1();	// static member can be access by using class name.
	}
	static class Inner
	{
		int x=11;
		static int y=22;
		static void m1()
		{
			System.out.println("Inner-> show()");
		}
	}
}

class Lab1006
{
	public static void main(String[] args)
	{
		Outer out =new Outer();
		out.showOuter();
	}
}