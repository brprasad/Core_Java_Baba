class Outer
{
	void m1() // method is non-static 
	{
		//Inner1 obj1=new Inner1();  this statement give error because we can't call any statement before its declaration.
		class Inner1{} 	// local inner class in method m1 i.e scope of that class Inner1 is method m1() scope.
		Inner1 obj1=new Inner1();
	}
	void m2() // method is non-static 
	{
		class Inner2{} 	// local class inner in method m2 i.e scope of that class Inner2 is method m2() scope.
		Inner2 obj2=new Inner2();
	}
}
class Lab1015
{
	public static void main(String[] args)
	{
		System.out.println("Hello Guys");
	}
}