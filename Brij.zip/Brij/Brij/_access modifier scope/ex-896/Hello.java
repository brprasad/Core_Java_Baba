package com.jlc.p1;
public class Hello
{
	protected int ab=99;
}