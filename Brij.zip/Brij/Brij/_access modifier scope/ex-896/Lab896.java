package com.jlc.p2;
import com.jlc.p1.Hello;

class Xyz extends Hello{}

class Hai extends Hello
{
	void show()
	{
		System.out.println("Hai-show()");
		Hello hello=new Hello();
		System.out.println(hello.ab);
		
		Xyz xyz =new Xyz();
		System.out.println(xyz.ab);
	}
}

public class Lab895
{
	public static void main(String[] args)
	{
		Hai hai =new Hai();
		hai.show();
	}
}