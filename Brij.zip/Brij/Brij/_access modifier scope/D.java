package com.jlc.p2;
import com.jlc.p1.A;
public class D extends A	// different package subclass
{
	public void show()
	{
		System.out.println("D-> show()");
	
		//System.out.println(a); 
		/*  D.java:7: error: a has private access in A  
		so we can't access private member of class any where, either direct or by creating object  
		and private member of class can't be inherited. */
						
		//System.out.println(b);
		/*  D.java:7: error: can't be access from outside the package 
		so we can't access default member of class any where, either direct or by creating object  
		and default member of class can't be used outside the package.
		default scope is also called pacakge private scope */
		
		System.out.println(c);	// accessed from outside the package in subclass direct,with D object,this,super 
								//*** imp- but not with A class Object.
		System.out.println(d);
		
	}
	
}