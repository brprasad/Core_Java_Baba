package com.jlc.p1;
public class B extends A 	//subclass in same package
{
	public void show()
	{
		System.out.println("B-> show()");
	//	System.out.println(a);
		/* B.java:7: error: a has private access in A  
		so we can't access private member of class any where, either direct or by creating object  
		and private member of class can't be inherited. */
						
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
	}
	
}