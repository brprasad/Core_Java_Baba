public class Lab901
{
	public static void main(String[] args)
	{
		B bobj=new B(99);	// constructor invocation of current class
		System.out.println(bobj.getX());	// getter method
	}
}
class A
{
	private int x;	// x is a private member of A class, can't be used outside A class .
	
	A(int x)	// use constructor or setter method to assign value to private datamember.
	{
		this.x=x;
	}
	public int getX()	// use getter method to access value of private datamember.
	{
		return this.x;
	}
}
class B extends A
{
	B(int x)
	{
		super(x);	// invocking constructor of super class
	}
}
