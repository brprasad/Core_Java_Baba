public class Lab900
{
	public static void main(String[] args)
	{
		A aobj=new A();
		aobj.setX(99);	//setter method 
		System.out.println(aobj.getX());	// getter method
		
	}
}

class A
{
	private int x;	// x is a private member of A class, can't be used outside A class .
	
	public void setX(int x)	// use setter method to assign value to private datamember.
	{
		this.x=x;
	}
	public int getX()	// use getter method to access value of private datamember.
	{
		return this.x;
	}
}
