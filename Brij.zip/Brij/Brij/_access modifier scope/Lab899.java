public class Lab899
{
	public static void main(String[] args)
	{
		A aobj=new A(99);
		aobj.show();
	}
}

class A
{
	private int x;	// x is a private member of A class, can't be used outside A class .
	
	A(int x)	// always use constructor to assign value to private datamember.
	{
		this.x=x;
	}
	void show()
	{
		System.out.println(x); // so to access private member outside class always use method.
	}
}
