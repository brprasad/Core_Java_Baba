/*Lab897.java:6: error: x has private access in A
                aobj.x=99;
                    ^
Lab897.java:7: error: x has private access in A
                System.out.println(aobj.x);
                                       ^
2 errors*/

public class Lab897
{
	public static void main(String[] args)
	{
		A aobj=new A();
		aobj.x=99;
		System.out.println(aobj.x);
	}
}

class A
{
	private int x;	// x is a private member of A class, can't be used outside A class.
}