package com.jlc.p2;
import com.jlc.p1.A;
public class E		//different package non-subclass.
{
	public void show()
	{
		System.out.println("E-> show()");
		A e1=new A();
		//System.out.println(e1.a);
		/*  A.java:7: error: a has private access in A  
		so we can't access private member of class any where, either direct or by creating object  
		and private member of class can't be inherited. */
						
		//System.out.println(e1.b);	
		/*  A.java:7: error: can't be access from outside the package 
		so we can't access default member of class any where, either direct or by creating object  
		and default member of class can't be used outside the package.
		default scope is also called pacakge private scope */
				
		//System.out.println(e1.c);	//not accessed from outside the package non-subclass with direct, E object, A onject,this,super 
					
		System.out.println(e1.d);
			
	}
	
}