package com.jlc.p1;
public class C		// non-subclass in same package
{
	public void show()
	{
		System.out.println("C-> show()");
		A a1= new A();
		
		//System.out.println(a1.a); 
		
		/*	C.java:7: error: a has private access in A  
		so we can't access private member of class any where, either direct or by creating object  
		and private member of class can't be inherited. */
						
		System.out.println(a1.b);
		System.out.println(a1.c);
		System.out.println(a1.d);
		
	}
	
}