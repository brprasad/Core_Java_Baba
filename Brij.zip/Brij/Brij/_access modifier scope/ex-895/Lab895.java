package com.jlc.p3;
import com.jlc.p1.*;
import com.jlc.p2.*;
public class Lab895
{
	public static void main(String[] args)
	{
		A aobj=new A();
		aobj.show();
		
		B bobj=new B();
		bobj.show();
		
		C cobj=new C();
		cobj.show();
		
		D dobj=new D();
		dobj.show();
		
		E eobj=new E();
		eobj.show();
		
	}
}