package com.jlc.p1;
public class B extends A	//same package subclass
{
	public void show()
	{
		System.out.println("B-> show()");
		System.out.println("Direct");
		//System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
		System.out.println("A-Object");
		A a1=new A();
		//System.out.println(a1.a);
		System.out.println(a1.b);
		System.out.println(a1.c);
		System.out.println(a1.d);
		
		System.out.println("B-Object");
		B b1=new B();
		//System.out.println(b1.a);
		System.out.println(b1.b);
		System.out.println(b1.c);
		System.out.println(b1.d);
		
		
	}
	
}