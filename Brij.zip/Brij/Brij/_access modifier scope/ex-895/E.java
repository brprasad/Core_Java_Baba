package com.jlc.p2;
import com.jlc.p1.*;
import com.jlc.p2.*;
public class E		// different package non-subclass
{
	public void show()
	{
		System.out.println("E-> show()");
			
		System.out.println("A-Object");
		A a1=new A();
		//System.out.println(a1.a);
		//System.out.println(a1.b);
		//System.out.println(a1.c);
		System.out.println(a1.d);
				
	}
	
}