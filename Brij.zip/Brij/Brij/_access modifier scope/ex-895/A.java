package com.jlc.p1;
public class A
{
	private int a=10;
			int b=20;
	protected int c=30;
	public int d=40;
	
	public void show()
	{
		System.out.println("A-> show()");
		System.out.println("Direct");
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
		System.out.println("A-Object");
		A a1=new A();
		System.out.println(a1.a);
		System.out.println(a1.b);
		System.out.println(a1.c);
		System.out.println(a1.d);
		
	}
	
}