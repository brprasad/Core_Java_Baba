package com.jlc.p2;
import com.jlc.p1.*;
public class D extends A	//defferent package subclass.
{
	public void show()
	{
		System.out.println("D-> show()");
		System.out.println("Direct");
		//System.out.println(a);
		//System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
		System.out.println("A-Object");
		A a1=new A();
		//System.out.println(a1.a);
		//System.out.println(a1.b);
		//System.out.println(a1.c);
		System.out.println(a1.d);
		
		System.out.println("D-Object");
		D d1=new D();
		//System.out.println(d1.a);
		//System.out.println(d1.b);
		System.out.println(d1.c);
		System.out.println(d1.d);
		
		System.out.println("super keyword");
		
		//System.out.println(super.a);
		//System.out.println(super.b);
		System.out.println(super.c);
		System.out.println(super.d);
		
		
	}
	
}